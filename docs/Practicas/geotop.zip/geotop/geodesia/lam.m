% Funcion:  lam
% Objeto:   Determinacion de la longitud de arco de meridiano a
%           partir de la latitud geodesica sobre un elipsoide de
%           revolucion.
% Recibe:   - Latitud geodesica en radianes.
%           - Elipsoide de trabajo, como un vector fila de 5 columnas:
%             elipsoide=[a alfa b e e'];
% Devuelve: Longitud de arco de meridiano en metros.
% Ejemplo:  lam1=lam(fig,elipsoide)
