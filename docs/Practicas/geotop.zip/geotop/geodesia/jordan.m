% Funcion:  jordan
% Objeto:   Calcula el desnivel elipsoidico mediante la formula de jordan
% Recibe:   - hi altitud aproximada del punto de estacion
%           - hj altitud aproximada del del punto visado. Si se desconoce introducir 0
%           - sij longitud aproximada de la l�nea geod�sica entre i y j
%           - ce cenital directo de la linea estacion-punto visado
%           - rt radio terrestre (radio de euler)
%           - i altura del instrumento
%           - m altura de mira
% Devuelve: Desnivel elipsoidico
% Ejemplo:  ih=jordan(hi,hj,sij,ce,rt,i,m)
