% Funcion:  clhapv
% Objeto:   Corrige una lectura horizontal por la altura del punto visado.
% Recibe:   - Lectura a corregir, en radianes.
%           - Azimut directo de la linea geodesica, en radianes.
%           - Latitud del punto estacion, en radianes.
%           - Latitud del punto visado, en radianes.
%           - Altitud elipsoidal del punto visado, en metros.
%           - Elipsoide de trabajo, como un vector fila de 5 columnas:
%             elipsoide=[a alfa b e e'];
% Devuelve: Lectura corregida en radianes, entre 0 y 2pi.
% Ejemplo:  lhz12c=clhapv(lhz,az,fi1,fi2,h2,elipsoide)
