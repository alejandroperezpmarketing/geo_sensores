% Funcion:  pdgrk4o
% Objeto:   Resuelve el problema directo de la geodesia sobre el elipsoide
%           por el metodo de integracion numerica de Runge-Kutta de cuarto
%           orden.
% Recibe:   - Coordenadas geodesicas en radianes del punto origen de la geodesica,
%           - Longitud de la linea en metros, 
%             El dominio de la longitud es [0,pi] U ]-pi,0]
%           - Azimut geodesico de inicio en radianes y
%           - Elipsoide de trabajo:  elipsoide=[a alfa b e e'];
% Devuelve: Coordenadas geodesica en radianes del extremo final.
% Ejemplo:  [fi2,lon2]=pdgrk4o(fi1,lon1,s12,a12,elipsoide);
