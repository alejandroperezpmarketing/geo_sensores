% Funcion:  errjordan
% Objeto:   Estima el error en el desnivel obtenido a partir de la formula de jordan
% Recibe:   - Latitud,longitud y altitud elipsoidal del punto de estacion
%				- Latitud,longitud y altitud elipsoidal del punto visado
%           - Angulo cenital
%				- Parametros del elipsoide
%           - Matriz con las caracteristicas del instrumental.
%             Su estructura es, ej:
%  			  inst=[1  2  0.001  0.001  0.020  2.0  0.015  0.015  0.000  0      0      0     0
%					     2  2  0.001  0.001  0.010  1.0  0.015  0.015  0.000  0      0      0     0
%  					  3  1  1      1.0    20     30   1      0.01   3.000  0.005  0.020  0.01  0.01];
%             - Cada fila corresponde a un instrumento distinto.
%             - Cada fila tiene 13 columnas.
%             - La primera columna es el numero del instrumento.
%             - La segunda columna es el tipo: 1-Est. Total o Teo+Dis, 2-GPS.
%               Para Est.Total las siguientes columnas corresponden a:
%               - Col.3:  1/0, Lectura Analogica / Digital.
%               - Col.4:  Apreciacion de lectura angular, en segundos centesimales.
%               - Col.5:  Sensibilidad del nivel tubular en segundos sexagesimales.
%               - Col.6:  Aumentos del anteojo.
%               - Col.7:  1/0, Compensador o no de eclimetro.
%               - Col.8:  Parte constante de error del distanciometro, en metros.
%               - Col.9:  Parte proporcional de error del distanciometro, en ppm.
%               - Col.10: Error de centrado en el instrumento, en metros.
%               - Col.11: Error de centrado en el elemento de punteria, en metros.
%               - Col.12: Error de medida de altura de instrumento, en metros.
%               - Col.13: Error en altura de punteria, en metros.
%           - Numero identificador del instrumento(fila)
%           - Numero de veces que se realiza la visual.
% Devuelve: - Error propagado al desnivel elipsoidal, en metros.
% Lamadas:  pigbsl,reuler,edirev
% Ejemplo:  eh=errjordan(lati,loni,heli,latj,lonj,helj,ce,elipsoide,instru,ni,nl)
