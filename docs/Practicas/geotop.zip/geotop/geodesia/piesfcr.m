% Funcion:  piesfcr
% Objeto:   Resuelve el problema inverso de la geodesia sobre una esfera
%           utilizando el metodo de rotacion ( cambio de base ).
% Recibe:   - Coordenadas geodesicas en radianes del punto origen de la geodesica,
%           - Coordenadas geodesicas en radianes del punto final de la geodesica y
%           - Radio de la esfera en metros.
%           El dominio de la longitud es [0,pi] U ]-pi,0]
% Devuelve: - Longitud del arco de circulo maximo en metros.
%           - Azimut del arco de circulo maximo en el origen.
% Ejemplo:  [s12,a12]=piesfcr(fi1,l1,fi2,l2,resfera);