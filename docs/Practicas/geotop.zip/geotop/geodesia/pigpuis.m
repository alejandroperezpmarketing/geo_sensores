% Funcion:  pigpuis
% Objeto:   Resuelve el problema inverso de la geodesia sobre el elipsoide
%           por el metodo de Puissant.
% Recibe:   - Coordenadas geodesicas en radianes del punto origen y final de
%             la geodesica: Latitud y Longitud.
%             El dominio de la longitud es [0,pi] U ]-pi,0]
%           - Elipsoide de trabajo.
%             elipsoide=[a alfa b e e'];
% Devuelve: - Longitud de la linea geodesica.
%           - Azimut geodesico en el punto origen.
%           - Azimut geodesico en el punto final.
% Ejemplo:  [sij,aij,aji]=pigpuis(fi,li,fj,lj,elipsoide);
