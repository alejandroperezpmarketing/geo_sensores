% Funcion:  rdtce
% Objeto:   Reduce una distancia del terreno a la cuerda sobre el elipsoide.
% Recibe:   - Distancia terreno, en metros.
%           - Azimut de la seccion normal, en radianes.
%           - Latitud geodesica del punto estacion,  en radianes.
%           - Altitud elipsoidal del punto estacion ( incrementada con la
%             altura del instrumento ), en metros.
%           - Altitud elipsoidal del punto visado ( incrementada con la
%             altura del prisma ), en metros.
%           - Elipsoide:  elipsoide=[a alfa b e e'];
% Devuelve: Distancia reducida a la cuerda elipsoide.
% Ejemplo:  dce=rdtce(dg,az,lat1,h1,h2,elipsoide);
% Llamadas: rm, rn.
