% Funcion:  tri2esf
% Objeto:   Convierte las coordenadas cartesianas geoc�ntricas x, y, z al sistema de coordenadas 
%           ef�ricas (latitud esf�rica, longitud esf�rica, distancia)
% Recibe:   x (m), y (m), z (m)
% Devuelve: Latitud esf�rica(rad),longitud ef�rica(rad),distancia(m)
% Ejemplo:  [lae,loe,dis]=tri2esf(x,y,z);