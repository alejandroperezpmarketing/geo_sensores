% Funcion:  xyzclat
% Objeto:   Paso de un Vector Geodesico expresado en Componentes del Sistema
%           Cartesiano Tridimensional: ix, iy, iz a Componentes en polares
%           ( observables clasicos: az,v,dg ), sobre el terreno.
% Recibe:   - Coordenadas Geodesicas del origen en radianes: Latitud y Longitud
%             El dominio de la longitud es [0,pi] U ]-pi,0]
%           - Componentes ix,iy,iz, en metros.
% Devuelve: Distancia geometrica en metros, azimut y cenital en radianes.
% Ejemplo:  [dg12,a12,v12]=xyzclat(fi1,lon1,ix,iy,iz)
% Llamadas: xyzenu, enucla.
