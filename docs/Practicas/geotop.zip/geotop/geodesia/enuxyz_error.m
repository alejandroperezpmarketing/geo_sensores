% Funcion:  enuxyz_error
% Objeto:   Paso de un vector geodesico expresado en componentes del sistema
%           topocentrico local: ie, in, iu a incrementos de coordenadas
%           cartesianas tridimensionales: ix,iy,iz con propagacion de error
% Recibe:   - Coordenadas geodesicas del Extremo Origen del vector, en radianes
%             latitud y longitud.
%             El dominio de la longitud es [0,pi] U ]-pi,0]
%           - Componentes ie,in,iu en metros.
% Devuelve: Componentes Cartesianas Tridimensionales en metros: ix, iy, iz.
% Ejemplo:  [ix,iy,iz,errorxyz]=enuxyz_error(lat,lon,ie,in,iu,errorenu)
