% Funcion:  pdg_dif1
% Objeto:   Resuelve el problema directo de la geodesia sobre el elipsoide
%           utilizando un desarrollo limitado a las primeras derivadas parciales
%           de latitud, longitud y azimut respecto a la distancia.
% Recibe:   - Coordenadas geodesicas en radianes del punto origen de la geodesica,
%           - Longitud de la linea en metros,
%           - Azimut geodesico de inicio en radianes y
%           - Elipsoide de trabajo:  elipsoide=[a alfa b e e'];
%           El dominio de la longitud es [0,pi] U ]-pi,0]
% Devuelve: - Coordenadas geodesicas en radianes del extremo final y
%           - Azimut reciproco en el extremo final.
% Ejemplo:  [fi2,lon2,a21]=pdg_dif1(fi1,lon1,s12,a12,elipsoide);
