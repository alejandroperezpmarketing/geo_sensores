% Funcion:  enucla
% Objeto:   Paso de un vector geodesico expresado en componentes del sistema
%           topocentrico local: ie, in, iu a coordenadas polares
%           ( observables clasicos: az,dg,ce ).
%           Tambien sirve como paso de cartesianas tridimensionales a
%           polares ( en sentido geodesico ).
% Recibe:   Componentes ie,in,iu en metros.
% Devuelve: Componentes clasicos: az,v en radianes y dg en metros.
% Ejemplo:  [az,dg,ce]=enucla(ie,in,iu)
