% funcion:  elipesf
% Objeto:   Devuelve una variable tipo elipsoide
%              elipsoide=[a alfa b e e'];
%           que es una esfera ( a=b, alfa=0, e=0, e'=0)
%           tangente a un elipsoide en un paralelo de latitud fi.
% Recibe:   - Elipsoide al que ha de ser tangente la esfera.
%           - Latitud geodesica de tangencia, en radianes.
% Devuelve: El mismo elipsoide transformado en esfera.
% Ejemplo:  esfera1=elipesf(elipsoide,fi);
