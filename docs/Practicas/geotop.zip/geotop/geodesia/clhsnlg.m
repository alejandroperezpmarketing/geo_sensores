% Funcion:  clhsnlg
% Objeto:   Pasa una lectura horizontal de la seccion normal a la linea geodesica.
% Recibe:   - Lectura a corregir, en radianes.
%           - Longitud de la linea geodesica, en metros.
%           - Azimut directo de la linea geodesica, en radianes.
%           - Latitud del punto estacion, en radianes.
%           - Latitud del punto visado, en radianes.
%           - Elipsoide de trabajo, como un vector fila de 5 columnas:
%             elipsoide=[a alfa b e e'];
% Devuelve: Lectura corregida en radianes, entre 0 y 2pi.
% Ejemplo:  lhz12c=clhsnlg(lhz,s,az,lat1,lat2,elipsoide)
