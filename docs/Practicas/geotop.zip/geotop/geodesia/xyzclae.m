% Funcion:  xyzclae
% Objeto:   Paso de un Vector Geodesico expresado en Componentes del Sistema
%           Cartesiano Tridimensional: ix, iy, iz a Componentes sobre el elipsoide
%           ( long.linea geodesica, azimut linea geodesica e incr.alt.elip.: sg,azg,ih ).
% Recibe:   - Coordenadas Cartesianas Tridimensionales del origen, Componentes ix,iy,iz,
%             ambas en metros.
%           - Elipsoide
%             elipsoide=[a alfa b e e'];
% Devuelve: Long.linea geodesica en metros, azimut linea geodesica en radianes e
%           incremento de altitud elipsoidal en metros.
% Ejemplo:  [s12,a12,h12]=xyzclae(X1,Y1,Z1,DX,DY,DZ,elipsoide)
% Llamadas: trigeo, pigbslm.
