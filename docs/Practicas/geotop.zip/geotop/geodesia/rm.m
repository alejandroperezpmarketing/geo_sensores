% Funcion:  rm
% Objeto:   Calculo del radio de curvatura de la elipse meridiana.
% Recibe:   - Latitud geodesica, en radianes.
%           - Elipsoide de trabajo, como un vector fila de 5 columnas:
%             elipsoide=[a alfa b e e'];
% Devuelve: Radio en metros.
% Ejemplo:  rempe=rm(fipe,elipsoide)
