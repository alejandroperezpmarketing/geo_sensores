% Funcion:  clhdesv
% Objeto:   Corrige una lectura horizontal por desviacion de la vertical.
% Recibe:   - Lectura a corregir, en radianes.
%           - Latitud del punto de estacion
%           - Desviaci�n de la vertical en direccion del meridiano
%           - Desviaci�n de la vertical en direccion del primer vertical
%           - Azimut directo de la linea estacion-punto visado
%           - Cenital directo de la linea estacion-punto visado
%             si se le asigna un valor nulo hace la correcci�n incompleta de Laplace
% Devuelve: Lectura corregida en radianes, entre 0 y 2pi.
% Ejemplo:  clhdesv=clhdesv(lh,fi1,xi,eta,az,ce)
