% Funcion:  reuler
% Objeto:   Calculo del radio de la seccion normal de un determinado azimut.
% Recibe:   - Latitud geodesica en radianes.
%           - Azimut geodesico de la seccion normal en radianes.
%           - Elipsoide de trabajo, como un vector fila de 5 columnas:
%             elipsoide=[a alfa b e e'];
% Devuelve: Radio en metros.
% Ejemplo:  r45=reuler(fig,azi,elipsoide);
% Llamadas: rm, rn.
