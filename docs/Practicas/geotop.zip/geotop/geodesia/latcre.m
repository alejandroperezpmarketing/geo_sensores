% Funcion:  latcre
% Objeto:   Paso de latitud geodesica a creciente.
% Recibe:   - Latitud geodesica en radianes.
%           - Elipsoide de trabajo, como un vector fila de 5 columnas:
%             elipsoide=[a alfa b e e'];
% Devuelve: Latitud geodesica en radianes.
% Ejemplo:  ficre=latcre(fig,elipsoide)
