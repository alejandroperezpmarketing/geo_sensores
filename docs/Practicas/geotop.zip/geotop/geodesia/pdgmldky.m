% Funcion:  pdgmldky
% Objeto:   Resuelve el problema directo de la geodesia sobre el elipsoide
%           por el metodo de Molodensky.
% Recibe:   - Coordenadas geodesicas en radianes del punto origen de la cuerda,
%           - Altitud elipsoidal del punto origen,
%           - Longitud de la cuerda, 
%             El dominio de la longitud es [0,pi] U ]-pi,0]
%           - Azimut geodesico de inicio de la cuerda en radianes
%           - Angulo cenital de la cuerda  (si se desconoce introducir 0)
%           - Elipsoide de trabajo:  elipsoide=[a alfa b e e'];
% Devuelve: Coordenadas geodesicas en radianes del extremo final y el acimut reciproco.
% Ejemplo:  [fj,lj,aji]=pdgmldky(fi,lj,hi,cij,aij,vij,elipsoide);
