% Funcion:  areaelip
% Objeto:   Calculo superficie sobre el elipsoide encerrada entre los
%           meridianos y paralelos de dos puntos.
% Recibe:   - Coordenadas geodesicas en radianes de los dos puntos que
%             definen las esquinas del area a medir.
%             El dominio de la longitud es [0,pi] U ]-pi,0]
%           - Elipsoide de trabajo, como un vector fila de 5 columnas:
%             elipsoide=[a alfa b e e'];
% Devuelve: Superficie en metros cuadrados.
% Ejemplo:  superf=areaelip(fi1,lon1,fi2,lon2,elipsoide);
