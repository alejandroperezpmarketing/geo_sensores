% Funcion:  pi_loxod
% Objeto:   Resuelve el problema inverso ( s12,a12 ) para la curva
%           loxodromica sobre el elipsoide.
% Recibe:   - Coordenadas geodesicas en radianes del punto origen y final de
%             la loxodromica.
%             El dominio de la longitud es [0,pi] U ]-pi,0]
%           - Elipsoide de trabajo:  elipsoide=[a alfa b e e'];
% Devuelve: - Longitud de la linea loxodromica.
%           - Azimut geodesico en el punto origen.
% Ejemplo:  [s12,a12]=piloxo(fi1,lon1,fi2,lon2,elipsoide);
% Llamadas: latcre.
