% Funcion:  reduce
% Objeto:   Reducir las mediciones de una libreta cl�sica u estimar su error
% Recibe:   Matriz de observaciones ( pe pv lh(cent)  lv(cent)  i(m)  m(m) dg(m) instr )
%			Matriz de instrumentos
%           Matriz de coordenadas   ( num  lat(rad)   lon(rad)   H(m)   N(m)  psi(rad)  eta(rad))
%           Vector con los par�metros del elipsoide de referencia
% Devuelve: Matriz de mediciones angulares reducidas,matriz de mediciones de distancia
%           reducidas y matriz de diferencias de altitud elipsoidal (y errores estimados)
% Ejemplo:  [obsdir,obsdis,obsalt]=reduce(obs,instrumentos,geo,elipsoide) 