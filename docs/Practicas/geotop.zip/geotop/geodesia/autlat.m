% Funcion:  autlat
% Objeto:   Paso de latitud autalica a geodesica.
% Recibe:   - Latitud autalica en radianes.
%           - Elipsoide de trabajo, como un vector fila de 5 columnas:
%             elipsoide=[a alfa b e e'];
% Devuelve: Latitud geodesica en radianes.
% Ejemplo:  fig=autlat(fia,elipsoide);
