% Funcion:  esf2tri
% Objeto:   Convierte coordenadas esf�ricas (lae,loe,dis) a cartesianas geoc�ntricas x,y,z
% Recibe:   latitud esf�rica (rad), longitud esf�rica (rad) y distancia (m)
% Devuelve: Las coordenadas cartesianas geoc�ntricas x, y, z
% Ejemplo:  [x,y,z]=esf2tri(lae,loe,dis);
