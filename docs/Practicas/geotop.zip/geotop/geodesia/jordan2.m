% Funcion:  jordan2
% Objeto:   Calcula el desnivel elipsoidico mediante la formula de jordan
% Recibe:   - Altitud del punto de estacion
%           - Altitud aproximada del punto visado. Si se desconoce introducir 0
%           - Distancia punto estacion - punto visado
%           - Cenital directo de la linea estacion-punto visado
%           - Radio terrestre (radio de euler)
%           - Altura del instrumento
%           - Altura de mira
% Devuelve: Desnivel elipsoidico
% Ejemplo:  ih=jordan2(hi,hj,s,ce,r,i,m)