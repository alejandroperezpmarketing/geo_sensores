% Funcion:  crelat
% Objeto:   Paso de latitud creciente a geodesica.
% Recibe:   - Latitud creciente en radianes.
%           - Elipsoide de trabajo, como un vector fila de 5 columnas:
%             elipsoide=[a alfa b e e'];
% Devuelve: Latitud geodesica en radianes.
% Ejemplo:  fig=crelat(fia,elipsoide);
