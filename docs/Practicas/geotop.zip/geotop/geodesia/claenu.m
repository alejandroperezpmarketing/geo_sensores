% Funcion:  claenu
% Objeto:   Paso de un vector geodesico expresado en coordenadas polares
%           ( observables clasicos: az,v,dg ) a coordenadas en el sistema
%           topocentrico local: ie,in,iu.
%           Tambien sirve como paso de polares ( en sentido geodesico ) a
%           cartesianas tridimensionales referidas al punto estacion.
% Recibe:   Componentes clasicos: az,v en radianes y dg en metros.
% Devuelve: Componentes ie,in,iu en metros.
% Ejemplo:  [iepepv,inpepv,iupepv]=claenu(az,v,dg)
