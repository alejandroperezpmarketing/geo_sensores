% Funcion:  tri2ubl
% Objeto:   Convierte las coordenadas cartesianas geoc�ntricas x, y, z al sistema de coordenadas 
%           "elipsoidales" (u,beta,lambda) empleado para definir en forma cerrada el potencial
% Recibe:   x (m), y (m), z (m) y parametros del elipsoide
% Devuelve: Las coordenadas u,beta,lambda
% Ejemplo:  [u,beta,lambda]=tri2ubl(x,y,z,elipsoide);