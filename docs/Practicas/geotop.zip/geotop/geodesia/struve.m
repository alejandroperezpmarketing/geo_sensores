% Programa: struve
% Objeto:   Define en memoria una variable elipsoide que incluye la
%           definicion del elipsoide de Struve.
%           La variable es un vector fila con la siguiente estructura:
%           - elipsoide(1,1)=Semieje mayor.
%           - elipsoide(1,2)=Aplanamiento.
%           - elipsoide(1,3)=Semieje menor.
%           - elipsoide(1,4)=Primera excentricidad.
%           - elipsoide(1,5)=Segunda excentricidad.
%           En particular, los datos conocidos para este elipsoide son:
%           - elipsoide(1,1)=6378298.3
%           - elipsoide(1,2)=1/294.73
%           El resto se calculan y almacenan.
% Llamada:  struve
