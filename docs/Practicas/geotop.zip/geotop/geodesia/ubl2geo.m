% Funcion:  ubl2geo
% Objeto:   Convierte las coordenadas "elipsoidales" (u,beta,lambda) empleadas para definir en forma
%           cerrada el potencial a coordenadas geod�sicas (latitud,longitud y altitud elipsoidal)
% Recibe:   u(m),beta(rad),lambda(rad) y parametros del elipsoide
% Devuelve: Las coordenadas coordenadas geod�sicas lat(rad),lon(rad)y altitud elipsoidal(m)
% LLama:    ubl2tri,trigeo
% Ejemplo:  [lat,lon,hel]=ubl2geo(u,beta,lambda,elipsoide);