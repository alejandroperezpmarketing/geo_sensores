% Funcion:  ubl2tri
% Objeto:   Convierte las coordenadas "elipsoidales" (u,beta,lambda) empleadas para definir
%           en forma cerrda el potencial normal a cartesianas geoc�ntricas x,y,z
% Recibe:   coordenadas u (m), beta (rad),lambda (rad) y parametros del elipsoide
% Devuelve: Las coordenadas x, y, z
% Ejemplo:  [x,y,z]=ubl2tri(u,beta,lambda,elipsoide);