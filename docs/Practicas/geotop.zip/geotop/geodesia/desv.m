% Funcion:  desv
% Objeto:   Calcula la desviacion de la vertical en una direccion de acimut az
% Recibe:   
%           - Desviaci�n de la vertical en direccion del meridiano
%           - Desviaci�n de la vertical en direccion del primer vertical
%           - Azimut directo de la linea estacion-punto visado
% Devuelve: La desviacion de la vertical en radianes
% Ejemplo:  epsilon=desv(xi,eta,az)
