% Funcion:  claenu_error
% Objeto:   Paso de un vector geodesico expresado en coordenadas polares
%           ( observables clasicos: az,v,dg ) a coordenadas en el sistema
%           topocentrico local: ie,in,iu con propagacion de errores
%           Tambien sirve como paso de polares ( en sentido geodesico ) a
%           cartesianas tridimensionales referidas al punto estacion.
% Recibe:   Componentes clasicos: az,ce en radianes y dg en metros.
% Devuelve: Componentes ie,in,iu en metros.
% Ejemplo:  [ie,in,iu,error]=claenu_error(az,ce,dg,ni,nl,instrumentos)
