% Funcion:  rdcae
% Objeto:   Reduce una distancia de la cuerda al arco elipsoide.
% Recibe:   - Distancia cuerda, en metros.
%           - Azimut de la seccion normal, en radianes.
%           - Latitud geodesica del punto estacion, en radianes.
%           - Elipsoide:  elipsoide=[a alfa b e e'];
% Devuelve: Distancia reducida al arco elipsoide.
% Ejemplo:  dae=rdcae(dcu,az,lat1,elipsoide);
% Llamadas: rm, rn.
