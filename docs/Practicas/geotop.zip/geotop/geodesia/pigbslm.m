% Funcion:  pigbslm
% Objeto:   Resuelve el problema inverso de la geodesia sobre el elipsoide
%           por el metodo de Bessel segun modificacion a�adida por
%           David Hernandez Lopez.
% Recibe:   - Coordenadas geodesicas en radianes del punto origen y final de
%             la geodesica: Latitud y Longitud.
%             El dominio de la longitud es [0,pi] U ]-pi,0]
%           - Elipsoide de trabajo.
%             elipsoide=[a alfa b e e'];
% Devuelve: - Longitud de la linea geodesica.
%           - Azimut geodesico en el punto origen.
%           - Azimut geodesico en el punto final.
% Ejemplo:  [s12,a12,a21]=pigbslm(fi1,lon1,fi2,lon2,elipsoide);
