% Funcion:  pdgvicenty
% Objeto:   Resuelve el problema directo de la geodesia sobre el elipsoide
%           por el metodo de Vicenty (v�lido hasta 20.000 km )
% Recibe:   - Coordenadas geodesicas en radianes del punto origen de la geodesica,
%           - Longitud de la linea en metros, 
%             El dominio de la longitud es [0,pi] U ]-pi,0]
%           - Azimut geodesico de inicio en radianes y
%           - Elipsoide de trabajo:  elipsoide=[a alfa b e e'];
% Devuelve: Coordenadas geodesicas en radianes del extremo final y el acimut reciproco.
% Ejemplo:  [latj,lonj,aji]=pdgvicenty(lati,loni,sij,aij,elipsoide)