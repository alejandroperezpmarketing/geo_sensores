% Funcion:  efleutm
% Objeto:   - Paso de la elispe de error de un punto del plano tangente al elipsoide
%             en el punto a la proyeccion UTM, en el huso indicado.
% Recibe:   - Latitud geodesica del punto, en radianes.
%           - Longitud geodesica del punto, en radianes.
%           - Semieje mayor de la elipse en el plano tangente al elipsoide en el punto, en metros.
%           - Semieje menor de la elipse en el plano tangente al elipsoide en el punto, en metros.
%           - Azimut geodesico del semieje mayor de la elipse en el plano tangente al elipsoide en el punto, en radianes.
%           - Elipsoide del Sistema de Referencia Geodesico, como un vector fila:
%             elipsoide=[a alfa b e e'];
%           - huso donde se desea proyectar la figura de error. Si es 0, la calcula en el huso del punto.
% Devuelve: - Semieje mayor de la elipse de error en el plano UTM, en metros.
%           - Semieje menor de la elipse de error en el plano UTM, en metros.
%           - Azimut geodesico del semieje mayor de la elipse de error en el plano UTM, en radianes.
% Ejemplo:  [semia,semib,azia]=efleutm(cgp(i,2),cgp(i,3),semia,semib,azia,elipsoide,huso)
