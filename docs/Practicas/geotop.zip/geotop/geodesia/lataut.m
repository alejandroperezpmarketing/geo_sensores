% Funcion:  lataut
% Objeto:   Paso de latitud geodesica a autalica.
% Recibe:   - Latitud geodesica en radianes.
%           - Elipsoide de trabajo, como un vector fila de 5 columnas:
%             elipsoide=[a alfa b e e'];
% Devuelve: Latitud autalica en radianes.
% Ejemplo:  fiaut=lataut(fig,elipsoide);
