% Programa: grs80
% Objeto:   Define en memoria una variable elipsoide que incluye la
%           definicion del elipsoide del S.Referencia GRS80.
%           La variable es un vector fila con la siguiente estructura:
%           - elipsoide(1,1)=Semieje mayor.
%           - elipsoide(1,2)=Aplanamiento.
%           - elipsoide(1,3)=Semieje menor.
%           - elipsoide(1,4)=Primera excentricidad.
%           - elipsoide(1,5)=Segunda excentricidad.
%           - elipsoide(1,6)=Coeficiente J2.
%           - elipsoide(1,7)= Producto GM.
%           - elipsoide(1,8)=Velocidad angular de rotaci�n.
%           - elipsoide(1,9)= m = w2*a2*b/GM.
%           En particular, los datos conocidos para este elipsoide son:
%           - elipsoide(1,1)=6378137
%           - elipsoide(1,2)=1/298.257222
%           El resto se calculan y almacenan.
% Llamada:  grs80
