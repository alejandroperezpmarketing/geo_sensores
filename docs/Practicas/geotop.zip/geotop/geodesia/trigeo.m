% Funcion:  trigeo
% Objeto:   Paso de Coordenadas Cartesianas Tridimensionales
%           a Coordenadas Geodesicas: latitud, longitud y altitud elipsoidal.
% Recibe:   - Coordenadas Cartesianas Tridimensionales: X, Y, Z
%           - Elipsoide de trabajo.
%             elipsoide=[a alfa b e e'];
% Devuelve: - Coordenadas Geodesicas: Latitud y Longitud en radianes. 
%             El dominio de la longitud es [0,pi] U ]-pi,0]
%           - Altitud elipsoidal en metros.
% Ejemplo:  [lat,lon,h]=trigeo(X,Y,Z,elipsoide)
% Llamadas: rn.
