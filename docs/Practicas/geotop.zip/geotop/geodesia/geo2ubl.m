% Funcion:  geo2ubl
% Objeto:   Convierte las coordenadas geod�sicas (latitud,longitud y altitud elipsoidal) al sistema 
%           de coordenadas "elipsoidales" (u,beta,lambda) empleado para definir en forma cerrada el potencial
% Recibe:   latitud (rad),longitud (rad),altitud elipsoidal (m) y parametros del elipsoide
% Devuelve: Las coordenadas u,beta,lambda
% LLama:    geotri,tri2ubl
% Ejemplo:  [u,beta,lambda]=geo2ubl(lat,lon,hel,elipsoide);