% Funcion:  geotri
% Objeto:   Paso de Coordenadas Geodesicas: latitud, longitud y altitud elipsoidal
%           a Coordenadas Cartesianas Tridimensionales: X,Y,Z.
% Recibe:   - Coordenadas geodesicas del punto en radianes: latitud y longitud.
%             El dominio de la longitud es [0,pi] U ]-pi,0]
%           - Altitud elipsoidal en metros.
%           - Elipsoide de trabajo.
%             elipsoide=[a alfa b e e'];
% Devuelve: Coordenadas Cartesianas Tridimensionales en metros: ( X, Y, Z )
% Ejemplo:  [xp,yp,zp]=geotri(fip,lonp,hp,elipsoide)
