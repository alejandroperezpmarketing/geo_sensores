% Funcion:  lamlat
% Objeto:   Determinacion de la latitud geodesica en el elipsoide
%           correspondiente a una longitud de arco de meridiano dada.
% Recibe:   - Longitud de arco de meridiano en metros.
%           - Elipsoide de trabajo, como un vector fila de 5 columnas:
%             elipsoide=[a alfa b e e'];
% Devuelve: Latitud geodesica en radianes.
% Ejemplo:  fipe=lamlat(lampe,elipsoide)
