% Funcion:  pdesfcr
% Objeto:   Resuelve el problema directo de la geodesia sobre una esfera
%           utilizando el metodo de rotacion ( cambio de base ).
% Recibe:   - Coordenadas geodesicas en radianes del punto origen de la geodesica,
%             El dominio de la longitud es [0,pi] U ]-pi,0]
%           - Longitud del arco de circulo maximo en metros.
%           - Azimut geodesico de inicio en radianes.
%           - Radio de la esfera en metros.
% Devuelve: Coordenadas geodesica en radianes del extremo final.
% Ejemplo:  [fi2,lon2]=pdesfcr(fi1,lon1,s12,a12,resfera);
