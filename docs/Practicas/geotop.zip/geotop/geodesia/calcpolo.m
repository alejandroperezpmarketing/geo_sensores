% Funcion:  calcpolo
% Objeto:   Dados 3 puntos en una esfera, calcula el nuevo polo
%           tal que los tres puntos quedan en el mismo paralelo.
% Recibe:   Coordenadas geodesicas en radianes de los tres puntos:
%           latitud y longitud.
% Devuelve: - Latitud y longitud geodesica del nuevo polo en radianes
%           - La colatitud de los tres puntos respecto al nuevo polo.
%           El dominio de la longitud es [0,pi] U ]-pi,0]
% Ejemplo:  [finp,lonnp,co]=calcpolo(fi1,lon1,fi2,lon2,fi3,lon3)
