% Libreria GeoTop: 	Geodesia.
%
%Areaelip.  - c�lculo del �rea de un recinto sobre el elipsoide, limitado por arcos de 
%             meridiano y paralelo.
%Autlat.    - paso de latitud aut�lica a geod�sica.
%Calcpolo.  - c�lculo del polo de la esfera, a partir de tres puntos no alineados de la misma, de forma que
%             pasen a estar en un mismo paralelo tras realizarse el cambio de polo.
%Claenu.    - paso de un vector geod�sico, expresado en componentes polares ( observables cl�sicos ), 
%             a componentes ENU.
%Clhapv.    - lectura horizontal corregida por altitud del punto visado.
%Clhsnlg.   - lectura horizontal corregida por paso de la secci�n normal a la l�nea geod�sica.
%Crelat.    - paso de latitud creciente a geod�sica.
%Edhclagt.  - c�lculo de la previsi�n de error propagado a un desnivel elipsoidal, obtenido por observaci�n 
%             cl�sica aplicando geodesia tridimensional.
%Efleutm.   - paso de la elipse de error de un punto del plano tangente al elipsoide al plano de la proyecci�n UTM.
%Elipesf.   - determinaci�n de la esfera tangente al elipsoide en un paralelo indicado.
%Enucla.    - paso de un vector geod�sico, expresado en componentes ENU, a componentes polares 
%             ( observables cl�sicos ).
%Enuxyz.    - paso de un vector geod�sico, expresado en componentes ENU, a componentes cartesianas tridimensionales.
%Eta_ed50.  - componente de la desviaci�n relativa de la vertical en Ed50 seg�n la direcci�n del primer vertical.
%Geotri.    - paso de coordenadas geodesicas a cartesianas tridimensionales, para un punto y elipsoide determinados.
%Hayford.   - definici�n de una variable con la geometr�a del elipsoide internacional de Hayford, 1924.
%Lam.       - c�lculo de la longitud de arco de meridiano a partir de la latitud geod�sica y del elipsoide.
%Lamlat.    - c�lculo de la latitud geod�sica que le corresponde a una determinada longitud de arco de meridiano 
%             en el elipsoide indicado.
%Lataut.    - paso de latitud geod�sica a aut�lica.
%Latcre.    - paso de latitud geod�sica a creciente.
%Ond_ed50.  - c�lculo de la ondulaci�n del geoide de un punto en Ed50.
%Pdesfcr.   - problema directo en la esfera con el m�todo de cambio de base.
%Pdg_dif1.  - problema directo de la geodesia con la primera derivada.
%Pdg_dif2.  - problema directo de la geodesia con la primera y segunda derivada.
%Pdg_dif3.  - problema directo de la geodesia con la primera, segunda y tercera derivada.
%Pdgrk4o.   - problema directo de la geodesia seg�n m�todo de integraci�n num�rica de Runge-Kutta de cuarto orden.
%Piesfcr.   - problema inverso en la esfera con el m�todo de cambio de base.
%Pigbsl.    - problema inverso de la geodesia seg�n el m�todo de Bessel.
%Pigbslm.   - problema inverso de la geodesia seg�n el m�todo de Bessel modificado por el autor de este proyecto 
%             docente.
%Pi_loxod.  - problema inverso para la curva loxodr�mica.
%Psi_ed50.  - componente de la desviaci�n relativa de la vertical en Ed50 seg�n la direcci�n del meridiano.
%Rdcae.     - reducci�n de la distacia de la cuerda al arco elipsoide.
%Rdtce.     - reducci�n de la distancia del terreno a la cuerda elipsoide.
%Reuler.    - radio de la secci�n normal de un determinado acimut, a partir del teorema de Euler.
%Rm.        - radio de curvatura de la elipse meridiana, en un punto y elipsoide determinados..
%Rn.        - radio de curvatura del primer vertical, en un punto y elipsoide determinados.
%Struve.    - definici�n de una variable con la geometr�a del elipsoide de Struve.
%Trigeo.    - paso de coordenadas cartesianas tridimensionales a geod�sicas, en un punto y elipsoide determinados.
%Wgs84.     - definici�n de una variable con la geometr�a del elipsoide del WGS84.
%Xyzclae.   - Paso de un vector geod�sico, expresado en componentes cartesianas tridimensionales, a observables 
%             cl�sicos sobre el elipsoide y desnivel elipsoidal.
%Xyzclat.   - Paso de un vector geod�sico, expresado en componentes cartesianas tridimensionales, a componentes
%             polares en el terreno.
%Xyzenu.    - Paso de un vector geod�sico, expresado en componentes cartesianas tridimensionales, a componentes ENU.
