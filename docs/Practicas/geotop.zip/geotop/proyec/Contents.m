% Libreria GeoTop: 	Proyec
%
%Calhuso.  - c�lculo del huso correspondiente a un punto en la proyecci�n 
%            UTM a partir de su longitud geod�sica.
%Cdelgeo.  - paso de un punto, de la proyecci�n cil�ndrica directa equivalente
%            de Lambert, al elipsoide.
%Convestp. - c�lculo de la convergencia de meridianos de un punto de la esfera,
%            en la proyecci�n estereogr�fica polar.
%Convgk.   - c�lculo de la convergencia de meridianos de un punto del elipsoide,
%            en la proyecci�n general de Gauss-Kr�ger.
%Convlamb. - c�lculo de la convergencia de meridianos de un punto del elipsoide,
%            en la proyecci�n general c�nica conforme de Lambert.
%Convutm.  - c�lculo de la convergencia de meridianos de un punto del elipsoide,
%            en la proyecci�n UTM, calculada en el huso que le corresponde al 
%            punto por su longitud geod�sica.
%Convutmh. - c�lculo de la convergencia de meridianos de un punto del elipsoide,
%            en la proyecci�n UTM, calculada en el huso indicado.
%Dcdgputm. - paso de la distancia cuerda en la proyecci�n UTM, entre dos puntos, 
%            a la correspondiente a la proyecci�n UTM de la l�nea ge�desica, 
%            que los une en el elipsoide.
%Dcesfera. - c�lculo de la reducci�n angular de la cuerda, en el extremo inicial
%            de una geod�sica en el elipsoide, al pasar a la proyecci�n general 
%            conforme en una esfera.
%Dcestp.   - c�lculo de la reducci�n angular de la cuerda, en el extremo inicial
%            de una geod�sica en la esfera, al pasar a la proyecci�n 
%            estereogr�fica polar.
%Dcgk.     - c�lculo de la reducci�n angular de la cuerda, en el extremo inicial
%            de una geod�sica en el elipsoide, al pasar a la proyecci�n general
%            de Gauss-Kr�ger.
%Dclamb.   - c�lculo de la reducci�n angular de la cuerda, en el extremo inicial 
%            de una geod�sica en el elipsoide, al pasar a la proyecci�n general
%            c�nica conforme de Lambert.
%Dclambf.  - c�lculo de la reducci�n angular de la cuerda, en el extremo inicial
%            de una geod�sica en el elipsoide, al pasar a la proyecci�n general
%            c�nica conforme de Lambert, con m�s precisi�n que la funci�n anterior.
%Dcutm.    - c�lculo de la reducci�n angular de la cuerda, en el extremo inicial 
%            de una geod�sica en el elipsoide, al pasar a la proyecci�n UTM, 
%            calculada en el huso que le corresponde al punto por su longitud 
%            geod�sica.
%Dcutmh.   - c�lculo de la reducci�n angular de la cuerda, en el extremo inicial 
%            de una geod�sica en el elipsoide, al pasar a la proyecci�n UTM, 
%            calculada en el huso indicado.
%Dgpdcutm. - paso de la distancia geod�sica proyectada, en el plano UTM, 
%            a la distancia correspondient a la cuerda en esta proyecci�n, 
%            para una geod�sica del elipsoide.
%Esfesfg.  - paso de un punto, de una esfera, a la esfera con cambio de polo. 
%            Tambi�n se calcula el giro de los c�rculos m�ximos, motivado por
%            el cambio de polo.
%Esfgesf.  - paso de un punto, de la esfera con cambio de polo, a la esfera 
%            original. Tambi�n se calcula el giro de los c�rculos m�ximos, 
%            motivado por el cambio de polo.
%Estpgeoe. - paso de un punto, de la proyecci�n estereogr�fica polar, a la esfera.
%Geocdel.  - paso de un punto, del elipsoide, a la proyecci�n cil�ndrica directa 
%            equivalente de Lambert.
%Geoestpe. - paso de un punto, de la esfera, a la proyecci�n estereogr�fica polar.
%Geogk.    - paso de un punto, del elipsoide, a la proyecci�n general de Gauss-Kr�ger.
%Geolamb.  - paso de un punto, del elipsoide, a la proyecci�n general c�nica conforme
%            de Lambert.
%Geomerc.  - paso de un punto, del elipsoide, a la proyecci�n de Mercator.
%Geoutm.   - paso de un punto, del elipsoide, a la proyecci�n UTM, en el huso que 
%            le corresponde al punto por su longitud geod�sica.
%Geoutmh.  - paso de un punto, del elipsoide, a la proyecci�n UTM, en el huso indicado.
%Gkgeo.    - paso de un punto, de la proyecci�n general de Gauss-Kr�ger, al elipsoide.
%Kdesfera. - c�lculo del coeficiente de anamorfosis lineal, a aplicar a una geod�sica
%            del elipsoide, al proyectarla en la proyecci�n general conforme sobre una
%            esfera. Utiliza la integraci�n num�rica de Simpson.
%Kdestp.   - c�lculo del coeficiente de anamorfosis lineal, a aplicar a una geod�sica
%            de la esfera, al proyectarla en la proyecci�n estereogr�fica polar. 
%            Utiliza la integraci�n num�rica de Simpson.
%Kdgk.     - c�lculo del coeficiente de anamorfosis lineal, a aplicar a una geod�sica
%            del elipsoide, al proyectarla en la proyecci�n general de Gauss-Kr�ger.
%            Utiliza la integraci�n num�rica de Simpson.
%Kdlamb.   - c�lculo del coeficiente de anamorfosis lineal, a aplicar a una geod�sica 
%            del elipsoide, al proyectarla en la proyecci�n general c�nica conforme de
%            Lambert. Utiliza la integraci�n num�rica de Simpson.
%Kdutm.    - c�lculo del coeficiente de anamorfosis lineal, a aplicar a una geod�sica 
%            del elipsoide, al proyectarla en la proyecci�n UTM, en el huso del primer
%            punto. Utiliza la integraci�n num�rica de Simpson.
%Kdutmh.   - c�lculo del coeficiente de anamorfosis lineal, a aplicar a una geod�sica
%            del elipsoide, al proyectarla en la proyecci�n UTM, en el huso indicado.
%            Utiliza la integraci�n num�rica de Simpson.
%Kpesfera. - c�lculo del coeficiente de anamorfosis lineal puntual, para un punto del
%            elipsoide, en la proyecci�n general conforme sobre una esfera.
%Kpestp.   - c�lculo del coeficiente de anamorfosis lineal puntual, para un punto de
%            la esfera, en la proyecci�n estereogr�fica polar.
%Kpgk.     - c�lculo del coeficiente de anamorfosis lineal puntual, para un punto del
%            elipsoide, en la proyecci�n general de Gauss-Kr�ger.
%Kplamb.   - c�lculo del coeficiente de anamorfosis lineal puntual, para un punto del
%            elipsoide, en la proyecci�n general c�nica conforme de Lambert.
%Kputm.    - c�lculo del coeficiente de anamorfosis lineal puntual, para un punto del
%            elipsoide, en la proyecci�n UTM, en el huso que le corresponde al punto
%            por su longitud geod�sica.
%Kputmh.   - c�lculo del coeficiente de anamorfosis lineal puntual, para un punto del
%            elipsoide, en la proyecci�n UTM, en el huso indicado.
%Lambgeo.  - paso de un punto, de la proyecci�n general c�nica conforme de Lambert, 
%            al elipsoide.
%Latelesc. - paso de la latitud geod�sica, sobre el elipsoide, a la correspondiente
%            sobre la esfera, seg�n la proyecci�n general conforme sobre la esfera.
%Lateselc. - paso de latitud, sobre la esfera, a la correspondiente sobre el elipsoide,
%            seg�n la proyecci�n general conforme sobre la esfera.
%Mercgeo.  - paso de un punto, de la proyecci�n de Mercator, al elipsoide.
%Utmgeo.   - paso de un punto, de la proyecci�n UTM, al elipsoide.
