% Funcion:  geolamb
% Objeto:   Paso de coordenadas geodesicas a coordenadas planas en
%           la Proyeccion Conica Conforme de Lambert.
% Recibe:   - Coordenadas geodesicas del punto, en radianes:
%             Latitud y longitud.
%             El dominio de la longitud es [0,pi] U ]-pi,0]
%           - Latitud del paralelo fundamental de la proyeccion, en radianes.
%           - Longitud del meridiano origen, en radianes.
%           - Coeficiente del Artificio de Tissot ( enviando 1 si no se desea aplicar ).
%           - Traslaciones, Tx, Ty, a aplicar a las coordenadas, en metros.�
%           - Elipsoide de trabajo.
%             elipsoide=[a alfa b e e'];
% Devuelve: Coordenadas planas en metros.
% Ejemplo:  [xp,yp]=geolamb(fip,lonp, fi0,lon0,p,tx,ty,elipsoide);
