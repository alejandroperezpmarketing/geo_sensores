% Funcion:  mercgeo
% Objeto:   Paso de coordenadas planas en la Proyeccion de Mercator a
%           coordenadas geodesicas sobre el elipsoide.
% Recibe:   - Coordenadas planas en la proyeccion, en metros: X, Y.
%           - Longitud del meridiano origen de la proyeccion, en radianes.
%             El dominio de la longitud es [0,pi] U ]-pi,0]
%           - Traslaciones, Tx, Ty, en metros.
%           - Elipsoide de trabajo: elipsoide=[a alfa b e e'];
% Devuelve: Coordenadas geodesicas, en radianes: Latitud y longitud.
% Ejemplo:  [fip,lonp]=mercgeo(x,y,lon0,tx,ty,elipsoide);
