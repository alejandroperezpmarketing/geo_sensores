% Funcion:  esfesfg
% Objeto:   Paso de un punto en una esfera a la esfera girada con nuevo polo.
% Recibe:   Coordenadas geodesicas sobre la esfera del punto y las del nuevo
%           polo, en radianes.
% Devuelve: - Coordenadas geodesicas en la esfera girada, en radianes:
%             Latitud y longitud.
%             El dominio de la longitud es [0,pi] U ]-pi,0]
%           - Angulo de giro de las geodesicas, en radianes.
% Ejemplo:  [fin,lonn,g]=esfesfg(fi,lon,fip,lonp);
