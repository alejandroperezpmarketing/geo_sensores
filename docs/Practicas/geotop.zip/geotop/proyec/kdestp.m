% Funcion:  kdestp
% Objeto:   Calcula el modulo de deformacion lineal a aplicar a una distancia para
%           proyectarla de la esfera a la Proyeccion Estereografia Polar.
%           Utiliza la integracion numerica de Simpson.
% Recibe:   - Coordenadas geodesicas de los dos puntos, en radianes:
%             Latitud y longitud.
%             El dominio de la longitud es [0,pi] U ]-pi,0]
%           - Longitud del meridiano origen de la proyeccion, en radianes.
%           - Radio de la esfera, en metros.
%           - Traslaciones, Tx, Ty, en metros.
% Devuelve: El modulo de deformacion lineal de la distancia.
% Ejemplo:  kd=kdestp(fi1,l1,fi2,l2,l0,radio,tx,ty);
