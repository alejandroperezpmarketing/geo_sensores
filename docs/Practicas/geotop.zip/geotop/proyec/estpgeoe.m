% Funcion:  estpgeoe
% Objeto:   Paso de coordenadas planas en la Proyeccion Estereografia Polar
%           a Geodesicas sobre la esfera.
% Recibe:   - Coordenadas X, Y, en metros.
%           - Longitud geodesica origen de la proyeccion, en radianes.
%             El dominio de la longitud es [0,pi] U ]-pi,0]
%           - Radio de la esfera, en metros.
%           - Traslaciones, tx, ty, de la proyeccion, en metros.
% Devuelve: Latitud y longitud geodesicas en radianes.
%           El dominio de la longitud es [0,pi] U ]-pi,0]
% Ejemplo:  [fip,lonp]=estpgeoe(xp,yp,lon0,radio,tx,ty);
