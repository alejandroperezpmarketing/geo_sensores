% Funcion:  dcgk
% Objeto:   Calcula la reduccion angular de la cuerda en la Proyeccion Gauss-Kruger.
%           El numero de terminos considerado en el desarrollo es tal que se
%           garantiza la precision del mm. para un incremento de longitud respecto
%           al meridiano central donde se incluye a los puntos de 7.5 g.sexa.
%           Contempla la posibilidad de que la cuerda corte el meridiano central.
%           El signo obtenido es tal que:
%           Lhz_utm=Lhz_elipsoide-dc.
%           Lhz_elipsoide=Lhz_utm+dc.
% Recibe:   - Coordenadas geodesicas de los dos puntos en radianes: latitud y longitud.
%             El dominio de la longitud es [0,pi] U ]-pi,0]
%           - Longitud geodesica del meridiano origen, en radianes.
%           - Coeficiente, p del Artificio de Tissot.
%             Si no se aplica se debe enviar 1.
%           - Elipsoide de trabajo.
%             elipsoide=[a alfa b e e'];
% Devuelve: La reduccion angular de la cuerda en radianes.
% Ejemplo:  dc=dcgk(fi1,l1,fi2,l2,lon0,p,elipsoide);
