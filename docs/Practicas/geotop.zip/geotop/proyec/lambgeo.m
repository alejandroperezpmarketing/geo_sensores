% Funcion:  lambgeo
% Objeto:   Paso de coordenadas en la Proyeccion Conica Conforme de Lambert
%           a coordenadas geodesicas sobre el elipsoide.
% Recibe:   - Coordenadas planas en la proyeccion, en metros.
%           - Latitud del paralelo fundamental de la proyeccion, en radianes.
%           - Longitud del meridiano origen, en radianes.
%             El dominio de la longitud es [0,pi] U ]-pi,0]
%           - Coeficiente del Artificio de Tissot ( enviando 1 si no se desea aplicar ),
%           - Traslaciones, Tx, Ty, en metros.
%           - Elipsoide de trabajo:  elipsoide=[a alfa b e e'];
% Devuelve: Coordenadas geodesicas, en radianes: Latitud, longitud.
% Ejemplo:  [fi,lon]=lambgeo(x,y,fi0,l0,p,tx,ty,elipsoide);
