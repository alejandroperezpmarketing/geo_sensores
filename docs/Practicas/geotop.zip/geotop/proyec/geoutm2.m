% Funcion:  geoutm2
% Objeto:   Paso de coordenadas geodesicas a coordenadas planas en
%           la Proyeccion Universal Transversa de Mercator, UTM.
% Recibe:   - Coordenadas geodesicas del punto, en radianes:
%             Latitud y longitud.
%             El dominio de la longitud es [0,pi] U ]-pi,0]
%           - Elipsoide de trabajo.
%             elipsoide=[a alfa b e e'];
% Devuelve: Coordenadas planas en metros junto con el huso que oficialmente le corresponde.
% Ejemplo:  [xp,yp,huso]=geoutm2(lat,lon,elipsoide);
