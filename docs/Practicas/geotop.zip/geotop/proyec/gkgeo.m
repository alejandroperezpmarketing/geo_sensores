% Funcion:  gkgeo
% Objeto:   Paso de coordenadas en la Proyeccion Gauss-Kruger a geodesicas.
% Recibe:   - Coordenadas en la Proyeccion Gauss-Kruger, en metros: X, Y.
%           - Longitud del meridiano origen, en radianes.
%           - Coeficiente p del Artificio de Tissot.
%             Si no se ha aplicado sobre las coordenadas se debe enviar 1.
%           - Traslaciones en X, Y que han afectado a las coordenadas.
%           - Elipsoide de trabajo.
%             elipsoide=[a alfa b e e'];
% Devuelve: Coordenadas geodesicas en radianes.
%           El dominio de la longitud es [0,pi] U ]-pi,0]
% Ejemplo:  [fip,lonp]=gkgeo(xp,yp,lon0,p,tx,ty,elipsoide)
