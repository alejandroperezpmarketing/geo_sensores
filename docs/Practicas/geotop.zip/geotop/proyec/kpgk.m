% Funcion:  kpgk
% Objeto:   Calcula el modulo de deformacion lineal puntual
%           para la Proyeccion Gauss-Kruger.
% Recibe:   - Coordenadas geodesicas del punto, en radianes:
%             Latitud y longitud.
%             El dominio de la longitud es [0,pi] U ]-pi,0]
%           - Longitud geodesica del meridiano origen, en radianes.
%           - Coeficiente, p del Artificio de Tissot.
%             Si no se aplica se debe enviar 1.
%           - Elipsoide de trabajo.
%             elipsoide=[a alfa b e e'];
% Devuelve: El modulo de deformacion puntual.
% Ejemplo:  kp=kpgk(fi1,l1,lon0,p,elipsoide);
