% Funcion:  dgpdcutm
% Objeto:   Calcula la correccion para pasar de la distancia geodesica
%           proyectada en UTM a la distancia de la cuerda sobre la proyeccion.
%           Calcula en el huso del primer punto.
% Recibe:   - Coordenadas geodesicas de los dos puntos, en radianes:
%             Latitud y longitud.
%           - Longitud de la linea geodesica.
%           - Elipsoide de trabajo.
%             elipsoide=[a alfa b e e'];
%           El dominio de la longitud es [0,pi] U ]-pi,0]
% Devuelve: La correccion en metros.
% Ejemplo:  cdcdg=dgpdcutm(fi1,lon1,fi2,lon2,elipsoide);
