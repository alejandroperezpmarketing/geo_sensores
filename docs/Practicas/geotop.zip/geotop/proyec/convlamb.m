% Funcion:  convlamb
% Objeto:   Determina la convergencia de meridianos de un punto proyectado
%           del elipsoide a la Proyeccion Conica Conforme de Lambert.
% Recibe:   - Longitud geodesica del punto, en radianes.
%             El dominio de la longitud es [0,pi] U ]-pi,0]
%           - Latitud del paralelo fundamental de la proyeccion en radianes,
%           - Longitud del meridiano origen de la proyeccion en radianes.
% Devuelve: La convergencia de meridianos en radianes.
% Ejemplo:  convp=convlamb(l,fi0,l0);
