% Funcion:  geoestpe
% Objeto:   Paso de coordenadas geodesicas en la esfera a las planas en la
%           Proyeccion Estereografia Polar.
% Recibe:   - Coordenadas geodesicas, en radianes: Latitud y longitud.
%             El dominio de la longitud es [0,pi] U ]-pi,0]
%           - Longitud geodesica origen de la proyeccion, en radianes.
%           - Radio de la esfera, en metros.
%           - Traslaciones, tx, ty, de la proyeccion, en metros.
% Devuelve: Coordenadas planas en la proyeccion, en metros.
% Ejemplo:  [X,Y]=geoestpe(fi,lon,lon0,radio,tx,ty);
