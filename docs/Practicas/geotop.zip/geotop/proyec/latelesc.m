% Funcion:  latelesc
% Objeto:   Paso de latitud elipsodica a esferica segun proyeccion conforme entre
%           ambas superficies, considerandolas tangentes en un paralelo de latitud fi0.
% Recibe:   - Latitud geodesica sobre el elipsoide, en radianes.
%           - Latitud del paralelo fundamental de tangencia, en radianes.
%           - Elipsoide de trabajo:  elipsoide=[a alfa b e e'];
% Devuelve: Latitud sobre la esfera en radianes.
% Ejemplo:  latesf=latelesc(latelip,fi0,elipsoide);
