% Funcion:  utmgeo
% Objeto:   Paso de coordenadas en la Proyeccion UTM a geodesicas.
% Recibe:   - Coordenadas en la Proyeccion UTM, en metros: X, Y.
%           - Numero de huso.
%           - Elipsoide de trabajo.
%             elipsoide=[a alfa b e e'];
% Devuelve: Coordenadas geodesicas en radianes.
%           El dominio de la longitud es [0,pi] U ]-pi,0]
% Ejemplo:  [fip,lonp]=utmgeo(xp,yp,husop,elipsoide)
