% Funcion:  dcesfera
% Objeto:   Calcula la reduccion angular de la cuerda en la Proyeccion Conforme
%           del elipsoide sobre la esfera tangente en un paralelo de latitud fi0.
%           El signo obtenido es tal que:
%           Lhz_esfera=Lhz_elipsoide+dc.
%           Lhz_elipsoide=Lhz_esfera-dc.
% Recibe:   - Coordenadas geodesicas de los dos puntos, en radianes:
%             Latitud y longitud.
%             El dominio de la longitud es [0,pi] U ]-pi,0]
%           - Latitud geodesica del paralelo de tangencia, en radianes.
%           - Elipsoide de trabajo.
%             elipsoide=[a alfa b e e'];
% Devuelve: La reduccion angular de la cuerda en radianes.
% Ejemplo:  dc=dcesfera(fi1,lon1,fi2,lon2,fi0,elipsoide);
