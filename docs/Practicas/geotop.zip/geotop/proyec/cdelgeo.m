% Funcion:  cdelgeo
% Objeto:   Paso de coordenadas planas en la proyeccion Cilindrica
%           Directa Equivalente de Lambert a Geodesicas.
% Recibe:   - Coordenadas X, Y, en metros.
%           - Longitud geodesica origen.
%             El dominio de la longitud es [0,pi] U ]-pi,0]
%           - Traslaciones aplicadas en las coordenadas planas, en metros.
%           - Elipsoide de trabajo.
%             elipsoide=[a alfa b e e'];
% Devuelve: Latitud y longitud geodesicas en radianes.
% Ejemplo:  [fip,lonp]=cdelgeo(xp,yp,lon0,elipsoide);
