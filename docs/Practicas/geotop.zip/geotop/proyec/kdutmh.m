% Funcion:  kdutmh
% Objeto:   Calcula el modulo de deformacion lineal a aplicar a una distancia para
%           proyectarla del elipsoide a la Proyeccion UTM.
%           Lo determina en el huso indicado.
%           El numero de terminos considerado en el desarrollo es tal que se
%           garantiza la precision del mm. para un incremento de longitud respecto
%           al meridiano central del huso donde se incluye a los puntos de 7.5 g.sexa.
%           Utiliza la integracion numerica de Simpson.
% Recibe:   - Coordenadas geodesicas de los dos puntos, en radianes:
%             Latitud y longitud.
%             El dominio de la longitud es [0,pi] U ]-pi,0]
%           - Elipsoide de trabajo.
%             elipsoide=[a alfa b e e'];
% Devuelve: El modulo de deformacion lineal de la distancia.
% Ejemplo:  kd=kdutmh(fi1,l1,fi2,l2,huso,elipsoide);
