% Funcion:  convestp
% Objeto:   Determina la convergencia de meridianos de un punto proyectado
%           del elipsoide a la Proyeccion Estereografica Polar.
% Recibe:   - Longitud geodesica y origen de la proyeccion en radianes.
%             El dominio de la longitud es [0,pi] U ]-pi,0]
% Devuelve: La convergencia de meridianos en radianes.
% Ejemplo:  convp=convestp(lp,l0);
