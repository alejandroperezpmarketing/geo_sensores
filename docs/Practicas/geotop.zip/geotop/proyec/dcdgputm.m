% Funcion:  dcdgputm
% Objeto:   Calcula la correccion para pasar de la distancia cuerda
%           entre dos puntos en la Proyeccion UTM a la distancia de la
%           geodesica proyectada.
%           Calcula en el huso del primer punto.
% Recibe:   - Coordenadas geodesicas de los dos puntos en radianes:
%             Latitud y Longitud.
%             El dominio de la longitud es [0,pi] U ]-pi,0]
%           - Elipsoide de trabajo.
%             elipsoide=[a alfa b e e'];
% Devuelve: La correccion en metros.
% Ejemplo:  cdcdg=dcdgputm(fi1,lon1,fi2,lon2,elipsoide);
