% Funcion:  calhuso
% Objeto:   Determina el huso de la proyeccion UTM de un punto.
% Recibe:   Longitud geodesicas en radianes del punto.
%           El dominio de la longitud es [0,pi] U ]-pi,0]
% Devuelve: El numero de huso.
% Ejemplo:  nhusop=calhuso(lon)
