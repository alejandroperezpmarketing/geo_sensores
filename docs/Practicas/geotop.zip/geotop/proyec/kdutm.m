% Funcion:  kdutm
% Objeto:   Calcula el modulo de deformacion lineal a aplicar a una distancia para
%           proyectarla del elipsoide a la Proyeccion UTM.
%           Lo determina en el huso del primer punto.
%           Utiliza la integracion numerica de Simpson.
% Recibe:   - Coordenadas geodesicas de los dos puntos, en radianes:
%             Latitud y longitud.
%             El dominio de la longitud es [0,pi] U ]-pi,0]
%           - Elipsoide de trabajo.
%             elipsoide=[a alfa b e e'];
% Devuelve: El modulo de deformacion lineal de la distancia.
% Ejemplo:  kd=kdutm(fi1,l1,fi2,l2,elipsoide);
