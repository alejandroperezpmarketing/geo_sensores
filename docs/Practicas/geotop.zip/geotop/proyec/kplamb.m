% Funcion:  kplamb
% Objeto:   Calcula el modulo de deformacion lineal puntual en la Proyeccion
%           Conica Conforme de Lambert.
% Recibe:   - Latitud geodesica del punto, en radianes: Latitud y longitud.
%           - Latitud geodesica del paralelo fundamental de la proyeccion, en radianes.
%           - Coeficiente del artificio de Tissot ( 1, si no se aplica )
%           - Elipsoide de trabajo.
%             elipsoide=[a alfa b e e'];
% Devuelve: El modulo de deformacion puntual.
% Ejemplo:  kp=kplamb(fi1,fi0,p,elipsoide);
