% Funcion:  kputmh
% Objeto:   Calcula el modulo de deformacion lineal puntual
%           para la Proyeccion UTM.
%           Lo determina en el huso indicado.
%           El numero de terminos considerado en el desarrollo es tal que se
%           garantiza la precision del mm. para un incremento de longitud respecto
%           al meridiano central del huso donde se incluye al punto de 7.5 g.sexa.
% Recibe:   - Coordenadas geodesicas del punto, en radianes: latitud y longitud.
%             El dominio de la longitud es [0,pi] U ]-pi,0]
%           - Huso donde se desea determinar el modulo.
%           - Elipsoide de trabajo.
%             elipsoide=[a alfa b e e'];
% Devuelve: El modulo de deformacion puntual.
% Ejemplo:  kp=kputmh(fi1,l1,huso,elipsoide);
