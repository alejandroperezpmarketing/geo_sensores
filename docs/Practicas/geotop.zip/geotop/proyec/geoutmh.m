% Funcion:  geoutmh
% Objeto:   Paso de coordenadas geodesicas a coordenadas planas en
%           la Proyeccion Universal Transversa de Mercator, UTM, 
%           indicando el huso donde se desea calcular el punto.
%           Esta funcion permite obtener las coordenadas de un punto que esta,
%           por ejemplo, en el huso 31, en el huso 30.
%           El numero de terminos considerado en el desarrollo es tal que se
%           garantiza la precision del mm. para un incremento de longitud respecto
%           al meridiano central del huso donde se incluye al punto de 7.5 g.sexa.
% Recibe:   - Coordenadas geodesicas del punto en radianes: latitud y longitud.
%             El dominio de la longitud es [0,pi] U ]-pi,0]
%           - Numero de huso.
%           - Elipsoide de trabajo.
%             elipsoide=[a alfa b e e'];
% Devuelve: Coordenadas planas en metros.
% Ejemplo:  [xp,yp]=geoutmh(fip,lonp,huso,elipsoide)
