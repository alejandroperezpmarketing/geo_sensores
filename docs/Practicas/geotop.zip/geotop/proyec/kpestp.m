% Funcion:  kpestp
% Objeto:   Calcula el modulo de deformacion lineal puntual
%           para la Proyeccion Estereografia Polar de la esfera.
% Recibe:   - Latitud geodesica del punto, en radianes.
% Devuelve: El modulo de deformacion lineal puntual.
% Ejemplo:  kp=kpestp(fi1);
