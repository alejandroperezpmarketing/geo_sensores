% Funcion:  convgk
% Objeto:   Determina la convergencia de meridianos de un punto proyectado
%           del elipsoide a la Proyeccion Gauss-Kruger.
%           Incluye un numero de terminos del desarrollo en serie tal que
%           permite incluir puntos con un incremento de longitud respecto
%           al meridiano central indicado de 7.5 grados sexagesimales.
% Recibe:   - Coordenadas geodesicas del punto en radianes: Laitud y longitud.
%             El dominio de la longitud es [0,pi] U ]-pi,0]
%           - Longitud geodesica del meridiano origen, en radianes.
%           - Elipsoide de trabajo.
%             elipsoide=[a alfa b e e'];
% Devuelve: La convergencia de meridianos en radianes.
% Ejemplo:  convp=convgk(fi,l,lon0,elipsoide);
