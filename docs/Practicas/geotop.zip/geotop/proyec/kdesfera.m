% Funcion:  kdesfera
% Objeto:   Calcula el modulo de deformacion lineal a aplicar a una distancia para
%           proyectarla del elipsoide a la esfera tangente al mismo en el paralelo
%           de latitud fi0, segun proyeccion conforme.
%           Utiliza la integracion numerica de Simpson.
% Recibe:   - Coordenadas geodesicas de los dos puntos, en radianes:
%             Latitud y longitud.
%             El dominio de la longitud es [0,pi] U ]-pi,0]
%           - Latitud geodesica del paralelo de tangencia, en radianes.
%           - Elipsoide de trabajo.
%             elipsoide=[a alfa b e e'];
% Devuelve: El modulo de deformacion lineal de la distancia.
% Ejemplo:  kd=kdesfera(fi1,lon1,fi2,lon2,fi0,elipsoide);
