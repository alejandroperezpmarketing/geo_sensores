% Funcion:  convutmh
% Objeto:   Determina la convergencia de meridianos de un punto proyectado
%           del elipsoide a la Proyeccion UTM, en el huso indicado.
%           Incluye un numero de terminos del desarrollo en serie tal que
%           permite incluir puntos con un incremento de longitud respecto
%           al meridiano central del huso indicado de 7.5 grados sexagesimales.
% Recibe:   - Coordenadas geodesicas del punto en radianes: Laitud y longitud.
%             El dominio de la longitud es [0,pi] U ]-pi,0]
%           - Numero de Huso.
%           - Elipsoide de trabajo.
%             elipsoide=[a alfa b e e'];
% Devuelve: La convergencia de meridianos en radianes.
% Ejemplo:  convp=convutmh(fi,l,huso,elipsoide);
