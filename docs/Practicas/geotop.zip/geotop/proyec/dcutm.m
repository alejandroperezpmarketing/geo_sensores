% Funcion:  dcutm
% Objeto:   Calcula la reduccion angular de la cuerda en la Proyeccion UTM.
%           Calcula en el huso del primer punto.
%           Contempla la posibilidad de que la cuerda corte el meridiano central.
%           El signo obtenido es tal que:
%           Lhz_utm=Lhz_elipsoide-dc.
%           Lhz_elipsoide=Lhz_utm+dc.
% Recibe:   - Coordenadas geodesicas de los dos puntos, en radianes:
%             Latitud y longitud.
%             El dominio de la longitud es [0,pi] U ]-pi,0]
%           - Elipsoide de trabajo.
%             elipsoide=[a alfa b e e'];
% Devuelve: La reduccion angular de la cuerda en radianes.
% Ejemplo:  dc=dcutm(fi1,l1,fi2,l2,elipsoide);
