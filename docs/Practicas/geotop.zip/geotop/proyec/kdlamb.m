% Funcion:  kdlamb
% Objeto:   Calcula el modulo de deformacion lineal a aplicar a una distancia para
%           proyectarla del elipsoide a la Proyeccion Conica Conforme de Lambert.
%           Utiliza la integracion numerica de Simpson.
% Recibe:   - Coordenadas geodesicas de los dos puntos, en radianes:
%             Latitud y longitud.
%             El dominio de la longitud es [0,pi] U ]-pi,0]
%           - Latitud geodesica del paralelo fundamental de la proyeccion, en radianes.
%           - Longitud del meridiano origen de la proyeccion, en radianes.
%           - Coeficiente del artificio de Tissot ( 1, si no se aplica ).
%           - Traslaciones, tx,ty, en metros.
%           - Elipsoide de trabajo.
%             elipsoide=[a alfa b e e'];
% Devuelve: El modulo de deformacion lineal de la distancia.
% Ejemplo:  kd=kdlamb(fi1,l1,fi2,l2,fi0,l0,p,elipsoide);
