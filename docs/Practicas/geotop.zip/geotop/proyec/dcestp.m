% Funcion:  dcestp
% Objeto:   Calcula la reduccion angular de la cuerda en la Proyeccion
%           Estereografica Polar.
%           El signo obtenido es tal que:
%           Lhz_estp=Lhz_esfera+dc.
%           Lhz_esfera=Lhz_estp-dc.
% Recibe:   - Coordenadas geodesicas de los dos puntos, en radianes:
%             Latitud y longitud.
%             El dominio de la longitud es [0,pi] U ]-pi,0]
%           - Radio de la esfera.
% Devuelve: La reduccion angular de la cuerda en radianes.
% Ejemplo:  dc=dcestp(fi1,l1,fi2,l2,radio);
