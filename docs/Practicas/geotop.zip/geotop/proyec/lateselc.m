% Funcion:  lateselc
% Objeto:   Paso de latitud esferica a elipsodica segun proyeccion conforme entre
%           ambas superficies, considerandolas tangentes en un paralelo de latitud fi0.
% Recibe:   - Latitud geodesica sobre la esfera, en radianes.
%           - Latitud del paralelo fundamental de tangencia, en radianes.
%           - Elipsoide de trabajo:  elipsoide=[a alfa b e e'];
% Devuelve: Latitud geodesica sobre el elipsoide, en radianes.
% Ejemplo:  latelip=lateselc(latesf,fi0,elipsoide);
