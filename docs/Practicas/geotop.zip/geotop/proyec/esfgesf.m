% Funcion:  esfgesf
% Objeto:   Paso de un punto en una esfera girada a la esfera original.
% Recibe:   - Coordenadas geodesicas sobre la esfera girada del punto, en radianes:
%             Latitud y longitud.
%             El dominio de la longitud es [0,pi] U ]-pi,0]
%           - Coordenadas geodesicas del nuevo Polo sobre la esfera original ( sin
%             girar ), en radianes: Latitud y Longitud.
% Devuelve: - Coordenadas geodesicas en la esfera original, en radianes:
%             Latitud y longitud.
%           - Angulo de giro de las geodesicas, en radianes.
% Ejemplo:  [fio,lono,g]=esfgesf(fig,long,fip,lonp);
