% Funcion:  kpesfera
% Objeto:   Calcula el modulo de deformacion lineal puntual en la proyeccion
%           del elipsoide a la esfera tangente al mismo en el paralelo
%           de latitud fi0, segun proyeccion conforme.
% Recibe:   - Latitud geodesica del punto, en radianes.
%           - Latitud geodesica del paralelo de tangencia, en radianes.
%           - Elipsoide de trabajo.
%             elipsoide=[a alfa b e e'];
% Devuelve: El modulo de deformacion lineal puntual.
% Ejemplo:  kp=kpesfera(fi,fi0,elipsoide);
