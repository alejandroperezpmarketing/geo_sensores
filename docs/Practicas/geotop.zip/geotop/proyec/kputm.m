% Funcion:  kputm
% Objeto:   Calcula el modulo de deformacion lineal puntual
%           para la Proyeccion UTM.
% Recibe:   - Coordenadas geodesicas del punto, en radianes:
%             Latitud y longitud.
%             El dominio de la longitud es [0,pi] U ]-pi,0]
%           - Elipsoide de trabajo.
%             elipsoide=[a alfa b e e'];
% Devuelve: El modulo de deformacion puntual.
% Ejemplo:  kp=kputm(fi1,l1,elipsoide);
