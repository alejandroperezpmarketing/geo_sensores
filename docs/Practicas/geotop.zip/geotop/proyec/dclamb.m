% Funcion:  dclamb
% Objeto:   Calcula la reduccion angular de la cuerda en la Proyeccion Conica
%           Conforme de Lambert.
%           El signo obtenido es tal que:
%           Lhz_lambert=Lhz_elipsoide+dc.
%           Lhz_elipsoide=Lhz_lambert-dc.
% Recibe:   - Coordenadas geodesicas de los dos puntos, en radianes:
%             Latitud y longitud.
%             El dominio de la longitud es [0,pi] U ]-pi,0]
%           - Latitud geodesica del paralelo de tangencia, en radianes.
%           - Longitud geodesica del meridiano origen, en radianes.
%           - Coeficiente p que define el artificio de tissot.
%           - Elipsoide de trabajo.
%             elipsoide=[a alfa b e e'];
% Devuelve: La reduccion angular de la cuerda en radianes.
% Ejemplo:  dc=dclamb(fi1,l1,fi2,l2,fio,lo,p,elipsoide);
