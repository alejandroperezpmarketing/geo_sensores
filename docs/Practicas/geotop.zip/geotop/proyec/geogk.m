% Funcion:  geogk
% Objeto:   Paso de coordenadas geodesicas a coordenadas planas en
%           la Proyeccion Gauss-Kruger. 
%           El numero de terminos considerado en el desarrollo es tal que se
%           garantiza la precision del mm. para un incremento de longitud respecto
%           al meridiano central indicado de 7.5 g.sexa.
% Recibe:   - Coordenadas geodesicas del punto en radianes: latitud y longitud.
%             El dominio de la longitud es [0,pi] U ]-pi,0]
%           - Longitud geodesica del meridiano central, en radianes.
%           - Coeficiente, p del Artificio de Tissot.
%             Si no se aplica se debe enviar 1.
%           - Traslaciones a aplicar a abcisa y ordenada, en metros.
%           - Elipsoide de trabajo.
%             elipsoide=[a alfa b e e'];
% Devuelve: Coordenadas planas en metros.
% Ejemplo:  [xp,yp]=geogk(fip,lonp,lon0,p,tx,ty,elipsoide)
