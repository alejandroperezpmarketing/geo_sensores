% Funcion:  geocdel
% Objeto:   Paso de coordenadas geodesicas a coordenadas planas en
%           la Proyeccion Cilindrica Directa Equivalente de Lambert.
% Recibe:   - Coordenadas geodesicas del punto, en radianes:
%             Latitud y longitud.
%             El dominio de la longitud es [0,pi] U ]-pi,0]
%           - Longitud del meridiano origen, en radianes.
%           - Traslaciones, tx, ty, a aplicar a las coordenadas, en metros.
%           - Elipsoide de trabajo.
%             elipsoide=[a alfa b e e'];
% Devuelve: Coordenadas planas en metros.
% Ejemplo:  [xp,yp]=geocdel(fip,lonp,lon0,tx,ty,elipsoide);
