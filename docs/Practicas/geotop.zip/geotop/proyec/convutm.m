% Funcion:  convutm
% Objeto:   Determina la convergencia de meridianos de un punto proyectado
%           del elipsoide a la Proyeccion UTM.
% Recibe:   - Coordenadas geodesicas del punto en radianes: Latitud y longitud.
%             El dominio de la longitud es [0,pi] U ]-pi,0]
%           - Elipsoide de trabajo.
%             elipsoide=[a alfa b e e'];
% Devuelve: La convergencia de meridianos en radianes.
% Ejemplo:  convp=convutm(fi,l,elipsoide);
