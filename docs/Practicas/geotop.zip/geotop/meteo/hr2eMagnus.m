% Funcion:  hr2eMagnus
% Objeto:   Convierte de humedad relativa a presi�n de vapor.
%           Emplea las f�rmulas de Magnus-Tetens (R�eger Pag 63) para obtener E�
% Recibe:   Humedad relativa (%),temperatura seca (�C)
% Devuelve: Presi�n de vapor e (hPa)
% Emplea  : presatMagnus
% Ejemplo:  [e]=hr2eMagnus(hr,ts)
