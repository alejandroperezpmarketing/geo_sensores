% Funcion:  presatMurray
% Objeto:   Calcula la presi�n de saturaci�n a una cierta temperatura.
%           Sirve tanto para la temperatura seca como para la h�meda.
%           Emplea las f�rmulas de Murray (R�eger Pag 64) y es v�lida para -50�C < ts < 50�C
% Recibe:   Temperatura (�C)
% Devuelve: Presi�n de saturaci�n E (hPa)
% Ejemplo:  [ps]=presatMurray(t)
