% Funcion:  tsth2eHuang
% Objeto:   To compute the partial water vapor pressure from dry temperature,
%           wet temperature and air pressure https://glossary.ametsoc.org/wiki/Psychrometric_formula
% Recibe:   dry temperature (�C), wet temperature (�C), air pressure (hPa)
% Devuelve: partial water vapor pressure e (hPa)
% Emplea  : svpHuang
% Ejemplo:  [e]=tsth2eHuang(ts,th,pa)