% Funcion:  hr2eBuck
% Objeto:   Convierte de humedad relativa a presi�n de vapor.
%           Emplea la f�rmula de Buck (R�eger Pag.64) para obtener E�
% Recibe:   Humedad relativa (%),temperatura seca (�C) y presi�n atmosf�rica (hPa)
% Devuelve: Presi�n de vapor e (hPa)
% Emplea  : presatBuck
% Ejemplo:  [e]=hr2eBuck(hr,ts,pa)
