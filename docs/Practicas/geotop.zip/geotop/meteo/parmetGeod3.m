% Funcion:  parmetGeod3
% Objeto:   Determina para una cierta altitud los parametros meteorologicos
%           segun el modelo de troposfera te�rico m�s simple (apuntes geodesia 3�)
%           A nivel del mar: to = 18�, po = 1013.25 hPa, hr = 50% > e = 10 hPa
%           Gradientes (Torge 3ed Pag 125) gradt = -0.0065, gradp = -0.12, grade = -0.0035;
% Recibe:   altitud en metros
% Devuelve: temperatura seca (�C) , presi�n atmosf�rica (hPa) y humedad relativa (%)
% Ejemplo:  [ts,pa,e]=parmetGeod3(h)