% Libreria GeoTop:   Meteo
%
% arccue.m           - Calcula el paso del arco a la cuerda
%
% e2hrBuck.m         - Convierte la tensi�n de vapor a humedad relativa
%                      seg�n la f�rmula de Buck
% e2hrGeod3.m        - Convierte la tensi�n de vapor a humedad relativa
%                      seg�n la f�rmula de los apuntes de geodesia 3�
% e2hrMagnus.m       - Convierte la tensi�n de vapor a humedad relativa
%                      seg�n la f�rmula de Magnus
% e2hrMurray.m       - Convierte la tensi�n de vapor a humedad relativa
%                      seg�n la f�rmula de Murray
% hr2eBuck.m         - Convierte la humedad relativa a tensi�n de vapor 
%                      seg�n la f�rmula de Buck
% hr2eGeod3.m        - Convierte la humedad relativa a tensi�n de vapor 
%                      seg�n la f�rmula de los apuntes geodesia 3�
% hr2eMagnus.m       - Convierte la humedad relativa a tensi�n de vapor 
%                      seg�n la f�rmula de Magnus
% hr2eMurray.m       - Convierte la humedad relativa a tensi�n de vapor 
%                      seg�n la f�rmula de Murray
% kmicro1999.m       - Calcula el coeficiente de refracci�n para las 
%                      microondas seg�n la f�rmula recomendada por la IAG
% koptico1999.m      - Calcula el coeficiente de refracci�n para el  
%                      visible seg�n la f�rmula recomendada por la IAG
% nmicro1963.m       - Calcula el �ndice de refracci�n para las microondas
%                      seg�n la f�rmula recomendada por la IAG en 1963
% nmicro1999.m       - Calcula el �ndice de refracci�n para las microondas
%                      seg�n la f�rmula recomendada por la IAG en 1999
% noptico1963.m      - Calcula el �ndice de refracci�n para el visible
%                      seg�n la f�rmula recomendada por la IAG en 1963
% noptico1999.m      - Calcula el �ndice de refracci�n para el visible
%                      seg�n la f�rmula recomendada por la IAG en 1999
% parmetBernese.m    - Proporciona los parametros meteorologicos para una
%                      cierta altitud segun un modelo te�rico (Bernese 4.2)
% parmetTorge.m      - Proporciona los parametros meteorologicos para una
%                      cierta altitud segun un modelo te�rico (Torge)
% pcorrvel.m         - Calcula la primera correcci�n de velocidad
%
% presatBuck.m       - Calcula la presi�n de saturaci�n a una cierta
%                      temperatura seg�n la f�rmula de Buck
% presatGeod3.m      - Calcula la presi�n de saturaci�n a una cierta
%                      temperatura seg�n la f�rmula de los apuntes
% presatMagnus.m     - Calcula la presi�n de saturaci�n a una cierta
%                      temperatura seg�n la f�rmula de Magnus
% presatMurray.m     - Calcula la presi�n de saturaci�n a una cierta
%                      temperatura seg�n la f�rmula de Murray
% scorrvel.m         - Calcula la segunda correcci�n de velocidad
%
% tpe2thGeod3.m     - Calcula la temperatura h�meda a partir de la temperatura
%                     seca,la presion atmosf�rica y la presi�n de vapor 
% tsth2eBuck.m      - Convierte las temperaturas seca y h�meda a tensi�n de
%                     vapor seg�n la f�rmula de Buck
% tsth2eGeod3.m     - Convierte las temperaturas seca y h�meda a tensi�n de
%                     vapor seg�n la f�rmula de los apuntes de geodesia
% tsth2eMagnus.m    - Convierte las temperaturas seca y h�meda a tensi�n de
%                     vapor seg�n la f�rmula de Magnus
