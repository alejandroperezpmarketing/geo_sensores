% Funcion : e2hrHuang
% Objeto  : to compute the relative humidity from the partial water vapor pressure and dry temperature
% Recibe  : partial water vapor pressure e (hPa), dry temperature (�C)
% Devuelve: relative humidity(%)
% Emplea  :  svpHuang
% Ejemplo : [hr]=e2hrHuang(e,ts)