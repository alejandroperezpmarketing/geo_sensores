% Funcion:  hr2eGeod3
% Objeto:   Convierte la humedad relativa hr(%) a presi�n de vapor e (hPa)
%           Emplea la f�rmula de los puntes de geodesia para obtener E�
% Recibe:   Humedad relativa (%),temperatura seca (�C)
% Devuelve: Presi�n de vapor e (hPa)
% Emplea  : presatGeod3
% Ejemplo:  [e]=hr2eGeod3(hr,ts)
