% Funcion:  hr2eMurray
% Objeto:   Convierte de humedad relativa a presi�n de vapor.
%           Emplea las f�rmulas de Murray (R�eger Pag 64) para obtener E�
% Recibe:   Humedad relativa (%),temperatura seca (�C)
% Devuelve: Presi�n de vapor e (hPa)
% Emplea  : presatMurray
% Ejemplo:  [e]=hr2eMurray(hr,ts)

