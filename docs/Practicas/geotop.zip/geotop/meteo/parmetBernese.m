% Funcion:  parmetBernese
% Objeto:   Determina para una cierta altitud los parametros meteorologicos
%           segun el modelo de troposfera te�rico empleado en Bernese 4.2
% Recibe:   altitud en metros
% Devuelve: temperatura seca (�C) , presi�n atmosf�rica (hPa) y humedad relativa (%)
% Ejemplo:  [ts,pa,hr]=parmetBernese(h)
