% Funcion:  scorrvel
% Objeto:   Calcula la segunda correcci�n de velocidad para distancias
%           Emplea la f�rmula del libro Electronic Distance Measurement, R�eger, Pag.81
% Recibe:   Coeficiente de refraccion, radio terrestre y distancia medida en campo
% Devuelve: La segunda correccion de velocidad en las mismas unidades que la distancia
% Ejemplo:  [scv]=scorrvel(kr,rt,dg)

