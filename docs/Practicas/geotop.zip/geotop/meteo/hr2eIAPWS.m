% Funcion : hr2eIAPWS
% Objeto  : To obtain the partial water vapor presure e from the relative humidity (%).
%           https://glossary.ametsoc.org/wiki/Psychrometric_formula
% Recibe  : Humedad relativa (%),temperatura seca (�C) y presi�n atmosf�rica (hPa)
% Devuelve: Presi�n de vapor e (hPa)
% Emplea  : svpIAPWS
% Ejemplo : [e]=hr2eIAPWS(hr,ts,pa)
