% Funcion:  presatGeod3
% Objeto:   Calcula la presi�n de saturaci�n a una cierta temperatura.
%           Sirve tanto para la temperatura seca como para la h�meda.
%           Emplea las f�rmulas de los apuntes de Geodesia de 3� y es v�lida para  0�C < ts < 50�C
% Recibe:   Temperatura (�C)
% Devuelve: Presi�n de saturaci�n E (hPa)
% Ejemplo:  [ps]=presatGeod3(t)
