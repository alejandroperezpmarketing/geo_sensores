% Funcion:  pcorrvel
% Objeto:   Calcula la primera correcci�n de velocidad para distancias
%           Emplea la f�rmula del libro Electronic Distance Measurement, R�eger, Pag.75
% Recibe:   Indice de refraccion residente, indice de refracion actual y distancia medida en campo
% Devuelve: La primera correccion de velocidad en las mismas unidades que la distancia
% Emplea  : presatBuck
% Ejemplo:  [pcv]=pcorrvel(nr,nm,dg)
