% Funcion:  presatBuck
% Objeto:   Calcula la presi�n de saturaci�n a una cierta temperatura.
%           Sirve tanto para la temperatura seca como para la h�meda.
%           Emplea las f�rmulas de Buck (R�eger Pag 64) y es v�lida para -50�C < ts < 50�C
% Recibe:   Temperatura (�C) y presi�n atmosf�rica (hPa)
% Devuelve: Presi�n de saturaci�n E hPa)
% Ejemplo:  [ps]=presatBuck(t,p)
