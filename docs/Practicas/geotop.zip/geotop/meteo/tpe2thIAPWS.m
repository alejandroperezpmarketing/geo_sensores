% Funcion:  tpe2thIAPWS
% Objeto:   Calcula la temperatura h�meda a partir de la temperatura seca (�C)
%           la presion atmosf�rica (hPa) y la presi�n de vapor (hPa), 
%           Emplea las f�rmulas de los apuntes de Geodesia de 3� y es v�lida para  0�C < ts < 50�C
% Recibe:   Temperatura seca (�C) y presi�n de vapor (hPa)
% Devuelve: Temperatura humeda (�C)
% Emplea  : tsth2eBuck
% Ejemplo:  [th]=tpe2thBuck(ts,pa,e)
