% Funcion:  koptico1999
% Objeto:   Calcula a partir de los par�metros meteorol�gicos el coeficiente de refraccion
%           para el visible (�ndice local segun AIUG-1999)
%           Emplea la f�rmula de Geodesy 3rd, Torge, Pag. 126 con los siguientes gradientes:
%           temperatura -> -0.0065 �K/m  presi�n de vapor -> -0.0035 hPa/m
%           y un radio terrestre de 6371 km.
% Recibe:   Temperatura (�K) y presion atmosf�rica (hPa)
% Devuelve: El coeficiente de refracci�n (adimensional)
% Ejemplo:  [res]=koptico1999(t,p)
