% Funcion:  e2hrBuck
% Objeto:   Convierte de presi�n de vapor a humedad relativa
%           Emplea la f�rmula de Buck (R�eger Pag.64) para obtener E�
% Recibe:   Presi�n de vapor e (hPa),temperatura seca (�C) y presion atmosf�rica (hPa)
% Devuelve: Humedad relativa hr(%)
% Emplea  : presatBuck
% Ejemplo:  [hr]=e2hrBuck(e,ts,pa)
