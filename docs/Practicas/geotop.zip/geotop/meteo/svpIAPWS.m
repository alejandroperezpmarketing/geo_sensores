% Funcion:  svpIAPWS
% Objeto:   To compute the saturation vapor pressure at temperature t
%           International Association for the Properties of Water and Steam
%           (IAPWS). Formulation from GEOPHYSICAL RESEARCH LETTERS, VOL. 40, 6303�6307, 
%           doi:10.1002/2013GL058474
% Recibe:   dry temperature (�C)
%           water_vapor_in_water 1- water / 0 - ice
% Devuelve: saturation vapor pressure (hPa)
% Emplea  : 
% Ejemplo:  [svp_hPa]=svpIAPWS(t)