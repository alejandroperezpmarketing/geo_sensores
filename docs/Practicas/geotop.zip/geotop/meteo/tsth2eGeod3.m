% Funcion:  tsth2eGeod3
% Objeto:   Calcula la presi�n de vapor a partir de la temperatura seca, 
%           de la temperatura h�meda y de la presi�n atmosf�rica.
%           Emplea las f�rmulas de los apuntes de Geodesia de 3� y es v�lida para  0�C < ts < 50�C
% Recibe:   Temperatura seca (�C), temperatura h�meda (�C) y presi�n atmosf�rica (hPa)
% Devuelve: Presi�n de vapor e (hPa)
% Emplea  : presatGeod3
% Ejemplo:  [e]=tsth2eGeod3(ts,th,pa)
