% Funcion:  tsth2eMagnus
% Objeto:   Calcula la presi�n de vapor a partir de la temperatura seca, 
%           de la temperatura h�meda y de la presi�n atmosf�rica.
%           Emplea las f�rmulas de Magnus-Tetens (R�eger Pag 63) y es v�lida para -50�C < ts < 50�C
% Recibe:   Temperatura seca (�C), temperatura h�meda (�C) y presi�n atmosf�rica (hPa)
% Devuelve: Presi�n de vapor e (hPa)
% Emplea  : presatMagnus
% Ejemplo:  [e]=tsth2eMagnus(ts,th,pa)
