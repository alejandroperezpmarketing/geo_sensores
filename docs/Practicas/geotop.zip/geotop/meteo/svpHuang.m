% Funcion:  svpHuang
% Objeto :  To compute thr saturation vapor pressure at temperature t
%           Huang (2018) American Meteorological Society DOI:10.1175/JAMC-D-17-0334.1.
% Recibe  :   dry temperature (�C)
% Devuelve: saturation vapor pressure (hPa)
% Emplea  : 
% Ejemplo : [svp_hPa]=svpHuang(t)
