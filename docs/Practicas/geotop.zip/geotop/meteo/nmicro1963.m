% Funcion:  nmicro1963
% Objeto:   Calcula a partir de los par�metros meteorol�gicos el �ndice de refraccion
%           para radiaciones de microondas (telur�metros, se�al GPS)
%           Emplea las siguientes f�rmulas del libro Electronic Distance Measurement, R�eger
%           Indice de refracci�n local n (Essen&Froome adaptada IUGG 1963) -> Pag.57
% Recibe:   Temperatura (�C), presion atmosf�rica (hPa), tensi�n de vapor (hPa)
% Devuelve: El �ndice de refraccion (adimensional)
% Ejemplo:  [nl]=nmicro1963(t,p,e)

