% Funcion:  e2hrMurray
% Objeto:   Convierte de presi�n de vapor a humedad relativa
%           Emplea las f�rmulas de Murray (R�eger Pag 64) para obtener E�
% Recibe:   Presi�n de vapor e (hPa),temperatura seca (�C)
% Devuelve: Humedad relativa hr(%)
% Emplea  : presatMurray
% Ejemplo:  [hr]=e2hrMurray(e,ts)
