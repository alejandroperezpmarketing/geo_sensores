% Funcion:  e2hrMagnus
% Objeto:   Convierte de presi�n de vapor a humedad relativa
%           Emplea la f�rmula de Magnus (R�eger Pag.64) para obtener E�
% Recibe:   Presi�n de vapor e (hPa),temperatura seca (�C)
% Devuelve: Humedad relativa hr(%)
% Emplea  : presatMagnus
% Ejemplo:  [hr]=e2hrMagnus(e,ts)
