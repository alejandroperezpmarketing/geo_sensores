% Funcion:  arccue
% Objeto:   Calcula la correcci�n de distancia para pasar del arco a la cuerda
%           Emplea la f�rmula del libro Electronic Distance Measurement, R�eger, Pag.90
% Recibe:   Coeficiente de refraccion, radio terrestre y distancia medida en campo
% Devuelve: La correccion para pasar del arco a la cuerda en las mismas unidades que la distancia
% Ejemplo:  [arcu]=arccue(kr,rt,dg)

