% Funcion:  e2hrGeod3
% Objeto:   Convierte en presi�n de vapor e (hPa) a la humedad relativa hr(%)
%           Emplea la f�rmula de los puntes de geodesia para obtener E�
% Recibe:   Presi�n de vapor e (hPa),temperatura seca (�C)
% Devuelve: Humedad relativa hr (%)
% Emplea  : presatGeod3
% Ejemplo:  [hr]=e2hrGeod3(e,ts)
