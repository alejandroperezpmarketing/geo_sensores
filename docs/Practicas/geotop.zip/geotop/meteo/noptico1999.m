% Funcion:  noptico1999
% Objeto:   Calcula a partir de los par�metros meteorol�gicos el �ndice de refraccion
%           para radiaciones del espectro �ptico (incluido el infrarojo cercano)
%           Emplea las siguientes f�rmulas del libro Geodesy 3rd, Torge
%           Indice de refracci�n de grupo ng (IUGG 1999) -> Pag.124
%           Indice de refracci�n local n (Barell&Sears adaptada IUGG 1999) -> Pag.125
% Recibe:   Temperatura (�C), presion atmosf�rica (hPa), tensi�n de vapor (hPa),
%           longitud de la onda portadora (micrometros = 1.0e-006 m) y
%           un parametro (0/1) que indica si la portadora est� modulada (1) o no (0)
% Devuelve: El �ndice de refraccioncoeficiente de refracci�n (adimensional)
% Ejemplo:  [nl]=noptico1963(t,p,e,lambda,mod)
