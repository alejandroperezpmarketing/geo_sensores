% Funcion:  g2h
% Objeto:   Dado un valor de gravedad y su altitud,determina la gravedad para otra altitud
%           en la misma linea de fuerza(Torge pag 252 -6.83b)
% Recibe:   gravedad en i, altitud de i y altitud de j.
% Devuelve: El valor de la gravedad en j.
% Ejemplo:  val=g2h(gp,hp,hj);
