% Funcion:  gno
% Objeto:   Determina la gravedad normal en el elipsoide para una cierta latitud
% Recibe:   latitud en radianes y parametros del elipsoide
% Devuelve: el valor de la gravedad normal en el elipsoide para una cierta latitud
% LLama:    gne(lat)
% Ejemplo:  grav=gno(lat,elipsoide);
