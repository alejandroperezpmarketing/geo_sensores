% Funcion:  gneSomigliana
% Objeto:   Determinar la gravedad normal en el elipsoide a una cierta
%           latitud segun la f�rmula de Somigliana (Heiskanen pag.70)
% Recibe:   latitud del punto en radianes y parametros del elipsoide
% Devuelve: el valor de la gravedad normal en el elipsoide
% Ejemplo:  val=gneSomigliana(lat,elipsoide);