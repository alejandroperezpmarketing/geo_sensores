% Funcion:  gnh
% Objeto:   Determina la gravedad normal para una latitud lat y una altitd h (Torge pag 110)
% Recibe:   latitud, altitud y parametros del elipsoide
% Devuelve: el valor de la gravedad normal a una altitud h
% LLama:    gno(lat,elipsoide)
% Ejemplo:  val=gnh(lat,h,elipsoide);
