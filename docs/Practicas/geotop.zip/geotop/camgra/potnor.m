% Funcion:  potnor
% Objeto:   determina el potencial normal para un punto dado por lat,lon,hel.
%           Emplea la f�rmula cerrada de Heiskanen
% Recibe:   latitud (rad),longitud (rad),altitud elipsoidal (m) y parametros del elipsoide
% Devuelve: El valor del potencial normal (m2/s2) en el punto (lat,lon,hel)
% LLama:    geotri,tri2ubl
% Ejemplo:  val=potnor(lat,lon,hel,elipsoide);