% Libreria GeoTop:      Funciones para tratar el campo gravitatorio
% Autor:                David Hernandez Lopez (dhernand@gugu.usal.es)                      
%                       Luis Garc�a-Asenjo Villamayor (lugarcia@cgf.upv.es)
% Version:              1.0 para Matlab R11.1.
%
%
% gngrs80.m
% gngrs80abv.m
% gne.m
% gnp.m
% gnh.m
% gno.m
% gncas30.m
% gmedia.m
% g2h.m
% potnor.m
% gnmedia.m
