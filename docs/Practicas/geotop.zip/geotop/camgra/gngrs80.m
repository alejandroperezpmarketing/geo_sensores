% Funcion:  gngrs80
% Objeto:   Determina la gravedad normal en el sistema GRS80 con una exactitud
%           de 0.001 micro m / s*s
% Recibe:   latitud geodesica del punto en radianes
% Devuelve: el valor de la gravedad normal
% Ejemplo:  gn=gngrs80(lat);
