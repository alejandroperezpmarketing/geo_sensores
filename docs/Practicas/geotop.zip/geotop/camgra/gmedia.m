% Funcion:  gmedia
% Objeto:   Determina la gravedad media desde el terreno hasta el geoide(Torge pag 252)
% Recibe:   gravedad en superficie y altitud
% Devuelve: el valor medio de la gravedad a lo largo de la linea de fuerza
% Ejemplo:  val=gmedia(gp,hp);
