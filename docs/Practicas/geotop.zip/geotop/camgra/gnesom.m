% Funcion:  gnesom
% Objeto:   Determinar la gravedad normal en el elipsoide a una cierta
%           latitud segun la f�rmula de Somigliana (Heiskanen pag.70)
% Recibe:   latitud del punto en radianes y parametros del elipsoide
% Devuelve: el valor de la gravedad normal en el elipsoide
% Ejemplo:  val=gnesom(lat,elipsoide);
function[val]=gnesom(lat,elipsoide)
a = elipsoide(1,1);
b = elipsoide(1,3);
gm = elipsoide(1,7);
m = elipsoide(1,9);
a2 = a*a;
b2 = b*b;
se2 = elipsoide(1,5)*elipsoide(1,5);
E2 = a2-b2;
E = sqrt(E2);
at = atan(E/b);
qo = ( ( 1+3*b2/E2 ) * at - 3*b/E )/2;
qpo = 3*( 1+b2/E2 ) * ( 1-b*at/E ) -1;
gne = gm*(1-m-m*sqrt(se2)*qpo/(6*qo)) / (a*b);
gnp = gm*(1+m*sqrt(se2)*qpo/(3*qo)) / a2;
num = a*gne*cos(lat)^2+b*gnp*sin(lat)^2;
den = sqrt(a2*cos(lat)^2+b2*sin(lat)^2);
val = num/den;