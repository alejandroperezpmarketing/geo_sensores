% Funcion:  gnedeser
% Objeto:   Determinar la gravedad normal en el elipsoide a una cierta
%           latitud empleando un desarrollo en serie preciso
% Recibe:   latitud del punto en radianes y parametros del elipsoide
% Devuelve: el valor de la gravedad normal en el elipsoide
% Ejemplo:  val=gnedeser(lat,elipsoide);
