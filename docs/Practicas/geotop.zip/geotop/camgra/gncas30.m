% Funcion:  gncas30
% Objeto:   Determina la gravedad normal segun la formula de
%           Cassiniss-Silva-Heiskanen 1930 ( ED50)
% Recibe:   latitud geodesica del punto en radianes
% Devuelve: el valor de la gravedad normal
% Ejemplo:  gn=gncas30abv(lat);
