% Funcion:  gne
% Objeto:   Dado un elipsoide, determina la gravedad normal en el ecuador (Heiskanen pag69)
% Recibe:   parametros del elipsoide
% Devuelve: el valor de la gravedad normal en el ecuador
% Ejemplo:  val=gne(elipsoide);
