% Funcion:  gne2gnh
% Objeto:   Determina la gravedad normal para una latitud lat y una altitd h (Torge pag 110)
% Recibe:   latitud, altitud y parametros del elipsoide
% Devuelve: el valor de la gravedad normal a una altitud hel
% LLama:    gneSomigliana(lat,elipsoide);
% Ejemplo:  val=gne2gnh(lat,hel,elipsoide);

