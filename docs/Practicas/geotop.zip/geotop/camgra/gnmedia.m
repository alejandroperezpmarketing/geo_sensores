% Funcion:  gnmedia
% Objeto:   Determina la gravedad normal media desde el terreno hasta la superficie de referencia
%           considerada: quasigeoide (H normal), elipsoide (h elipsoidal) (Torge ed2 pag 59)
% Recibe:   latitud(rad),altitud(m) y parametros del elipsoide
% Devuelve: el valor medio de la gravedad (m/s2) a lo largo de la linea de fuerza considerada
% Ejemplo:  val=gnmedia(lat,h,elipsoide);