% Funcion:  tleick2d
% Objeto:   Determina y aplica una transformacion de Helmert 2D de cuatro parametros
%           en Coordenadas Geodesicas sobre la superficie del Elipsoide aplicando el 
%           modelo funcional de Leick.
%           El minimo numero de puntos comunes en los dos sistemas es de dos.
%           La transformacion se resuelve por minimos cuadrados.
% Recibe:   - Matriz de coordenadas geodesicas en el sistema origen,
%             con la estructura:
%             - Columna 1: N.Punto.
%             - Columna 2: Latitud geodesica en radianes.
%             - Columna 3: Longitud geodesica en radianes.
%           - Error medio cuadratico de la posicion en este sistema, en segundos sexa.
%           - Elipsoide del sistema de referencia origen: elipsoideo=[a alfa b e e'];
%           - Matriz de coordenadas geodesicas en el sistema destino,
%             con la estructura:
%             - Columna 1: N.Punto.
%             - Columna 2: Latitud geodesica en radianes.
%             - Columna 3: Longitud geodesica en radianes.
%           - Error medio cuadratico de la posicion en este sistema, en segundos sexa.
%           - Elipsoide del sistema de referencia destino: elipsoided=[a alfa b e e'];
%           - Matriz de coordenadas geodesicas en el sistema origen de puntos a transformar,
%             ( si no se desea aplicar la transformacion a ningun punto se envia 0 ).
%             con la estructura:
%             - Columna 1: N.Punto.
%             - Columna 2: Latitud geodesica en radianes.
%             - Columna 3: Longitud geodesica en radianes.
%           - Nivel de significacion para el F-test de compatibilidad estadistica de los
%             estimadores a priori y a posteriori de la varianza del observable de peso unidad.
%           - Nivel de significacion para el test de Baarda.
%           - Potencia de test para el test de Baarda.
%           - Nivel de significacion para el test de Pope.
%           - Fichero donde se desea el listado del resultado de la transformacion.
% Devuelve: - Una matriz con los puntos transformados con la misma estructura de entrada.
%           - Una variable control que valdra -1 si el numero de vectores es insuficiente
%             para determinar la transformacion, o el numero de puntos comunes que determinan
%             la transformacion.
%           - Numero de observaciones rechazables en la determinacion de la transformacion.
%           Ademas genera un fichero con los resultados ( el enviado como ultimo parametro ).
% Ejemplo:  [ct,control]=tleick2d(co,emco,elipsoideo,cd,emcd,elipsoided,cat,alfaglobal,alfabaarda,betabaarda,alfapope,fsalida);
