% Funcion:  hel3dv
% Objeto:   Determina y aplica una transformacion de Helmert 3D
%           a un fichero de vectores expresados en componentes Cartesianas Tridimensionales.
%           La propia transformacion se determina a partir de vectores entre puntos conocidos,
%           siendo necesario que existan un minimo de dos vectores entre puntos conocidos
%           ( en la transformacion se incluyen cuatro incognitas, tres giros y un factor de escala ).
%           La transformacion se resuelve por minimos cuadrados aplicando test de Baarda.
% Recibe:   - Matriz de coordenadas: NP. Coor.XCT  Coor.YCT. Coor.ZCT.
%               cct=[  1001     610976.262    4734613.143     4587460.138                        
%                      1025     618063.236    4726449.451     4589714.732                        
%                      ....     ..........    ...........       ........
%                      1026     616749.288    4726760.168     4581081.664];
%           - Matriz de observaciones: NPE.  NPV.  I.X.  I.Y.  I.Z.  N.I.
%             siendo la ultima columna el numero de instrumento para ponderar.
%               gps=[     1         2        392.974       -988.416       -527.966
%                         3         4        -40.336       -459.793         27.857
%                         5         6       -816.038         11.478       1103.615
%                         .         .       ........       ........       ........ 
%                         9        10       -860.361         30.642       1136.445];
%           - Matriz de instrumentos:
%               instru=[  1  1  0.001  0.001  0.020  2.0  0.015  0.015  0.000
%                         2  1  0.001  0.001  0.010  1.0  0.015  0.015  0.000
%                         .  .  .....  .....  .....  ...  .....  .....  .....
%                         3  2  0.001  0.001  0.010  1.0  5.000  0.015  0.015];
%           - Nivel de significacion para el F-test de compatibilidad estadistica de los
%             estimadores a priori y a posteriori de la varianza del observable de peso unidad.
%           - Nivel de significacion para el test de Baarda.
%           - Potencia de test para el test de Baarda.
%           - Nivel de significacion para el test de Pope.
%           - Fichero donde se desea el listado del resultado de la transformacion.
% Devuelve: - Una matriz con los vectores transformados ( sin incluir aquellos entre puntos
%             conocidos ) con la misma estructura que la matriz de vectores de entrada.
%           - Una variable control que valdra -1 si el numero de vectores es insuficiente
%             para determinar la transformacion.
%           - Una variable que valdra -1 si no se ha aceptado el test global del modelo.
%           - Una variable que indica el numero de observaciones rechazables por el 
%             test de Baarda o por el test de Pope.
%           Ademas se genera un fichero con los resultados ( el enviado como ultimo parametro ).
% Ejemplo:  [vect,control,testf,nor]=hel3dv(cctp,gps,instru,alfaglobal,alfabaarda,betabaarda,alfapope,fsalida);
