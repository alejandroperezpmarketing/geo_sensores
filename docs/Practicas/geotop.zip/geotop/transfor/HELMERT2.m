% Funcion:  helmert2
% Objeto:   Determina y aplica una transformacion de Helmert 2D
%           a un conjunto de puntos.
%           Contempla dos tipos de puntos: de control y destacados.
%           Los puntos de control son para determinar la transformacion.
%           Los puntos destacados son para aplicarles la transformacion hallada.
% Recibe:   - Tres matrices de datos:
%             - matriz de coordenadas de los puntos de control en sistema origen:
%                   NP. Coor.XCT  Coor.YCT. 
%                xco=[1 723531.130 4373418.660
%                    2 723747.650 4373433.380
%                    3 723710.330 4373363.090
%                    4 723384.610 4373489.230
%                    5 723464.250 4373471.620
%                    6 723433.450 4373668.400
%                    7 723582.870 4373748.710
%                    8 723485.010 4373737.870];
%             - matriz de coordenadas de los puntos de control en sistema destino:
%                   NP. Coor.XCT  Coor.YCT. 
%                xcd=[1 723531.004 4373418.548
%                    2 723747.384 4373433.058
%                    3 723710.200 4373363.134
%                    4 723384.450 4373489.339
%                    5 723464.283 4373471.714
%                    6 723433.678 4373668.458
%                    7 723582.950 4373748.523
%                    8 723485.042 4373737.864];
%             - matriz de coordenadas de los puntos destacados en sistema origen:
%              ( si no se desea aplicar la transformacion a ningun punto se envia 0 ).
%                   NP. Coor.XCT  Coor.YCT. 
%               xdo=[1 723529.320 4373322.270
%                    2 723529.710 4373396.330
%                    . .......... ...........
%                   16 723550.310 4373544.010];
%           - emc de coordenadas origen en metros.
%           - emc de coordenadas destino en metros.
%           - Nivel de significacion para el F-test de compatibilidad estadistica de los
%             estimadores a priori y a posteriori de la varianza del observable de peso unidad.
%           - Nivel de significacion para el test de Baarda.
%           - Potencia de test para el test de Baarda.
%           - Nivel de significacion para el test de Pope.
%           - Fichero donde se desea el listado del resultado de la transformacion.
% Devuelve: - Una matriz con las coordenadas transformadas de los puntos a transformar.
%           - Numero de observaciones rechazables en la determinacion de la transformacion.
%           Ademas genera un fichero con los resultados ( el enviado como ultimo parametro ).
% Ejemplo:  [xdd,nor]=helmert2(xco,xcd,xdo,emco,emcd,alfaglobal,alfabaarda,betabaarda,alfapope,fsalida);
