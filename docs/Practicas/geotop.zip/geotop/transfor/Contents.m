% Libreria GeoTop: 	Transfor
%
%Hel3dv.   - Determina y aplica una transformaci�n de Helmert tridimensional,
%            a un conjunto de vectores, expresados en componentes cartesianas 
%            tridimensionales. La determinaci�n se realiza a partir de la 
%            existencia de vectores entre puntos de coordenadas conocidas. 
%            La transformaci�n se resuelve por m�nimos cuadrados, a partir 
%            de la oportuna ponderaci�n. Se obtiene el test de Baarda.
%Helmert2. - Determina y aplica una transformaci�n de Helmert bidimensional,
%            a un conjunto de puntos. La determinaci�n se realiza a partir 
%            de la existencia de puntos en el sistema origen y destino de la 
%            transformaci�n. La transformaci�n se resuelve por m�nimos cuadrados,
%            a partir de la oportuna ponderaci�n. Se obtiene el test de Baarda.
%Tbm3d7.   - Determina y aplica una transformaci�n de Helmert tridimensional
%            de siete par�metros, a un conjunto de puntos, aplicando el modelo
%            de Badekas-Molodenskii. La determinaci�n se realiza a partir de la
%            existencia de puntos en el sistema origen y destino de la transformaci�n.
%            La transformaci�n se resuelve por m�nimos cuadrados, a partir de la 
%            oportuna ponderaci�n. Se obtiene el test de Baarda.
%Tbw3d7.   - Determina y aplica una transformaci�n de Helmert tridimensional de 
%            siete par�metros, a un conjunto de puntos, aplicando el modelo de 
%            Bursa-Wolf. La determinaci�n se realiza a partir de la existencia 
%            de puntos en el sistema origen y destino de la transformaci�n. 
%            La transformaci�n se resuelve por m�nimos cuadrados, a partir de la
%            oportuna ponderaci�n. Se obtiene el test de Baarda.
%Tleick2d. - Determina y aplica una transformaci�n de Helmert bidimensional de 
%            cuatro par�metros, sobre la superficie del elipsoide del sistema de 
%            referencia destino, a un conjunto de puntos, aplicando el modelo de 
%            Alfred Leick. La determinaci�n se realiza a partir de la existencia
%            de puntos en el sistema origen y destino de la transformaci�n. 
%            La transformaci�n se resuelve por m�nimos cuadrados, a partir de la
%            oportuna ponderaci�n. Se obtiene el test de Baarda.
