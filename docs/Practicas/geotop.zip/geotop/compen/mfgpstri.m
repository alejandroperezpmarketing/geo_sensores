% Funcion:  mfgpstri
% Objeto:   - Crea las matrices del sistema original, A, K y EMC, ( A y K ponderadas )
%             de la compensacion de una Red Geodesica:
%             - con Observables GPS,
%             - con ecuaciones de observacion en incrementos de Coordenadas Cartesianas Tridimensionales,
%             - con incognitas de posicion en diferenciales de Coordenadas Cartesianas Tridimensionales y
%             - con o sin parametros ( tres giros y un factor de escala ) para incluir la transformacion
%               del Sistema de Referencia de los Observables GPS al definido por las coordenadas de los puntos fijos.
% Recibe:   - Matriz de coordenadas:
%             Estructura de matriz de coordenadas:
%             - Primera columna: Numero de punto.
%             - Segunda columna: Coordenada X Cartesiana Tridimensional, en metros.
%             - Tercera columna: Coordenada Y Cartesiana Tridimensional, en metros.
%             - Cuarta  columna: Coordenada Z Cartesiana Tridimensional, en metros.
%             - Quinta  columna: Tipo: 1-Fijo, 0-libre.
%           - Vector columna con tantas filas como puntos fijos y libre intervien en la Red y que
%             contiene el numero de punto incognita. Se utiliza para calcular las columnas de los
%             diferenciales de las coordenadas de los puntos libres.
%           - Matriz de vectores:
%             Estructura de matriz de vectores:
%             - Primera columna: Punto extremo inicial.
%             - Segunda columna: Punto extremo final.
%             - Tercera columna: Incremento de X, en metros.
%             - Cuarta  columna: Incremento de Y, en metros.
%             - Quinta  columna: Incremento de Z, en metros.
%             - Sexta   columna: Posicion del instrumento en matriz de instrumentos.
%                                No se utiliza.
%             - Setpima columna: Error a priori del vector en metros.
%           - Variable cambio: 1-Si, 0-No, segun se incluyan o no parametros de transformacion.  
%           - Varianza a Priori del Observable de Peso Unidad.
%           - Numero de puntos incognita.
% Devuelve: - Matriz A de dise�o del Sistema Original, Ponderada.
%             Las ultimas cuatro columnas corresponden a las incognitas de la transformacion,
%             primero el factor de escala y a continuacion giros en X, Y, Z.
%           - Vector K de terminos independientes del Sistema Original, Ponderado.
%           - Vector Columna con los EMC a priori, en metros.
%           - Matriz Baarda que contiene para cada ecuacion:
%             - Primera columna: Pe.
%             - Segunda columna: Pv.
%             - Tercera columna: Tipo de observable.
%               1-AX, 2-AY, 3-AZ, 
%             - Cuarta columna: Unidad de residuos y errores medios cuadraticos.
%               1-metros, 2-radianes, 3-sex.cente, 4-sex.sexa,
%             Se utilizara en los listados.
% Ejemplo:  [A,K,EMC,baarda]=mfgpstri(cctp,gps,cambio,varpri,npi);
