% Funcion: lsredgeo4 - Es la funci�n lsredgeo con las siguientes
% modificaciones (18/03/2021):
%           - Devuelve un fichero con las coordenadas ajustadas y sus errores con el siguiente formato:
%           Si superficie == 1 : num, lat,lon,hel,errlat,errlon,errhel,covlatlon,covlathel,covlonhe,huso
%           Si superficie == 2 : num, E,N,hel,errE,errN,errhel,covEN,covEhel,covNhel,huso
%           - Devuelve un fichero con las coordenadas ajustadas y sus errores con el siguiente formato:
% modificaciones (06/11/2012):
%           - El fichero de coordenadas aproximadas ha de contener los datos de
%           ondulaci�n de geoide y desviaci�n de la vertical del siguiente modo
%           cp= [  105 732899.991 4508127.392 30  1127.385   0  0   51.276  7.6     1.5
%                 2517 736455.004 4507099.870 30   806.446   0  0   51.295  6.1     0.9
%           - Cambia la impresi�n de la cabecera
% modificaciones (04/11/2019):
%           - Genera un gr�fico con las figuras de error
%
% Objeto:   COMPENSACI�N de una Red Geodesica por minimos cuadrados.
%           Contempla las siguientes posibilidades:
%           - Sistema de Referencia Geod�sico: ED50 o ETRS89.
%           - Observables GPS y/o Clasicos.
%           - COMPENSACI�N separada en Planim�trica y Altim�trica.
%           - COMPENSACI�N Planim�trica:
%             - Superficie de COMPENSACI�N: el Elipsoide o el plano de la PROYECCI�N UTM.
%             - Se puede optar por incluir o no PAR�METROS sistematicos:
%               - Giro para acimut GPS.
%               - Factor de escala para distancias GPS.
%               - Factor de escala para distancias Clasicas.
%               Los dos primeros se introducen conjuntamente poniendo a 1 la variable cambiogps.
%           - COMPENSACI�N Altim�trica:
%             - Se puede optar por incluir o no PAR�METROS sistematicos a los observables GPS,
%               para incluir cambio de Sistema de Referencia Geod�sico: dos giros.
%               En esta practica se elige incluirlos.
%           - Cada vector GPS genera:
%             - Planimetria: observacion de acimut y distancia.
%               Realizandose las oporturnas operaciones de reduccion y PROYECCI�N a la superficie de COMPENSACI�N.
%             - Altimetria:  observacion de desnivel elipsoidal.
%           - Un observable clasico incluye: Lhz, Lv, ai, am, y Dg ( pudiendo ser algunos nulos ), generando:
%             - Planimetria: observacion de direccion y distancia.
%               Realizandose las oporturnas operaciones de reduccion y PROYECCI�N a la superficie de COMPENSACI�N.
%             - Altimetria:  observacion de desnivel elipsoidal.
%               Permite obtener el desnivel por dos metodos diferentes: clasico o por geodesia tridimensional.
%               Permite tambien aplicar correccion a la lectura cenital por refraccion.
%           - Si la Red es Libre, se encuentra la solucion minima norma-varianza, solucion seudoinversa.
%           - Se aplica Test Global del modelo.
%           - Se aplica Test de deteccion de errotes groseros, Baarda y Pope.
%           - Se ofrece soluciones y figuras de error, para un nivel de confianza especificado,
%             en diferentes Sistemas de Coordenadas:
%             - Coordenadas Geodesicas.
%             - Coordenadas sobre la PROYECCI�N UTM.
%           - El criterio que utiliza para determinar las figuras de error es el siguiente:
%             - Sea varo2 la Varianza a Priori del Observable de Peso Unidad,
%               y varo su raiz cuadrada.
%             - Sea so2 el estimador de la Varianza del Observable de Peso Unidad.
%               y so su raiz cuadrada.
%             - Si so2>varo2 se determinan segun:
%               error=so * sqrt( nir * qxxc * fsnedec )
%               donde,
%                 - nir, es el N�mero de inc�gnitas relacionadas en la figura de error:
%                   1 para los PAR�METROS de transformacion del cambio de Sistema de Referencia en Planimetria.
%                   1 para los PAR�METROS de transformacion del cambio de Sistema de Referencia en Altimetria.
%                   2 para la figura de error de la COMPENSACI�N Planim�trica.
%                   1 para la figura de error de la COMPENSACI�N Altim�trica.
%                 - fsnedec, es el valor de la distribucion F-Snedecor para:
%                   - nivel de confianza el seleccionado para las figuras de error.
%                   - grados de libertad de la distribucio: nir y los propios del ajuste.
%             - Si so2<varo2 se determinan segun:
%               error=varo * sqrt( qxxc * chi2 )
%               donde,
%                 - chi2, es el valor de la distribucion chi2 para:
%                   - nivel de confianza el seleccionado para las figuras de error.
%                   - grados de libertad el N�mero de inc�gnitas relacionadas en la figura de error, nir.
% Recibe:   - Matriz cpp, coordenadas fijas y aproximadas de partida:
%             cpp=[ N.Punto  C.X-UTM   C.Y-UTM  HUSO  Altitud  TIPO2D  TIPOZ
%                   .......  .......   .......  ....  .......  ......  .....];
%             - Tipo: 0-Libre, 1-Fijo., en planimetria o altimetria ( 2D y Z, respectivamente ).
%             Magnitudes lineales en metros.
%           - Tipo de altitud incluida en matriz de coordenadas: 1 - ortometricas.
%           - Observables GPS en una matriz: ( si no hay seria un escalar nulo, gps=0; )
%             gps=[ N.P.E.   N.P.V.   AX    AY    AZ    NI
%                   ......   ......   ..    ..    ..    ..];
%             Los incrementos de coordenadas cartesianas tridimensionales en metros.
%           - Observables Clasicos en una matriz: ( si no hay seria un escalar nulo, cla=0; )
%             cla=[ N.P.E.   N.P.V.   LHZ.   LV.    A.I.   A.M.   DG.   NI
%                   ......   ......   ....   ...    ....   ....   ...   ..];
%             Magnitudes lineales en metros y angulares en graduacion centesimal.
%           - NI es el N�mero de instrumento en matriz de instrumentos:
%             Es una matriz en la que en cada fila se incluye informacion de un instrumento tal que permite
%             estimar, segun metodos clasicos, la precision de los correspondientes observables.
%	  		     instru=[1  2  0.001  0.001  0.020  2.0  0.015  0.015  0.000  0      0      0     0
%					       2  2  0.001  0.001  0.010  1.0  0.015  0.015  0.000  0      0      0     0
%  					    3  1  1      1.0    20     30   1      0.01   3.000  0.005  0.020  0.01  0.01];
%             - Cada fila corresponde a un instrumento distinto.
%             - Cada fila tiene 13 columnas.
%             - La primera columna es el N�mero del instrumento.
%             - La segunda columna es el tipo: 1-Est. Total o Teo+Dis, 2-GPS.
%               - Para GPS las siguientes columnas corresponden a:
%                 - Col.3:  Error de centrado de la antena en el extremo inicial del vector, en metros.
%                 - Col.4:  Error de centrado de la antena en el extremo final del vector, en metros.
%                 - Col.5:  Parte constante de error del vector, en metros.
%                 - Col.6:  Parte proporcional de error del vector, en ppm.
%                 - Col.7:  Error de medida de altura de antena en el extremo inicial del vector, en metros.
%                 - Col.8:  Error de medida de altura de antena en el extremo final del vector, en metros.%               
%               - Para Est.Total las siguientes columnas corresponden a:
%                 - Col.3:  1/0, Lectura Analogica / Digital.
%                 - Col.4:  Apreciacion de lectura angular, en segundos centesimales.
%                 - Col.5:  Sensibilidad del nivel tubular en segundos sexagesimales.
%                 - Col.6:  Aumentos del anteojo.
%                 - Col.7:  1/0, Compensador o no de eclimetro.
%                 - Col.8:  Parte constante de error del distanciometro, en metros.
%                 - Col.9:  Parte proporcional de error del distanciometro, en ppm.
%                 - Col.10: Error de centrado en el instrumento, en metros.
%                 - Col.11: Error de centrado en el elemento de punteria, en metros.
%                 - Col.12: Error de medida de altura de instrumento, en metros.
%                 - Col.13: Error en altura de punteria, en metros.
%           - Un escalar: 1 - 0, segun se desee o no eliminar las inc�gnitas de descentrado del sistema
%                                de ecuaciones de la COMPENSACI�N Planim�trica.
%           - Un escalar: 1 - Con cambio Sis.Ref. ( Incluir giro y f.escala para obs.GPS )
%           - Un escalar: 1 - 0, segun se desee o no incluir factor de escala en distancias clasicas.
%           - Un vector fila con la siguiente informacion:
%             - Columna 1: Varianza a Priori del Observable de Peso Unidad.
%             - Columna 2: Nivel de Significacion del Test Global del Modelo.
%             - Columna 3: Nivel de Significacion del Test de Baarda de Deteccion de Errores Groseros.
%             - Columna 4: Potencia de Test de Baarda de Deteccion de Errores Groseros.
%             - Columna 5: Nivel de Significacion del Test de Pope de Deteccion de Errores Groseros.
%             Columnas 2 a 5 en tantos por 1.
%           - Nivel de confianza deseado para las figuras de error, en tanto por uno.
%           - Escalar: 1/2, segun se desee que la superficie de COMPENSACI�N Planim�trica sea la superficie del
%                      elipsoide de revolucion o la del plano de la PROYECCI�N UTM.
%           - Escalar con el N�mero de huso donde se desea realizar la COMPENSACI�N en caso de optar por esta
%             superficie en la variable anterior. Si no, debe enviarse 0.
%           - Un vector fila con la siguiente informacion:
%             - Columna 1: 1/2, calculo de desnivel a partir de lectura cenital por geodesia tridimensional o
%                          por metodo clasico, respectivamente.
%             - Columna 2: Coeficiente de refraccion atmosferica para el espectro visible.
%             - Columna 3: 1/0, segun se desee aplicar o no correccion por refraccion a la lectura cenital.
%				  Si no hay observaciones clasicas deberia enviarse un vector de tres columnas lleno de ceros.
%           - Sistema de Referencia Geod�sico a partir de una variable de elipsoide.
%             como un vector fila de 5 columnas: elipsoide=[a alfa b e e'];
%           - Nombre, con la ruta completa, del fichero donde se desean los resultados.
%             Si existe y no se desea a�adir con los resultados de esta funcion 
%             se deberia borrar previamente.
% Devuelve: Genera un fichero de resultados:
% Ejemplo: [adjcrd]=lsredgeo4(cp,altitud,cla,gps,instru,delides,cambiogps,fescalacla,test,elipconf,superficie,huso,desniv,elipsoide,fsalida);
