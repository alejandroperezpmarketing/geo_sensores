% Funcion:  prncp
% Objeto:   Imprime listado de coordenadas planas segun diferentes formatos en funcion
%           de un parametro recibido.
% Recibe:   - Matriz cp, de coordenadas UTM. Estructura:
%             cpp=[ N.Punto  C.X-UTM   C.Y-UTM  HUSO  Altitud  TIPO2D  TIPOH
%                   .......  .......   .......  ....  .......  ......  .....];
%             Pero con una serie de columnas a�adidas en funcion del tipo de impresion, concretamente,
%             si el tipo de impresion es 2 o 4, para cada punto libre:
%             - octava  columna: semieje mayor elipse de error en plano UTM, en metros.
%             - novena  columna: semieje mmenor elipse de error en plano UTM, en metros.
%             - decima  columna: acimut del semieje mayor, en radianes.
%             Si el tipo de impresion es 4, tambien deben figurar, para cada punto libre:
%             - onceava columna: Correccion a la abcisa UTM, en metros.
%             - doceava columna: Correccion a la ordenada UTM, en metros.
%           - Matriz de Coordenadas Cartesianas Tridimensionales.
%             Estructura de matriz de coordenadas:
%             - Primera columna: Numero de punto.
%             - Segunda columna: Coordenada X Cartesiana Tridimensional, en metros.
%             - Tercera columna: Coordenada Y Cartesiana Tridimensional, en metros.
%             - Cuarta  columna: Coordenada Z Cartesiana Tridimensional, en metros.
%             - Quinta  columna: Numero de observaciones planimetricas en que interviene el punto.
%             - Sexta   columna: Numero de observaciones altimetricas en que interviene el punto.
%           - nipla: vector columna de tantas filas como puntos totales, en que en la columna correspondiente
%             figurara el numero de punto libre, en orden secuencial, para la compensacion planimetrica.
%           - Tipo de impresion.
%             1: NP   C.X-UTM   C.Y-UTM  HUSO  H.ORT.   TIPO2D   TIPOH  NOBS2D NOBSH
%             2: NP   C.X-UTM   C.Y-UTM  HUSO  semia    semib    azia
%             3: NP   C.X-UTM   C.Y-UTM  HUSO  H.ORT.
%             4: NP   Desplaz.  dX.  X-U.T.M.  dY.  Y-U.T.M.   HUSO.    a      b      azim.a.
%           - Nivel de confianza para las figuras de error.
%           - Fichero de impresion.
% Devuelve: - No devuelve nada.
% Ejemplo:  []=prncp(cp,cct,nipla,tipoprn,elipconf,fsalida)
