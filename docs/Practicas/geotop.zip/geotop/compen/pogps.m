% Funcion:  pogps
% Objeto:   - Pasa una matriz de observables GPS como incremento de Coordenadas Cartesianas Tridimensionales
%             a dos matrices: de observables Planimetricos y Altimetricos.
%           - Cada vector GPS da lugar a:
%             - En la matriz de observables planimetricos:
%               - Observacion de acimut de la linea geodesica en la superficie elegida de compensacion,
%                 elipsoide o plano de la Proyeccion UTM, del Sistema de Referencia Geodesico indicado, en radianes.
%               - Observacion de distancia de la linea geodesica en la superficie elegida de compensacion,
%                 elipsoide o plano de la Proyeccion UTM, del Sistema de Referencia Geodesico indicado, en metros.
%             - En la matriz de observables altimetricos:
%               - Observacion de desnivel elipsoidal.
%           - Se calcula y almacena la precision a priori de cada observable anterior a partir de la inclusion
%             en la matriz de observables GPS de un codigo de union con una matriz de caracteristicas de
%             instrumentos.
% Recibe:   - Matriz de Coordenadas Cartesianas Tridimensionales.
%             Estructura de matriz de coordenadas:
%             - Primera columna: Numero de punto.
%             - Segunda columna: Coordenada X Cartesiana Tridimensional, en metros.
%             - Tercera columna: Coordenada Y Cartesiana Tridimensional, en metros.
%             - Cuarta  columna: Coordenada Z Cartesiana Tridimensional, en metros.
%             - Quinta  columna: Numero de observaciones planimetricas en que interviene el punto.
%             - Sexta   columna: Numero de observaciones altimetricas en que interviene el punto.
%           - Matriz de Coordenadas Geodesicas.
%             Estructura de matriz de coordenadas:
%             - Primera columna: Numero de punto.
%             - Segunda columna: Latitud geodesica, en radianes.
%             - Tercera columna: Longitud geodesica, en radianes.
%             - Cuarta  columna: Altitud elipsidal, en metros.
%             - Quinta  columna: Ondulacion del geoide, en metros.
%           - Matriz de coordenadas UTM. Estructura, ver ayuda de redgeo1.
%           - Matriz de observaciones GPS. Estructura, ver ayuda de redgeo1.
%           - Matriz de instrumentos. Estructura, ver ayuda de redgeo1.
%           - Elipsoide del Sistema de Referencia Geodesico, como un vector fila:
%             elipsoide=[a alfa b e e'];
%           - Superficie elegida para la compensacion: 1-Elipsoide, 2-Plano Proyeccion UTM.
% Devuelve: - Matriz de observaciones planimetricas sobre la superficie del elipsoide,
%             con la estructura:
%             - Cada fila corresponde a una observacion.
%             - Primera columna: Tipo de observacion:
%                                1 - Acimut GPS en la superficie de compensacion.
%                                2 - Distancia GPS en la superficie de compensacion.
%             - Segundo columna: Punto estacion.
%             - Tercera columna: Punto visado.
%             - Cuarta  columna: Observable. Angular en radianes. Lineal en metros.
%             - Quinta  columna: Precision. Angular en radianes. Lineal en metros.
%           - Matriz de observaciones para la compensacion Altimetrica
%             con la estructura:
%             - Cada fila corresponde a una observacion.
%             - Primera columna: Tipo de observacion:
%                                1 - Desnivel elipsoidal GPS.
%             - Segundo columna: Punto estacion.
%             - Tercera columna: Punto visado.
%             - Cuarta  columna: Observable, angular en radianes o lineal en metros.
%             - Quinta  columna: Precision, angular en radianes o lineal en metros.
% Ejemplo:  [gpspla,gpsalt]=pogps(cct,cg,cp,gps,instru,elipsoide,superficie);
