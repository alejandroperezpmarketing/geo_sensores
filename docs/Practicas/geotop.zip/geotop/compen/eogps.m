% Funcion:  eogps
% Objeto:   - Elimina observaciones GPS de una Red por:
%             - Observaciones entre puntos fijos si no se incluyen parametros sistematicos de cambio
%               de Sistema de Referencia Geodesico.
%             - Observaciones en las que alguno de los puntos que interviene no figura en la matriz
%               de coordenadas aproximadas.
%             - Observaciones en que coincide el punto estacion y visado.
%           - A cada punto libre se le asigna un numero de incognita, comenzando en 1, en una matriz
%             para planimetria y en otra para altimetria.
%             Se le asigna un 0 si no interviene en ninguna observacion, con lo que sera eliminado de
%             la compensacion.
%           - En la matriz de coordenadas cartesianas tridimensionales se a�aden dos columnas, la quinta y la
%             sexta, donde, respectivamente, se incluiran el numero de observaciones en que interviene cada
%             punto en la compensacion planimetrica y altimetrica, respectivamente.
% Recibe:   - Matriz de coordenadas cartesianas tridimensionales.
%             - Primera columna: Numero de punto.
%             - Segunda columna: Coordenada X Cartesiana Tridimensional, en metros.
%             - Tercera columna: Coordenada Y Cartesiana Tridimensional, en metros.
%             - Cuarta  columna: Coordenada Z Cartesiana Tridimensional, en metros.
%           - Matriz de coordenadas UTM. Estructura, ver ayuda de Redgeo1.
%           - Matriz de observables GPS. Estructura, ver ayuda de redgeo1.
%           - cambio: 1-Si, 0-No. Introduccion de parametros sistematicos para los obs. GPS.
% Devuelve: - nipla: vector columna de tantas filas como puntos totales, en que en la columna correspondiente
%             figurara el numero de punto libre, en orden secuencial, para la compensacion planimetrica.
%           - nialt: vector columna de tantas filas como puntos totales, en que en la columna correspondiente
%             figurara el numero de punto libre, en orden secuencial, para la compensacion altimetrica.
%           - npip: variable escalar donde se almacenara el numero de puntos libres intervinientes en la 
%             compensacion planimetrica.
%           - npia: variable escalar donde se almacenara el numero de puntos libres intervinientes en la 
%             compensacion altimetrica.
%           - Matriz de observables GPS, sin las observaciones eliminadas.
%           - La matriz cct ampliada con las dos columnas.
% Ejemplo:  [nipla,nialt,npip,npia,gpsbien,cct]=eogps(cct,cp,gps,cambio);
