% Funcion:  prntdegbp
% Objeto:   - Realiza e imprime los Test de deteccion de Errores Groseros de Baarda y Pope.
% Recibe:   - Matriz con tantas filas como observables y cuatro columnas:
%             - Primera columna: Pe.
%             - Segunda columna: Pv.
%             - Tercera columna: Tipo de observable.
%               1-AX, 2-AY, 3-AZ, 4-Acimut GPS, 5-Distancia GPS., 6-Desnivel elipsoidal GPS
%               7-Direccion Clasica, 8-Distancia Clasica, 9-Desnivel elipsoidal Clasico.
%             - Cuarta columna: Unidad de residuos y errores medios cuadraticos.
%               1-metros, 2-radianes, 3-sex.cente, 4-sex.sexa,
%           - Vector columna con los errores medios cuadraticos a priori de los observables.
%           - Vector columna con los residuos de los observables.
%           - Vector columna con los residuos ponderados de los observables.
%           - Vector columna con los residuos tipificados, en el sentido de Baarda, de los observables.
%           - Vector columna con los estadisticos del Test de Pope de los observables.
%           - Vector columna con los numeros de redundancia de los observables.
%           - Vector columna con el minimo error detectable por el Test de Baarda de los observables.
%           - Vector columna con la Homogeneidad Interna de los observables.
%           - Vector columna con la Homogeneidad Externa de los observables.
%           - Escalar con la Media de los Numeros de Redundancia.
%           - Escalar con la Suma de los Numeros de Redundancia.
%           - Escalar con los grados de libertad del ajuste.
%           - Nivel de significacion del Test de Baarda.
%           - Potencia del Test de Baarda.
%           - Nivel de significacion del Test de Pope.
%           - Parametro de no centralidad del Test de Baarda.
%           - Cadena de caracteres con el nombre del fichero en el que imprimir.
%           - Cambio de unidad angular: 1 de seg.sex a seg.cent.
% Devuelve: - Matriz con observaciones detectadas como rechazables por el Test de Baarda.
%             Tiene tantas filas como observaciones rechazables se han detectado.
%             En la primera columna esta el numero de observacion.
%             En la segunda columna esta el estadistico del Test de Baarda.
%             Esta ordenada en orden creciente, el mayor en la ultima fila.
%           - Matriz con observaciones detectadas como rechazables por el Test de Pope.
%             Tiene tantas filas como observaciones rechazables se han detectado.
%             En la primera columna esta el numero de observacion.
%             En la segunda columna esta el estadistico del Test de Pope.
%             Esta ordenada en orden creciente, el mayor en la ultima fila.
% Ejemplo:  [eliminaB,eliminaP]=prntdegbp(baarda,EMC,R,RP,RT,T,NR,MED,HINT,HEXT,MNR,SNR,gradlib,alfabarda,betabarda,alfapope,delta0,fsalida,cang);
