% Funcion:  prncct
% Objeto:   Imprime listado de coordenadas cartesianas tridimensionales segun diferentes formatos en funcion
%           de un parametro recibido.
% Recibe:   - Matriz cctp, coordenadas fijas y aproximadas de partida:
%             cctp=[NP  C.X.C.T.  C.Y.C.T.  C.Z.C.T.
%                   ..  ........  ........  ........];
%           - Tipo de impresion.
%             1:  NP  C.X.C.T.  C.Y.C.T.  C.Z.C.T.
%           - Fichero de impresion.
% Ejemplo:  []=prncct(cct,tipoprn,fsalida);
