% Funcion:  mflsredgeo
% Objeto:   - Crea las matrices del sistema original, A, K y EMC, ( A y K ponderadas )
%             de la compensacion planimetrica o altimetrica de una Red Geodesica:
%             - con Observables GPS y Clasicos,
%             - Si es planimetrica:
%               - superficie de compensacion el elipsoide o el plano de la proyeccion UTM,
%               - con ecuaciones de observacion de acimut, direccion y distancia de linea geodesica
%               - con incognitas de posicion en diferenciales de Coordenadas Geodesicas y
%               - con o sin parametros ( un giro a acimut GPS y un factor de escala distancias GPS )
%                 para incluir la transformacion del Sistema de Referencia de los Observables GPS
%                 al definido por las coordenadas de los puntos fijos, y con ( o sin ) un factor de
%                 escala a las distancias clasicas.
%               - Las ecuaciones de acimut, direccion y las incognitas de coordenadas se plantean en segundos
%                 sexagesimales y las de distancia y resto de magnitudes lineales en metros.
%               - Las incognitas de descentrado, si las hay y no eliminan, iran en segundos sexa.
%               - La incognita de giro, si la hay, ira en segundos sexa.
%               - La incognita de factor de escala, si lo hay, ira en ppm.
%             - Si es altimetrica:
%               - Observaciones de desnivel elipsoidal, en metros.
%               - Incognitas de correccion a altitudes aproximadas en metros.
%               - Con posibilidad de incluir dos rotaciones como parametros sistematicos para realizar el cambio
%                 de Sistema de Referencia Geodesico de desniveles elipsoidales procendentes de GPS.
% Recibe:   - Matriz de coordenadas geodesicas:
%             Estructura de matriz de coordenadas:
%             - Primera columna: Numero de punto.
%             - Segunda columna: Latitud Geodesica, en radianes.
%             - Tercera columna: Longitud Geodesica, en radianes.
%             - Cuarto  columna: Altitud elipsoidal, en metros.
%             - Quinta  columna: Onduacion del Geoide, en metros.
%           - Matriz de coordenas UTM, con la estructura especificada en la ayuda de redgeo1.
%           - Numero de puntos incognita.
%           - Vector columna con el numero de incognita de cada punto.
%           - Matriz de observaciones, devuelta por las funciones pogps y/o pocla.
%           - Varianza a Priori del Observable de Peso Unidad.
%           - Columna de la incognita de giro gps, si no la hay 0. Si la compensacion es altimetrica sera de giro x.
%           - Columna del factor de escala gps, si no lo hay 0. Si la compensacion es altimetrica sera de giro y.
%           - Columna del factor de escala clasico, si no lo hay 0.
%           - Eliminar o no las incognitas de descentrado ( 1/0 ).
%           - Mumero de incognitas de descentrado.
%           - Matriz de desorientaciones, devuelta por cvuelta.
%           - Elipsoide del Sistema de Referencia Geodesico, como un vector fila:
%             elipsoide=[a alfa b e e'];
%           - Tipo de compensacion: 1 - Planimetrica, 2 - Altimetrica.
%           - Superficie: 1-Elipsoide, 2-P.P.UTM.
% Devuelve: - Matriz A de dise�o del Sistema Original, Ponderada.
%             Las ultimas cuatro columnas corresponden a las incognitas de la transformacion,
%             primero el factor de escala y a continuacion giros en X, Y, Z.
%           - Vector K de terminos independientes del Sistema Original, Ponderado.
%           - Vector Columna con los EMC a priori, en metros para distancias y en seg.sexa para acimutes.
%           - Matriz Baarda que contiene para cada ecuacion:
%             - Primera columna: Pe.
%             - Segunda columna: Pv.
%             - Tercera columna: Tipo de observable.
%               4-Acimut GPS, 5-Distancia GPS., 6-Desnivel elipsoidal GPS, 7-Direccion Clasica
%               8-Distancia Clasica, 9-Desnivel elipsoidal clasico.
%             - Cuarta columna: Unidad de residuos y errores medios cuadraticos.
%               1-metros, 2-radianes, 3-sex.cente, 4-sex.sexa,
%             Se utilizara en los listados.
%           - La matriz de desorientaciones porque en caso de eliminar el descentrado de una compensacion
%             se almacena ( en la col.5 ) el sumatorio de los pesos del bloque de ecuaciones de direccion de cada
%             vuelta para, posteriormente, obtener la correccion necesaria a los numeros de redundancia. En la
%             columna cuarta figura el punto estacion.
% Ejemplo:  [A,K,EMC,baarda,vuelta]=mflsredgeo(cg,cp,npi,ni,obs,VARPRI,colgirogps,colfescalagps,colfescalacla,delides,nides,vuelta,elipsoide,compentipo,superficie);