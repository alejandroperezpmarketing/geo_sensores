% Funcion:  prntgmgm
% Objeto:   - Realiza el Test Global del Modelo Gauss-Markov de una compensacion de una cola.
%           - Lo imprime en el fichero indicado. 
% Recibe:   - Varianza del Observable de Peso Unidad a Priori.
%           - Estimador de la Varianza del Observable de Peso Unidad.
%           - Media de Residuos Ponderados ( para imprimirlos ).
%           - Nivel de significacion del Test.
%           - Grados de libertad del Modelo.
%           - Fichero de salida.
% Devuelve: - 1/0 segun no se rechaze o se rechaze.
% Ejemplo:  [tg]=prntgmgm(VARPRI,VAR,MRP,alfaglobal,gradlib,fsalida);
