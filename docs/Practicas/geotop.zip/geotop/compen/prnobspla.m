% Funcion:  prnobspla
% Objeto:   Imprime el listado de observaciones planimetricas de una compensacion.
% Recibe:   - Matriz de observaciones con la estructura:
%             - Cada fila corresponde a una observacion.
%             - Primera columna: Tipo de observacion:
%                                1 - Acimut GPS en la superficie de compensacion.
%                                2 - Distancia GPS en la superficie de compensacion.
%                                3 - Direccion clasica en la superficie de compensacion.
%                                4 - Distancia clasica en la superficie de compensacion.
%             - Segundo columna: Punto estacion.
%             - Tercera columna: Punto visado.
%             - Cuarta  columna: Observable. Angular en radianes. Lineal en metros.
%             - Quinta  columna: Precision. Angular en radianes. Lineal en metros.
%             - Sexta   columna: Si la observacion es de direccion, el numero de incognita
%                                de descentrado.
%           - Fichero de impresion.
% Devuelve: - Numero de ecuaciones de observacion de acimut GPS.
%           - Numero de ecuaciones de observacion de distancia GPS.
%           - Numero de ecuaciones de observacion de direccion clasica.
%           - Numero de ecuaciones de observacion de distancia clasica.
% Ejemplo:  [nazigps,ndisgps,ndircla,ndiscla]=prnobspla(obspla,fsalida);
