% Funcion:  pocla
% Objeto:   - Pasa una matriz de observables Clasicos a dos matrices: de observables Planimetricos y Altimetricos.
%             - En la matriz de observables planimetricos:
%               - Observacion de direccion de la linea geodesica en la superficie elegida de compensacion,
%                 elipsoide o plano de la Proyeccion UTM, del Sistema de Referencia Geodesico indicado, en radianes.
%               - Observacion de distancia de la linea geodesica en la superficie elegida de compensacion,
%                 elipsoide o plano de la Proyeccion UTM, del Sistema de Referencia Geodesico indicado, en metros.
%             - En la matriz de observables altimetricos:
%               - Observacion de desnivel elipsoidal, en metros.
%           - Se calcula y almacena la precision a priori de cada observable anterior a partir de la inclusion
%             en la matriz de observables clasicos de un codigo de union con una matriz de caracteristicas de
%             instrumentos.
% Recibe:   - Matriz de Coordenadas Geodesicas.
%             Estructura de matriz de coordenadas:
%             - Primera columna: Numero de punto.
%             - Segunda columna: Latitud geodesica, en radianes.
%             - Tercera columna: Longitud geodesica, en radianes.
%             - Cuarta  columna: Altitud elipsidal, en metros.
%             - Quinta  columna: Ondulacion del geoide, en metros.
%           - Matriz de observaciones Clasicas. Estructura, ver ayuda de redgeo1.
%           - Matriz de vueltas de horizonte. Estructura, ver ayuda cvuelta.
%           - Metodo de calculo del desnivel elipsoidal: 1-Geodesia Geometrica, 2-Clasico.
%           - Coeficiente de refraccion para el espectro visible. Si se recibe 0 toma el estandar, 0.08.
%           - 1/0, aplicar o no correccion de refraccion atmosferica a las lecturas cenitales.
%           - 1/0, aplicar o no desviacion de la vertical a las lecturas cenitales.
%           - Matriz de instrumentos. Estructura, ver ayuda de redgeo1.
%           - Matriz de observaciones planimetricas y altimetricas. Si ademas de Clasicas hay observaciones GPS
%             en la Red que se pretende compensar, ya tendran las correspondientes observaciones.
%           - Elipsoide del Sistema de Referencia Geodesico, como un vector fila:
%             elipsoide=[a alfa b e e'];
%           - Superficie elegida para la compensacion: 1-Elipsoide, 2-Plano Proyeccion UTM.
%           - Numero de huso elegido para la compensacion.
% Devuelve: - Matriz de observaciones planimetricas sobre la superficie del elipsoide,
%             con la estructura:
%             - Cada fila corresponde a una observacion.
%             - Primera columna: Tipo de observacion:
%                                3 - Direccion clasica en la superficie de compensacion.
%                                4 - Distancia clasica en la superficie de compensacion.
%             - Segundo columna: Punto estacion.
%             - Tercera columna: Punto visado.
%             - Cuarta  columna: Observable. Angular en radianes. Lineal en metros.
%             - Quinta  columna: Precision. Angular en radianes. Lineal en metros.
%             - Sexta   columna: Si es tipo 3, numero de incognita de descentrado.
%           - Matriz de observaciones para la compensacion Altimetrica
%             con la estructura:
%             - Cada fila corresponde a una observacion.
%             - Primera columna: Tipo de observacion:
%                                2 - Desnivel elipsoidal clasico.
%             - Segundo columna: Punto estacion.
%             - Tercera columna: Punto visado.
%             - Cuarta  columna: Observable, angular en radianes o lineal en metros.
%             - Quinta  columna: Precision, angular en radianes o lineal en metros.
% Ejemplo:  [obspla,obsalt]=pocla(cg,cla,vuelta,nivela,k,aplicak,aplicadesv,instru,obspla,obsalt,elipsoide,superficie,huso);
