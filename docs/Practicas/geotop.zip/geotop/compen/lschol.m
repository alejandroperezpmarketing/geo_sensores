% Funcion:  lschol
% Objeto:   - Resuelve un problema m�nimos cuadrados:
%             - Caso rango completo, LS-regular, utilizando el metodo de la factorizacion
%               de Cholesky de la matriz del sistema de ecuacione normales.
%             - Caso rango incompleto, descomposicion en valores singulares de la matriz del 
%               sistema original.
%           - Los defectos de rango son los deducidos a partir del rango teorico que se le
%             envia a la funcion. Esto es debido a que el rango numerico y el teorico pueden
%             no coincidir en una compensacion sobre la superficie del elipsoide.
%           - Realiza calculos para devolver un conjunto de variables utiles en la 
%             compensacion de una Red Geodesica. Ver las variables devueltas.
% Recibe:   - Matriz de dise�o de las incognitas del Sistema Original Ponderada.
%           - Vector columna de terminos independientes del Sistema Original Ponderado.
%           - Vector columna con los errores medios cuadraticos de cada ecuacion.
%           - Nivel de significacion del Test de Baarda.
%           - Potencia de Test de Baarda.
%           - Varianza a Priori.
%           - Numero de incognitas de descentrado.
%           - 1/0, segun se hayan eliminado o no las incognitas de descentrado.
%           - Matriz que en la primera columna incluye el tipo de observacion para cada observacion,
%             y en la segunda el punto estacion. Se utiliza para aplicar la correccion a los numeros de
%             redundancia de las observaciones de direccion si fueron eliminadas estas incognitas.
%           - Matriz de desorientaciones que en la quinta columna incluye el sumatorio de los pesos de las
%             observaciones de direccion de la vuelta, utilizada para corregir los numeros de redundancia.
%             En la quinta columna incluye el punto estacion.
%           - Rango Teorico en funcion de los constre�imientos y observaciones.
% Devuelve: - Estimacion de la Varianza del Observable de Peso Unidad.
%           - Vector columna de Incognitas.
%           - Matriz Cofactor de las Incognitas.
%           - Vector columna de Residuos Ponderados de la Observacion correspondiente.
%           - Vector columna de Residuos Sin Ponderar de la Observacion correspondiente.
%           - Vector columna de Numeros de Redundancia de la Observacion correspondiente.
%           - Vector columna de Homogeneidad Interna de la Observacion correspondiente.
%           - Vector columna de Homogeneidad Externa de la Observacion correspondiente.
%           - Vector columan de Minimo Error Detectable de la Observacion correspondiente.
%           - Escalar con el Sumatorio de los Numeros de Redundancia.
%           - Escalar con la Media de los Numeros de Redundancia.
%           - Escalar con la Media de los Residuos Ponderados.
%           - Vector columna con los Residuos Tipificados en el sentido de Baarda.
%           - Vector columna con los estadisticos del Test de Pope.
%           - Rango num�rico de A.
%           - Parametro de no centralidad del Test de Baarda.
% Ejemplo:  [VAR,X,QXX,RP,R,NR,HINT,HEXT,MED,SNR,MNR,MRP,RT,T,rangonA,delta0]=lschol(A,K,EMC,alfabaarda,betabaarda,VARPRI,nides,delides,obs,vuelta,rangoT);
