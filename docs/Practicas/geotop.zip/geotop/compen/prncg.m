% Funcion:  prncg
% Objeto:   Imprime listado de coordenadas geodesicas segun diferentes formatos en funcion
%           de un parametro recibido.
% Recibe:   - Matriz de Coordenadas Geodesicas.
%             Estructura de matriz de coordenadas:
%             - Primera columna: Numero de punto.
%             - Segunda columna: Latitud geodesica, en radianes.
%             - Tercera columna: Longitud geodesica, en radianes.
%             - Cuarta  columna: Altitud elipsidal, en metros.
%             - Quinta  columna: Ondulacion del geoide, en metros.
%             Si el tipo de impresion es 2, tambien deben figurar, para cada punto libre:
%             - Sexta      columna: Varianza en latitud, en metros cuadrados.
%             - Septima    columna: Varianza en longitud, en metros cuadrados.
%             - Octava     columna: Semieje mayor de elipse de error en el plano tangente, en metros.
%             - Novena     columna: Semieje menor de elipse de error en el plano tangente, en metros.
%             - Decima     columna: Acimut del semieje mayor de elipse en el plano tangente, en radianes.
%             - Onceava    columna: Correccion a la latitud geodesica aproximada, en seg.sexa.
%             - Doceava    columna: Correccion a la longitud geodesica aproximada, en seg.sexa.
%             - Treceava   columna: Desplazamiento en metros a las coordenadas aproximadas.
%             - Catorceava columna: Varianza en altitud elipsoidal, en metros cuadrados.
%             - Quinceava  columna: Correccion a la altitud elipsoidal aproximada, en metros.
%             Las columnas 14 y 15 deben figurar tambien si el tipo de impresion es 4.
%           - Matriz de coordenadas UTM. Estructura, ver ayuda de redgeo1.
%           - nipla: vector columna de tantas filas como puntos totales, en que en la columna correspondiente
%             figurara el numero de punto libre, en orden secuencial, para la compensacion planimetrica.
%             Si el tipo de impresion es 4, en lugar de recibir nipla, recibiria nialt ( similar para altimetria ).
%           - Tipo de impresion.
%             1:  NP     Latitud        Longitud      H-ORT.    h-ELIP.    ONDULACION.
%             2: 	NP     LAT.   E.LAT.   LON.    E.LON.    a      b     azim.a.   h.elip.     E.h.      H-ORT.
%             3:  NP     DESP.  D.LAT.   LAT.    D.LON.    LON.   a     b         azim.a.     h.elip.
%             4:  NP     dif.h.     h.Elip.      emc.h.      H.Orto.
%           - Nivel de confianza para las figuras de error.
%           - Fichero de impresion.
% Devuelve: - No devuelve nada.
% Ejemplo:  []=prncg(cg,cp,nipla,tipoprn,elipconf,fsalida);
