% Funcion:  cvuelta
% Objeto:   - Realiza diferentes calculos relativos a las vueltas de horizonte definidas por los observables
%             clasicos para servir posteriormente en una compensacion.
%           - Los datos de cada vuelta que se determinan son: numero de incognita de descentrado, desorientacion
%             media ponderada y numero de visuales incluidas en la vuelta. 
%           - Solo maneja una incognita de descentrado por punto por lo que si hay varias han debido ser
%             refundidas previamente.
%           - La desorientacion se puede calcular relativa a tres sistemas de coordenadas distintas:
%             componentes ENU, sobre el elipsoide y sobre el plano de la proyeccion UTM.
%           - Imprime resultados en el fichero indicado.
% Recibe:   - Matriz cg, coordenadas fijas y aproximadas de partida:
%             - Primera columna: Numero de punto.
%             - Segunda columna: Latitud geodesica, en radianes.
%             - Tercera columna: Longitud geodesica, en radianes.
%             - Cuarta  columna: Altitud elipsoidal, en metros.
%             - Quinta  columna: Ondulacion del geoide, en metros.
%           - Matriz cp, de coordenadas UTM. Estructura, ver ayuda redgeo1.
%           - Matriz de observables clasicos. Estructura, ver ayuda de redgeo1.
%           - Matriz de instrumentos. Estructura, ver ayuda de redgeo1.
%           - Vuelta, matriz de ceros con tantas filas como numero de puntos y tres columnas.
%           - Superficie, variable escalar: 1-Elipsoide, 2-Plano Proyeccion UTM.
%           - Elipsoide de trabajo, con la estructura:
%             elispoide=[a alfa b e e'].
%           - Nombre, con toda la ruta, del fichero donde se desea la salida.
% Devuelve: - La misma matriz recivida Vuelta en la que se incluira como informacion en sus columnas:
%             - Columna 1: Numero de incognita de descentrado asignada al punto correspondiente a esa fila.
%               Valdra -1 si hay que eliminar esa vuelta por cualquiera de los motivos:
%               - Solo incluye una visual en la vuelta.
%               - Solo incluye varias visuales a un mismo punto.
%               - Solo interviene puntos fijos en la vuelta.
%             - Columna 2: Desorientacion Media Ponderada, en radianes.
%             - Columna 3: Numero de visuales incluidas en la vuelta.
%           - Numero de incognitas de descentrado, es decir, numero de vueltas.
%             Coincidira con el numero de puntos si en todos se ha realizado vuelta.
% Ejemplo:  [vuelta,nides]=cvuelta(cg,cp,cla,instru,vuelta,superficie,elipsoide,fsalida);
