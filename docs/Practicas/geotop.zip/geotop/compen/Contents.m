% Libreria GeoTop: 	Compen
%
%Cvuelta.   - realiza diferentes calculos relativos a las vueltas de horizonte, a partir de observables cl�sicos,
%             como paso previo para la compensaci�n.
%Eocla.     - eliminaci�n de observaciones de una libreta cl�sica, previamente a la compensaci�n, por diferentes
%             planteamientos incorrectos: vuelta de horizonte con una �nica visual, ...
%Eogps.     - eliminaci�n de observaciones GPS de un fichero, previamente a la compensaci�n, por diferentes 
%             planteamientos incorrectos: observaciones entre puntos fijos sin par�metros sistem�ticos, ...
%Lschol.    - soluci�n num�rica de datos relativos a un problema de m�nimos cuadrados ( vector de inc�gnitas,
%             residuos, matriz cofactor de las inc�gnitas, par�metros de test de Baarda y Pope, ... ) utilizando
%             la descomposici�n de Cholesky o SVD, seg�n el problema sea de rango completo o incompleto,
%             respectivamente. Se contempla el c�lculo correcto de los n�meros de redundancia de los observables, 
%             en el caso de haber eliminado las inc�gnitas de descentrado.
%Lsredgeo.  - funci�n principal de la compensaci�n m�nimos cuadrados de una red geod�sica tridimensional, 
%             que contempla observables cl�sicos y GPS, compensaci�n planim�trica en el elipsoide o el plano UTM, ... 
%             Esta funci�n llama a la mayor�a de funciones restantes de este apartado de la librer�a.
%Mfgpstri.  - monta el sistema original de la compensaci�n de una red geod�sica, a partir de observables GPS en
%             coordenadas cartesianas tridimensionales. Contempla la introducci�n en el modelo de los cuatro 
%             par�metros de transformaci�n de sistema de referencia, a aplicar a los vectores GPS.
%Mflsredgeo.- monta el sistema original de la compensaci�n de una red geod�sica tridimensional para la 
%             funci�n Lsredgeo.
%Pocla.     - paso de una matriz tipo libreta de observaciones cl�sicas, a observaciones preparadas para una 
%             compensaci�n planim�trica y otra altim�trica. Tambi�n se c�lcula la precisi�n a priori de los 
%             correspondientes observables de compensaci�n, a partir de las caracter�sticas del instrumental 
%             utilizado en las observaciones.
%Pogps.     - paso de una matriz tipo libreta de observaciones GPS, a observaciones preparadas para una compensaci�n
%             planim�trica y otra altim�trica. Tambi�n se c�lcula la precisi�n a priori de los correspondientes 
%             observables de compensaci�n, a partir de las caracter�sticas del instrumental utilizado en 
%             las observaciones.
%Prncct.    - funci�n de impresi�n de datos en coordenadas cartesianas tridimensionales, seg�n diferentes formatos
%             codificados.
%Prncg.     - funci�n de impresi�n de datos en coordenadas geod�sicas, seg�n diferentes formatos codificados.
%Prncp.     - funci�n de impresi�n de datos en coordenadas sobre la proyecci�n UTM, seg�n diferentes 
%             formatos codificados.
%Prnobsalt. - funci�n de impresi�n de los observables que intervienen en una compensaci�n altim�trica.
%Prnobspla. - funci�n de impresi�n de los observables que intervienen en una compensaci�n planim�trica.
%Prntdegbp. - funci�n de impresi�n de la informaci�n relativa a los test de detecci�n de errores groseros 
%             de Baarda y Pope.
%Prntgmgm.  - funci�n de impresi�n del resultado del test global del modelo de Gauss-Markov.
%Vxyzvflh.  - paso de la figura de error en cartesianas tridimensionales, a la elipse de error en el plano 
%             tangente al elipsoide, y al error en altitud elipsoidal.
