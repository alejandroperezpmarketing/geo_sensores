% Funcion:  prnobsalt
% Objeto:   Imprime el listado de observaciones altimetricas de una compensacion.
% Recibe    - Matriz de observaciones para la compensacion Altimetrica
%             con la estructura:
%             - Cada fila corresponde a una observacion.
%             - Primera columna: Tipo de observacion:
%                                1 - Desnivel elipsoidal GPS.
%             - Segundo columna: Punto estacion.
%             - Tercera columna: Punto visado.
%             - Cuarta  columna: Observable, angular en radianes o lineal en metros.
%             - Quinta  columna: Precision, angular en radianes o lineal en metros.
%           - Fichero de impresion.
% Devuelve: - Numero de ecuaciones de observacion de desnivel elipsoidal GPS.
%           - Numero de ecuaciones de observacion de desnivel elipsoidal clasico.
% Ejemplo:  [ndegps,ndecla]=prnobsalt(obsalt,fsalida);
