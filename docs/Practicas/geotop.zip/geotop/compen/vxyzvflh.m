% Funcion:  vxyzvflh
% Objeto:   - Paso de una figura de error tridimensional en XYZ, Coordenadas Cartesianas Tridimensionales,
%             a latitud, longitud y altitud elipsoidal, Coordenadas Geodesicas.
% Recibe:   - Latitud geodesica del punto, en radianes.
%           - Longitud geodesica del punto, en radianes.
%           - Altitud elipsoidal del punto, en metros.
%           - Varianza en X Cartesiana Tridimensinal, en metros cuadrados.
%           - Varianza en Y Cartesiana Tridimensinal, en metros cuadrados.
%           - Varianza en Z Cartesiana Tridimensinal, en metros cuadrados.
%           - Covarianza X-Y, en metros cuadrados.
%           - Covarianza X-Z, en metros cuadrados.
%           - Covarianza Y-Z, en metros cuadrados.
%           - Elipsoide del Sistema de Referencia Geodesico, como un vector fila:
%             elipsoide=[a alfa b e e'];
% Devuelve: - Varianza en latitud geodesica, en metros al cuadrado.
%           - Varianza en longitud geodesica, en metros al cuadrado.
%           - Varianza en altitud elipsoidal, en metros al cuadrado.
%           - Semieje mayor de la elipse de error en el plano tangente, en metros.
%           - Semieje menor de la elipse de error en el plano tangente, en metros.
%           - Azimut geodesico del semieje mayor de la elipse de error en el plano tangente, en radianes.
% Ejemplo:  [varfi,varlon,varh,semia,semib,azia]=vxyzvflh(lat,lon,h,varx,vary,varz,covarxy,covarxz,covaryz,elipsoide)
