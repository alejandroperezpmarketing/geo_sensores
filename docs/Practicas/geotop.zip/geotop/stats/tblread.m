function [data,varnames,casenames] = tblread(filename,delimiter)
%TBLREAD Retrieves tabular data from the file system.
%   [DATA, VARNAMES, CASENAMES] = TBLREAD(FILENAME,DELIMITER) Retrieves
%   a file with variable names in the first row, case names
%   in the first column and data starting in the (2,2) position. FILENAME is 
%   the complete path to the desired file.
%   By default TBLREAD assumes space delimited files. 
%   Allowable values of DELIMITER are the strings:
%       'tab'
%       'space'
%       'comma'       
%   VARNAMES is a string matrix containing the variable names 
%   in the first row.
%   CASENAMES is a string matrix containing the names of each
%   case in the first column.
%   DATA is a numeric matrix with a value for each variable-case
%   pair.

%   B.A. Jones 1-4-94
%   Copyright (c) 1993-97 by The MathWorks, Inc.
%   $Revision: 2.5 $  $Date: 1997/04/08 15:14:16 $

if nargin == 1
  delimiter = ' ';
elseif strcmp(delimiter,'tab')
  delimiter = '	';
elseif strcmp(delimiter,'space')
  delimiter = ' ';
elseif strcmp(delimiter,'comma')
  delimiter = ',';
else
  error('Sorry, TBLREAD does not support the specified delimiter.');
end

if nargin == 0
   [F,P]=uigetfile('*');
   filename = [P,F];
end
if isempty(filename)
   [F,P]=uigetfile('*');
   filename = [P,F];
end
  
fid = fopen(filename,'r');

if fid == -1
   disp('Unable to open file.');
   return
end

line1 = fgetl(fid);

line1 = deblank(line1);
line1 = fliplr(deblank(fliplr(line1)));
line1 = strrep(line1,'(','_');
line1 = strrep(line1,')','');
line1 = strrep(line1,'.','_');
oldline1 = [];

while ~strcmp(line1,oldline1)
   oldline1 = line1;
   line1 = strrep(line1,'  ',' ');
   line1 = strrep(line1,'__','_');
end
line1 = [line1,delimiter];
idx = findstr(line1,delimiter);
if idx(1) ~= 1
   idx = [1 idx+1];
   line1 = [delimiter, line1];
end
strlength = diff(idx)-1;
maxl = max(strlength);
nvars = length(idx)-1;
b = ' ';
varnames = b(ones(nvars,1),ones(maxl,1));
for k = 1:nvars;
   varnames(k,1:strlength(k)) = line1(idx(k)+1:idx(k+1)-1);
end

if strcmp(computer,'MAC2')
   lf = setstr(13);
else
   lf = setstr(10);
end

[bigM,count] = fread(fid,Inf);
if bigM(count) ~= lf
   bigM = [bigM; lf];
end

newlines = find(bigM == lf);
nobs = length(newlines);

delimitidx = find(bigM == real(delimiter));
if length(delimitidx) ~= nobs*nvars
   error('Requires the same number of delimiters on each line.');
end
if nvars > 1
   delimitidx = (reshape(delimitidx,nvars,nobs))';
end
fclose(fid);

startlines = newlines;
startlines(nobs) = [];
startlines = [0;startlines];
clength = delimitidx(:,1) - startlines;
maxlength = max(clength);
casenames = ' ';
casenames = casenames(ones(nobs,1),ones(maxlength,1));
data = zeros(nobs,nvars);
for k = 1:nobs
    casenames(k,1:clength(k)) = setstr((bigM(startlines(k)+1:startlines(k)+clength(k)))');
    for vars = 1:nvars
       if vars == nvars
            data(k,vars) = str2num(setstr(bigM(delimitidx(k,vars)+1:newlines(k)-1)'));
       else
            data(k,vars) = str2num(setstr(bigM(delimitidx(k,vars)+1:delimitidx(k,vars+1)-1)'));
       end
    end
end
