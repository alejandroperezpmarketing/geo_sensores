function y = iqr(x)
%IQR    Interquartile Range. 
%   Y = IQR(X) calculates the interquarile range (IQR) of the input.
%   Given a vector input, the IQR is formed by subtracting the 25th 
%   percentile of the data from the 75th percentile of the data.
%   (See PRCTILE)
%
%   The IQR is a robust estimate of the spread of the data since changes
%   in the upper and lower 25% of the data do not affect it.

%   Copyright (c) 1993-97 by The MathWorks, Inc.
%   $Revision: 2.4 $  $Date: 1997/04/08 15:06:22 $

zlo = prctile(x,25);
zhi = prctile(x,75);
y = zhi - zlo;
