function [p, sep, proj, scaling] = polyfitp(x,y,degree)
%POLYFITP Polynomial curve fitting using projection.
%   [P, SEP, PROJ, SCALING] = POLYFITP(X,Y,DEGREE) finds the coefficients, P,
%    of a polynomial of the specified DEGREE that is the least squares fit of
%   Y with respect to the orthogonal basis formed using the vector of
%   inputs, X. SEP is the standard error of P.

%   Copyright (c) 1993-97 by The MathWorks, Inc.
%   $Revision: 1.2 $

x = x(:);
y = y(:);
n = length(x);

if nargin == 2
   degree = 1;
end

scaling = zeros(1,degree);
scaling(1) = 1;

X = ones(n,1);

proj = zeros(degree);

for k = 1:degree
   xk = ((x - proj(1,1))/scaling(1)).^k;
   p  = X\xk;
   proj(1:k,k) = p;
   r =  xk - X*p;

   if r'*r > n*eps
      scaling(k) = sqrt(r'*r/n);
      r = r/scaling(k);
      X = [X r];
   end
end
scaling(degree+1) = sqrt(n);
nc = size(X,2);
p = X'*y/n;

residuals = y - X*p;
df = n-nc;
rmse = sqrt((residuals'*residuals)/df);
sep = rmse/sqrt(n);
