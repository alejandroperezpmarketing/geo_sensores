function [m, v] = nbinstat(r,p)
%NBINSTAT Mean and variance of the negative binomial distribution.
%   [M, V] = NBINSTAT(R,P) returns the mean and variance of the
%   negative binomial distibution with parameters R and P.

%   Copyright (c) 1993-97 by The MathWorks, Inc.
%   $Revision: 2.5 $  $Date: 1997/04/08 15:08:22 $

if nargin < 2, 
    error('Requires two input arguments.'); 
end

[errorcode r p] = distchck(2,r,p);

if errorcode > 0
    error('Requires non-scalar arguments to match in size.');
end

q = 1 - p;
m = r .* q ./ p;
v = r .* q ./ (p .* p);

% Return NaN for parameter values outside their respective limits.
k = find(p<0 | p>1 | r<1 | round(r)~=r);
if any(k)
    tmp = NaN;
    m(k) = tmp(ones(size(k)));
    v(k) = m(k);
end
