function [m,v]= unidstat(n);
%UNIDSTAT Mean and variance for uniform (discrete) distribution.
%   [M,V] = UNIDSTAT(N) returns the mean and variance of
%   the (discrete) uniform distribution on {1,2,...,N}

%   Copyright (c) 1993-97 by The MathWorks, Inc.
%   $Revision: 2.5 $  $Date: 1997/04/08 15:15:32 $

if nargin < 1, 
    error('Requires one input argument.');   
end

%   Initialize the mean and variance to zero.
m = zeros(size(n));
v = m;

k = find(n > 0 & round(n) == n);
m(k) = (n(k) + 1) / 2;
v(k) = (n(k) .^ 2 - 1) / 12;

k1 = find(n <= 0 | round(n) ~= n);
if any(k1)
    tmp   = NaN;
    m(k1) = tmp(ones(size(k1)));
    v(k1) = m(k1);
end
