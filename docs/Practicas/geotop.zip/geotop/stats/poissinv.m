function x = poissinv(p,lambda)
%POISSINV Inverse of the Poisson cumulative distribution function (cdf).
%   X = POISSINV(P,LAMBDA) returns the inverse of the Poisson cdf 
%   with parameter lambda. Since the Poisson distribution is discrete,
%   POISSINV returns the smallest value of X, such that the poisson 
%   cdf evaluated, at X, equals or exceeds P.
%
%   The size of X is the common size of P and LAMBDA. A scalar input   
%   functions as a constant matrix of the same size as the other input.    

%   B.A. Jones 1-15-93
%   Copyright (c) 1993-97 by The MathWorks, Inc.
%   $Revision: 2.5 $  $Date: 1997/04/08 15:11:07 $

if nargin < 2, 
    error('Requires two input arguments.'); 
end

[errorcode p lambda] = distchck(2,p,lambda);

if errorcode > 0
    error('Requires non-scalar arguments to match in size.');
end

x = zeros(size(p));

cumdist = poisspdf(0,lambda);
count = 0;

% Compare P to the poisson cdf.
k = find(lambda > 0 & p >= 0 & p < 1);
while any(any(p(k) > cumdist(k)))
    count = count + 1;
    cumdist(k) = cumdist(k) + poisspdf(count,lambda(k));
    if count == 1
            x(k) = x(k) + 1;
    end
    index = find(cumdist(k) < p(k));
    x(k(index)) = x(k(index)) + 1;  
end

% Return NaN if the arguments are outside their respective limits.
k = find(lambda <= 0 | p < 0 | p > 1);
if any(k)
    tmp  = NaN;
    x(k) = tmp(ones(size(k)));
end

% Return Inf if p = 1 and lambda is positive.
k = find(lambda > 0 & p == 1);
if any(k)
    tmp  = Inf;
    x(k) = tmp(ones(size(k)));
end

