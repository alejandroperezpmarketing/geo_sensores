% Funcion : desor2
% Objeto  : dada una matriz de observaciones y otra de coordenadas aproximadas
%           calcula las desorientaciones medias de cada estacion
% Recibe  : matriz con coordenadas geograficas (np,lat,lon,h,fijo)
% Devuelve: Una matriz que contiene las desorientaciones y el error asociado (np,des,error)
% Ejemplo : [res]=desor2(obs,coor,elipsoide);