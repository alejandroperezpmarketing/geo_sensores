% Funcion:  intinv3
% Objeto:   Calculo de la interseccion inversa simple espacial basado en 
%           geodesia tridimensional.
%           Resuelve la posicion incognita, planimetria en Proyeccion UTM y altitud
%           ortometrica.
%           Resuelve tantas soluciones altimetricas como cenitales se hayan medido.
% Recibe:   - Matriz de datos, con la siguiente estructura:
%             Ejemplo,
%             datos=[ LAT-1  LON-1  HORT1  LHZ1  LV1  I1  M1  NI1  NV1
%                     LAT-2  LON-2  HORT2  LHZ2  LV2  I2  M2  NI2  NV2
%                     LAT-3  LON-3  HORT3  LHZ3  LV3  I3  M3  NI3  NV3];
%             - Cada fila corresponde a una observacion.
%             - Col. 1.: Latitud geodesica punto visado, en radianes.
%             - Col. 2.: Longitud geodesica punto visado, en radianes.
%                        El dominio de la longitud es [0,pi] U ]-pi,0]
%             - Col. 3.: Altitud ortometrica punto visado, en metros.
%             - Col. 4.: Lectura horizontal al punto visado, en radianes.
%             - Col. 5.: Lectura cenital, en radianes y corregida de refraccion.
%             - Col. 6.: Altura del instrumento, en metros.
%             - Col. 7.: Altura de punteria, en metros, respecto al punto cuya
%                        altitud ortometrica ha sido introducida en al col. 3.
%             - Col. 8.: Fila del instrumento utilizado en la matriz de instrumentos.
%           - Huso en que se desea la posicion del punto.
%             Si se envia 0 se determina en el huso que le corresponde al primer punto.
%           - Elipsoide de trabajo, con la estructura:
%             elispoide=[a alfa b e e'].
% Devuelve: - Matriz de soluciones, tantas como soluciones altimetricas,
%             con la misma solucion planimetrica, con la estructura:
%             - Col. 1.: Coord. X-UTM, en metros.
%             - Col. 2.: Coord. Y-UTM, en metros.
%             - Col. 3.: Altitud ortometrica, en metros.
%           - Numero de filas de la matriz anterior.
% Ejemplo:  [xx,t]=intinv3(datos,huso,elipsoide);
