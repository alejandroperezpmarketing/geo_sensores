% Libreria GeoTop:   C�lculo
%
%Calcla3d.- c�lculo de redes geod�sicas tridimensionales, a partir de 
%           observaciones cl�sicas.
%Calgps.  - c�lculo de redes geod�sicas tridimensionales, a partir de 
%           observaciones GPS.
%Ccid3dsl.- c�lculo de todos los puntos posibles de una red topogr�fica 
%           tridimensional, por intersecci�n directa m�ltiple. 
%           Utiliza un sistema de referencia local. Est� pensado para resolver, 
%           entre otros problemas, el c�lculo de los puntos de apoyo para 
%           fotogrametria terrestre.
%Intdir3. - c�lculo de intersecci�n directa simple, aplicando m�todos de 
%           geodesia tridimensional.
%Intdir3e.- igual que la anterior, pero calculando tambi�n la previsi�n 
%           del error propagado.
%Intdis3. - c�lculo de intersecci�n de distancias simple, aplicando m�todos
%           de geodesia tridimensional.
%Intdis3e.- igual que la anterior, pero calculando tambi�n la previsi�n del 
%           error propagado.
%Intinv2. - c�lculo de la intersecci�n inversa simple en un plano.
%Intinv2e.- igual que la anterior, pero calculando tambi�n la previsi�n del 
%           error propagado.
%Intinv3. - c�lculo de la intersecci�n inversa simple, aplicando m�todos de 
%           geodesia tridimensional.
%Intinv3e.- igual que la anterior, pero calculando tambi�n la previsi�n del 
%           error propagado.
%Radia3.  - c�lculo de la radiaci�n simple, aplicando m�todos de geodesia 
%           tridimensional.
%Radia3e. - igual que la anterior, pero calculando tambi�n la previsi�n del 
%           error propagado.
%Replautm3.-c�lculo riguroso de los datos de replanteo, a partir de la 
%           proyecci�n UTM y de altitudes ortom�tricas, aplicando m�todos de
%           geodesia tridimensional.
%Vxyzvpa. - paso de la figura de error, en cartesianas tridimensionales, 
%           al error planimetrico sobre el plano UTM, y error en altitud ortom�trica.
