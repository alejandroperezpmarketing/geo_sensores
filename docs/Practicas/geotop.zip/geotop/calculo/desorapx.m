% Funcion : desorapx
% Objeto  : dada una matriz de observaciones y otra de coordenadas aproximadas
%           calcula la desorientaci�n aproximada de cada estacion. Emplea el
%           m�todo de Bessel para resolver el problema inverso de la
%           geodesia.
% Recibe  : - matriz 'coor' con las coordenadas aproximadas de los puntos
%           cuyas coordenadas se conocen y con al menos las siguientes columnas
%          [np latitud longitud] estando la latitud y la longitud expresadas en radianes
%
%           - matriz 'obs' con al menos las siguientes columnas [pe pv lh ]
%           estando la lectura horizontal expresada en grados centesimales,
%           como por ejemplo:
%
%           465    5055    263.2184    104.0633   1.536   1.800    2058.507     4
%           465    5061     19.8985    107.1020   1.536   1.800    2316.882     4
%           465    5058    169.6558    100.7278   1.536   1.800    3263.087     4
%
%           - vector con los par�metros del elipsoide (ver funci�n parelip).
%
% Devuelve: Una matriz que contiene las desorientaciones y el error asociado (np,des,error)
% Ejemplo : [res]=desorapx(obs,coor,elipsoide);
