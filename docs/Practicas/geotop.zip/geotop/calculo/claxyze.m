% Funcion : claxyze
% Objeto  : calcula los incrementos de coordenadas cartesianas geoocentricas a 
%				partir de observaciones clasicas propagando el error
% Recibe  : az,ce, dg, hi, hm,lat p.est, lon p.est, error az, error ce. y error dg
% Devuelve: DX,DY,DZ,varXX,varYY,varZZ,covarXY,covarXZ,covarYZ
% Ejemplo : [dx,dy,dz,vxx,vyy,vzz,vxy,vxz,vyz]=claxyze(az,ce,dg,lat,lon,eaz,ece,edg);
