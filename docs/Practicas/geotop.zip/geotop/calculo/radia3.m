% Funcion:  radia3
% Objeto:   Calculo de la radiacion simple espacial basado en 
%           geodesia tridimensional.
%           Resuelve la posicion incognita, planimetria en Proyeccion UTM y altitud
%           ortometrica.
% Recibe:   - Datos del punto estacion:
%             - Latitud geodesica, en radianes.
%             - Longitud geodesica, en radianes.
%               El dominio de la longitud es [0,pi] U ]-pi,0]
%             - Altitud Ortometrica, en metros.
%             - Desorientacion de la vuelta, en radianes.
%           - Lectura horizontal al punto, en radianes.
%             Ha de estar en la misma vuelta de horizonte en que se conode la desorientacion.
%           - Lectura cenital, en radianes y corregida de refraccion.
%           - Distancia geometrica, en metros.
%           - Altura de instrumento, en metros.
%           - Altura de prisma, en metros.
%           - Elipsoide de trabajo, con la estructura:
%             elispoide=[a alfa b e e'].
%           - Huso en que se desea la posicion del punto.
%             Si se envia 0 se determina en el huso que le corresponde por su long. geodesica.
% Devuelve: - Posicion planimetrica calculada, en UTM y en metros.
%           - Altitud ortometrica calculada, en metros.
% Ejemplo:  [x,y,z]=radia3(fipe,lonpe,hpe,despe,lhz,lv,dg,ai,am,elipsoide,huso);
