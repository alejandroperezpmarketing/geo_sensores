% Funcion:  poligel
% Objeto:   Calculo de una poligonal empleando el modelo funcional elipsoidal
% Recibe:   Matriz de lectura horizontales reducidas al elipsoide ( pe pv  lh(rad)  error(rad) )
%           Matriz de distancias reducidas al elipsoide ( pe pv  dr(m)  error(m) )
%           Matriz de diferencias de altitud elipsoidal ( pe pv  dh(m)  error(m) )
%           Matriz de coordenadas  geodesicas ( num  lat(rad)   lon(rad)   h(m)  )
%           Elipsoide de referencia dels sistema al que estan referidas las coordenadas anteriores.
%           Matriz con la secuencia de la poligonal [ ref_inicial punto 1 punto 2 .... punto n  ref_final]
% Devuelve: Matriz de coordenadas geodesicas y error asociado
%           ( num  lat(rad)   lon(rad)   h(m)  varlat varlon varhel  covlatlon covlathel covlonhel)
%           Error de cierre en latitud,en longitud, en altitud y angular
%           Un n�mero de control que puede adquirir los siguientes valores:
%           0 - Calculo efectuado sin problemas
%           1 - No se encuentran las coordenadas de un punto de arranque
%           2 - No se puede calcular la desorientacion de la primera estacion
%           3 - Falta una observacion angular, de distancia o de desnivel
%           4 - No se encuentran las coordenadas de un punto de finalizacion
%           5 - No se puede calcular la desorientacion de la ultima estacion
%           6 - No se puede calcular el error de cierre angular
% Ejemplo:  [res,errlat,errlon,errhel,errang,control] = poligel(obsdir,obsdis,obsalt,geo,elipsoide,secuencia);