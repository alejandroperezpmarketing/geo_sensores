% Funcion:  replautm3
% Objeto:   Calculo de datos de replanteo a partir de coordenadas en
%           Proyeccion UTM y altitud ortometrica.
% Recibe:   - Matriz de coordenadas:
%             Estructura de matriz de coordenadas:
%               - Primera columna: Numero de punto.
%               - Segunda columna: Coordenada X-UTM.
%               - Tercera columna: Coordenada Y-UTM.
%               - Cuarta  columna: Numero de huso.
%               - Quinta  columna: Altitud Ortometrica
%           - Matriz de bases de replanteo:
%             Estructura de matriz de bases de replanteo:
%               - Primera columna: Numero de punto de la base.
%               - Segunda columna: Numero de la base con respecto a la cual
%                                  se quiere el angulo horizontal de replanteo.
%           - Elipsoide de trabajo, como un vector fila de 5 columnas:
%             elipsoide=[a alfa b e e'];
%           - Coeficiente de refraccion a aplicar para obtener cenitales reales.
%             Si se envia 0 utiliza el estandar, 0.08.
%           - Fichero de resultados, con la ruta completa.
% Devuelve: - No devuelve informacion alguna.
%           - Genera un fichero de resultados, el enviado como ultimo parametro.
% Ejemplo:  replautm(cp,bases,elipsoide,k,,fsalida);
