% Funcion:  radia3e
% Objeto:   Calculo de la radiacion simple espacial basado en 
%           geodesia tridimensional.
%           Resuelve la posicion incognita, planimetria en Proyeccion UTM y altitud
%           ortometrica.
%           Realiza tambien el calculo de la prevision de error de la posicion
%           calculada, error planimetrico y altimetrico, a partir de las caracteristicas
%           del instrumental utilizado, de la geometria de la figura y del metodo
%           numerico de calculo resuelto.
% Recibe:   - Datos del punto estacion:
%             - Latitud geodesica, en radianes.
%             - Longitud geodesica, en radianes.
%               El dominio de la longitud es [0,pi] U ]-pi,0]
%             - Altitud Ortometrica, en metros.
%             - Desorientacion de la vuelta, en radianes.
%             - Error medio cuadratico de la desorientacion, en radianes.
%           - Lectura horizontal al punto, en radianes.
%             Ha de estar en la misma vuelta de horizonte en que se conode la desorientacion.
%           - Lectura cenital, en radianes y corregida de refraccion.
%           - Distancia geometrica, en metros.
%           - Altura de instrumento, en metros.
%           - Altura de prisma, en metros.
%           - Elipsoide de trabajo, con la estructura:
%             elispoide=[a alfa b e e'].
%           - Huso en que se desea la posicion del punto.
%             Si se envia 0 se determina en el huso que le corresponde por su long. geodesica.
%           - Matriz con las caracteristicas del instrumental.
%             Su estructura es, ej:
%  			  inst=[1  2  0.001  0.001  0.020  2.0  0.015  0.015  0.000  0      0      0     0
%					     2  2  0.001  0.001  0.010  1.0  0.015  0.015  0.000  0      0      0     0
%  					  3  1  1      1.0    20     30   1      0.01   3.000  0.005  0.020  0.01  0.01];
%             - Cada fila corresponde a un instrumento distinto.
%             - Cada fila tiene 13 columnas.
%             - La primera columna es el numero del instrumento.
%             - La segunda columna es el tipo: 1-Est. Total o Teo+Dis, 2-GPS.
%               Para Est.Total las siguientes columnas corresponden a:
%               - Col.3:  1/0, Lectura Analogica / Digital.
%               - Col.4:  Apreciacion de lectura angular, en segundos centesimales.
%               - Col.5:  Sensibilidad del nivel tubular en segundos sexagesimales.
%               - Col.6:  Aumentos del anteojo.
%               - Col.7:  1/0, Compensador o no de eclimetro.
%               - Col.8:  Parte constante de error del distanciometro, en metros.
%               - Col.9:  Parte proporcional de error del distanciometro, en ppm.
%               - Col.10: Error de centrado en el instrumento, en metros.
%               - Col.11: Error de centrado en el elemento de punteria, en metros.
%               - Col.12: Error de medida de altura de instrumento, en metros.
%               - Col.13: Error en altura de punteria, en metros.
%           - Fila del instrumento utilizado en la lectura en la matriz de instrumentos.
%           - Numero de veces que se ha realizado punteria y lectura.
% Devuelve: - Posicion planimetrica calculada, en UTM y en metros.
%           - Altitud ortometrica calculada, en metros.
%           - Prevision de error planimetrico en metros.
%           - Prevision de error altimetrico en metros.
% Ejemplo:  [x,y,z,ep,ea]=radia3e(fipe,lonpe,hpe,despe,edes,lhz,lv,dg,ai,am,elipsoide,huso,instru,ni,nl);
