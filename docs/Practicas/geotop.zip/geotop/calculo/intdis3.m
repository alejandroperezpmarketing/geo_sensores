% Funcion:  intdis3
% Objeto:   Calculo de interseccion simple de distancias geometricas basado en 
%           geodesia tridimensional.
%           Resuelve la posicion incognita, coordenadas cartesianas tridimensionales
%           en el mismo Sistema de Referencia Geodesico en que se dan los cuatro
%           puntos de posicion conocida a los que se ha medido distancia.
% Recibe:   - Matriz con coordenadas de puntos de partida, con la siguiente
%             estructura:
%               ejemplo,
%               cp =[ np1  coorx1   coory1   coorz1  dist1
%                     np2  coorx2   coory2   coorz2  dist2
%                     np3  coorx3   coory3   coorz3  dist3
%                     np4  coorx4   coory4   coorz4  dist4];
%             - Primera columna: Numero de punto.
%             - Segunda columna: Coordenada X Cartesiana Tridimensional.
%             - Tercera columna: Coordenada Y Cartesiana Tridimensional.
%             - Cuarta  columna: Coordenada Z Cartesiana Tridimensional.
%             - Quinta  columna: Distancia Geometrica medida en metros.
%             Las coordenadas deben corresponder al centro del prisma.
% Devuelve: - Coordenadas Cartesianas Tridimensionales de la solucion encontrada.
% Ejemplo:  [xo,yo,zo]=intdis3(cp);
