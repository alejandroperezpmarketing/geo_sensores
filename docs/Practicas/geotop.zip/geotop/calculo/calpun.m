% Funcion : calpun
% Objeto  : dada una matriz de vectores y su error :
%           pe  pv  IX  IY  IZ  vxx vyy vzz vxy vxz vyz 
%			   calcula las coordenadas del extremo libre y su matriz varianza covarianza
% Recibe  : matriz conteniendo vectores y errores y una matriz de coordenadas aproximadas 
% Devuelve: Una matriz que contiene las coordenadas calculadas y su error
% Ejemplo : [res]=calpun(vec,coor);
