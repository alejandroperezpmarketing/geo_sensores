% Funcion : average
% Objeto  : dada una matriz de coordenadas cartesianas  y su error
%			   calcula las medias y las correspondientes matrices varianza covarianza
%				num  X Y Z  vxx vyy vzz vxy vxz vyz
% Recibe  : matriz con coordenadas y errores
% Devuelve: Una matriz que contiene las coordenadas medias
%				y el error de la media
% Ejemplo : [medias]=average(coor);
