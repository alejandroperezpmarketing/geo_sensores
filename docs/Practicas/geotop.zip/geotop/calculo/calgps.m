% Funcion:  calgps
% Objeto:   Determina coordenadas cartesianas tridimensionales de 
%           puntos a partir de una matriz de coordenadas cartesianas 
%           tridimensionales de puntos conocidos y de una matriz de
%           vectores en este sistema de coordenadas.
%           Los puntos a determinar se determinan automaticamente a
%           partir de la matriz de vectores.
%           La funcion trabaja de forma iterativa, calcula en primer
%           lugar el punto con un mayor numero de intersecciones y en
%           la siguiente iteracion lo utiliza como punto conocido.
%           A partir de datos del instrumental utilizado en las observaciones
%           realiza calculo del error propagado a cada posicion planimetrica (UTM)
%           y altimetrica para proceder a obtener la posicion final como media
%           ponderada, en funcion de las previsiones anteriores. Si alguna prevision
%           supera una cota enviada a la funcion, la solucion correspondiente no se 
%           utiliza en el calculo de la media ponderada.
% Recibe:   - Matriz de coordenadas:
%             Estructura de matriz de coordenadas:
%             - Primera columna: Numero de punto.
%             - Segunda columna: Coordenada X Cartesiana Tridimensional, en metros.
%             - Tercera columna: Coordenada Y Cartesiana Tridimensional, en metros.
%             - Cuarta  columna: Coordenada Z Cartesiana Tridimensional, en metros.
%             - Quinta  columna: Tipo: 1-Fijo, 0-libre.
%               Esta ultima no es imprescindible.
%               Para los puntos calculados devuelve 0.
%           - Matriz de vectores:
%             Estructura de matriz de vectores:
%             - Primera columna: Punto extremo inicial.
%             - Segunda columna: Punto extremo final.
%             - Tercera columna: Incremento de X, en metros.
%             - Cuarta  columna: Incremento de Y, en metros.
%             - Quinta  columna: Incremento de Z, en metros.
%             - Sexta   columna: Posicion del instrumento en matriz de instrumentos.
%           - Matriz con las caracteristicas del instrumental.
%             Su estructura es, ej:
%  			  inst=[1  2  0.001  0.001  0.020  2.0  0.015  0.015  0.000  0      0      0     0
%					     2  2  0.001  0.001  0.010  1.0  0.015  0.015  0.000  0      0      0     0
%  					  3  1  1      1.0    20     30   1      0.01   3.000  0.005  0.020  0.01  0.01];
%             - Cada fila corresponde a un instrumento distinto.
%             - Cada fila tiene 13 columnas.
%             - La primera columna es el numero del instrumento.
%             - La segunda columna es el tipo: 1-Est. Total o Teo+Dis, 2-GPS.
%               Para GPS las siguientes columnas corresponden a:
%               - Col.3:  Error de centrado de la antena en el extremo inicial del vector, en metros.
%               - Col.4:  Error de centrado de la antena en el extremo final del vector, en metros.
%               - Col.5:  Parte constante de error del vector, en metros.
%               - Col.6:  Parte proporcional de error del vector, en ppm.
%               - Col.7:  Error de medida de altura de antena en el extremo inicial del vector, en metros.
%               - Col.8:  Error de medida de altura de antena en el extremo final del vector, en metros.
%           - Tolerancia posicional, en metros. Si la prevision de error de alguna solucion 
%             multiple para la posicion de un punto calculado supera esta cota no se utilizara
%             en la media ponderada.
%           - Nombre, y ruta completa, del fichero de resultados.
% Devuelve: - La misma matriz de coordenadas ampliada.
% Ejemplo:  cctp=calgps(cctp,ogct,fsalida);
