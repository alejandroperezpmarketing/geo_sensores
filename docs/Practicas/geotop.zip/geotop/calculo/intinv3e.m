% Funcion:  intinv3e
% Objeto:   Calculo de la interseccion inversa simple espacial basado en 
%           geodesia tridimensional.
%           Resuelve la posicion incognita, planimetria en Proyeccion UTM y altitud
%           ortometrica.
%           Resuelve tantas soluciones altimetricas como cenitales se hayan medido.
%           Realiza tambien el calculo de la prevision de error de la posicion
%           calculada, error planimetrico y altimetrico, a partir de las caracteristicas
%           del instrumental utilizado, de la geometria de la figura y del metodo
%           numerico de calculo resuelto.
% Recibe:   - Matriz de datos, con la siguiente estructura:
%             Ejemplo,
%             datos=[ LAT-1  LON-1  HORT1  LHZ1  LV1  I1  M1  NI1  NV1
%                     LAT-2  LON-2  HORT2  LHZ2  LV2  I2  M2  NI2  NV2
%                     LAT-3  LON-3  HORT3  LHZ3  LV3  I3  M3  NI3  NV3];
%             - Cada fila corresponde a una observacion.
%             - Col. 1.: Latitud geodesica punto visado, en radianes.
%             - Col. 2.: Longitud geodesica punto visado, en radianes.
%                        El dominio de la longitud es [0,pi] U ]-pi,0]
%             - Col. 3.: Altitud ortometrica punto visado, en metros.
%             - Col. 4.: Lectura horizontal al punto visado, en radianes.
%             - Col. 5.: Lectura cenital, en radianes y corregida de refraccion.
%             - Col. 6.: Altura del instrumento, en metros.
%             - Col. 7.: Altura de punteria, en metros, respecto al punto cuya
%                        altitud ortometrica ha sido introducida en al col. 3.
%             - Col. 8.: Fila del instrumento utilizado en la matriz de instrumentos.
%             - Col. 9.: Numero de veces que se ha realizado lectura y punteria.
%           - Huso en que se desea la posicion del punto.
%             Si se envia 0 se determina en el huso que le corresponde al primer punto.
%           - Elipsoide de trabajo, con la estructura:
%             elispoide=[a alfa b e e'].
%           - Matriz con las caracteristicas del instrumental.
%             Su estructura es, ej:
%  			  inst=[1  2  0.001  0.001  0.020  2.0  0.015  0.015  0.000  0      0      0     0
%					     2  2  0.001  0.001  0.010  1.0  0.015  0.015  0.000  0      0      0     0
%  					  3  1  1      1.0    20     30   1      0.01   3.000  0.005  0.020  0.01  0.01];
%             - Cada fila corresponde a un instrumento distinto.
%             - Cada fila tiene 13 columnas.
%             - La primera columna es el numero del instrumento.
%             - La segunda columna es el tipo: 1-Est. Total o Teo+Dis, 2-GPS.
%               Para Est.Total las siguientes columnas corresponden a:
%               - Col.3:  1/0, Lectura Analogica / Digital.
%               - Col.4:  Apreciacion de lectura angular, en segundos centesimales.
%               - Col.5:  Sensibilidad del nivel tubular en segundos sexagesimales.
%               - Col.6:  Aumentos del anteojo.
%               - Col.7:  1/0, Compensador o no de eclimetro.
%               - Col.8:  Parte constante de error del distanciometro, en metros.
%               - Col.9:  Parte proporcional de error del distanciometro, en ppm.
%               - Col.10: Error de centrado en el instrumento, en metros.
%               - Col.11: Error de centrado en el elemento de punteria, en metros.
%               - Col.12: Error de medida de altura de instrumento, en metros.
%               - Col.13: Error en altura de punteria, en metros.
% Devuelve: - Matriz de soluciones, tantas como soluciones altimetricas,
%             con la misma solucion planimetrica, con la estructura:
%             - Col. 1.: Coord. X-UTM, en metros.
%             - Col. 2.: Coord. Y-UTM, en metros.
%             - Col. 3.: Altitud ortometrica, en metros.
%             - Col. 4.: Prevision de error en planimetria, en metros.
%             - Col. 5.: Prevision de error en altimetria, en metros.
%           - Numero de filas de la matriz anterior.
% Ejemplo:  [xx,t]=intinv3e(datos,huso,elipsoide,instru);
