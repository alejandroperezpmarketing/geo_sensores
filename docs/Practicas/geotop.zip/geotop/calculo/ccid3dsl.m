% Funcion:  ccid3dsl
% Objeto:   Calcula todos los puntos posibles de una red por interseccion directa
%           multiple.
%           Es valido para sistema local de coordenadas o geodesico trabajando en planas
%           sin aplicar reduccion a las observaciones acimutales.
%           Para cada interseccion con dos lecturas acimutales y dos cenitales
%           obtiene una solucion planimetrica y dos altimetricas con emc.
%           Si hay redundancias obtiene emc.
%           Obtiene internamente los puntos a calcular a partir de la matriz de observaciones.
% Recibe:   - Matriz de coordenadas: NP. Coor.X  Coor.Y. Coor.H.
%             cp=[  1001     610976.262    4734613.143        460.138                        
%                   1025     618063.236    4726449.451       1114.732                        
%                   ....     ..........    ...........       ........
%                   1026     616749.288    4726760.168       1081.664];
%           - Matriz de observaciones: NPE.  NPV.  LHZ.  LV.  A.I.  A.M.  DG.
%             con magnitudes angulares en centesimal y lineal en metros.
%		        obs=[ 1001      1004  171.0280    0.0000 1.410 0.000     0.000
%                   1001      2000  339.3078   92.0258 1.410 0.000     0.000
%                   ....      ....  ........   ....... ..... .....     .....  
%                   1001      2002  357.2458   93.0630 1.410 0.000     0.000];
%           - Fichero de salida de resultados de las intersecciones.
% Devuelve: - La misma matriz de coordenadas ampliada con los puntos calculados.
%           - Un fichero con los calculos: ccid3dsl.sal
% Ejemplo:  coor=ccid3dsl(coor,obs,fsalida);
