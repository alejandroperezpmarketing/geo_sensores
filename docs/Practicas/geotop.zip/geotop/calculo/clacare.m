% Funcion : clacare
% Objeto  : dada una matriz de observaciones clasicas, una matriz de instrumentos y una
%				matriz de coordenadas geodesicas, calcula los incrementos de coordenadas
%				cartesianas geocentricas y el error propagado
% Recibe  : cla (matriz de observaciones clasicas)
%				intru (matriz de intrumentos)
%				cpgeo (coordenadas geodesicas aproximadas)
%           desor (matriz de desorientaciones. ver funcion desor)
% Devuelve: Una matriz que contiene los incrementos de coordenadas cartesianas geocentricas
%				y el error propagado. Su estructura es:
%				pe pv IX IY IZ vxx vyy vzz vxy vxz vyz
% Ejemplo : [increm]=clacare(obs,instr,coor,desor);
