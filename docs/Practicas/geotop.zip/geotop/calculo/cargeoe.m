% Funcion : cargeoe
% Objeto  : transforma coordenadas cartesianas geocentricas con su matriz de error asociado
%				num X Y Z vxx vyy vx�zz vxy vxz vyz
%           a coordenadas geodesicas con su matriz de error asociado
% Recibe  : matriz de coordenadas cartesianas y error asociado, elipsoide
% Devuelve: matriz de coordenadas geodesicas y error asociado
% Ejemplo : [geod]=claxyze(carte,elipsoide);
