% Funcion:  intinv2
% Objeto:   Calculo de la interseccion inversa simple en el plano. 
% Recibe:   - Matriz de datos, con la siguiente estructura:
%             Ejemplo,
%             datos=[ X1  Y1  LHZ1
%                     X2  Y2  LHZ2
%                     X3  Y3  LHZ3];
%             - Cada fila corresponde a una observacion.
%             - Col. 1.: Coordenad X del punto visado, en metros.
%             - Col. 2.: Coordenad Y del punto visado, en metros.
%             - Col. 3.: Lectura horizontal al punto visado, en radianes.
% Devuelve: - Posicion calculada:
%             - Coordenada X, en metros.
%             - Coordenada Y, en metros.
%           - Angulo minimo formado por las tres visuales, en radianes.
% Ejemplo:  [xp,yp,ep]=intinv2(datos,instru);