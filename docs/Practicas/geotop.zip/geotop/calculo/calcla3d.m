% Funcion:  calcla3d
% Objeto:   Calculo de coordenadas aproximadas de redes geodesicas a partir
%           de observables clasicos.
%           Resuelve la posicion planimetrica y altimetrica.
%           Utiliza metodos de calculo de geodesia tridimensional.
%           A partir de datos del instrumental utilizado en las observaciones
%           realiza calculo del error propagado a cada posicion planimetrica (UTM)
%           y altimetrica para proceder a obtener la posicion final como media
%           ponderada, en funcion de las previsiones anteriores. Si alguna prevision
%           supera una cota enviada a la funcion, la solucion correspondiente no se 
%           utiliza en el calculo de la media ponderada.
% Recibe:   - Matriz con coordenadas de puntos de partida, con la siguiente
%             estructura:
%               ejemplo,
%               cp=[1001  394142.135  4476123.422  30   743.249  1
%                   1009  380555.257  4479149.534  30  1000.079  1
%                   ....  ..........  ...........  ..  ........  .
%                   1012  390826.436  4481082.299  30  1048.202  1];
%             - Primera columna: Numero de punto.
%             - Segunda columna: Coordenada X-UTM.
%             - Tercera columna: Coordenada Y-UTM.
%             - Cuarta  columna: Huso del punto.
%             - Quinta  columna: Altitud ortometrica.
%             - Sexta   columna: Tipo del punto: 1/0, Fijo / Libre.
%               Para una posible compensacion posterior.
%               Esta ultima no es imprescindible.
%               Para los puntos calculados devuelve 0.
%           - Matriz de observables, con la estructura:
%               ejemplo,
%               obs=[1001      1009   52.7512    0.0000 1.530 0.000     0.000  3
%                    1001      1012  101.2795    0.0000 1.530 0.000     0.000  3
%                    ....      ....  ........   ....... ..... .....  ........  .
%                    1008      1002   69.2380   91.7020 1.530 1.270  2830.127  3];
%             - Primera columna: Punto estacion.
%             - Segunda columna: Punto visado.
%             - Tercera columna: Lectura horizontal en graduacion 
%               centesimal. Una lectura 0 se debe introducir 0.000001.
%             - Cuarta  columna: Lectura cenital en centesimal.
%             - Quinta  columna: Altura del instrumento en metros.
%             - Sexta   columna: Altura de punteria en metros.
%             - Septima columna: Distancia geometrica en metros.
%             - Octava  columna: Numero de instrumento con el que se ha
%               realizado la observacion.
%           - Elipsoide de trabajo, con la estructura:
%             elispoide=[a alfa b e e'].
%           - Numero de huso global en el que se desean los calculos.
%             Si algun punto no pertenece a este huso sera pasado al mismo.
%           - Matriz con las caracteristicas del instrumental.
%             Su estructura es, ej:
%  			  inst=[1  2  0.001  0.001  0.020  2.0  0.015  0.015  0.000  0      0      0     0
%					     2  2  0.001  0.001  0.010  1.0  0.015  0.015  0.000  0      0      0     0
%  					  3  1  1      1.0    20     30   1      0.01   3.000  0.005  0.020  0.01  0.01];
%             - Cada fila corresponde a un instrumento distinto.
%             - Cada fila tiene 13 columnas.
%             - La primera columna es el numero del instrumento.
%             - La segunda columna es el tipo: 1-Est. Total o Teo+Dis, 2-GPS.
%               Para Est.Total las siguientes columnas corresponden a:
%               - Col.3:  1/0, Lectura Analogica / Digital.
%               - Col.4:  Apreciacion de lectura angular, en segundos centesimales.
%               - Col.5:  Sensibilidad del nivel tubular en segundos sexagesimales.
%               - Col.6:  Aumentos del anteojo.
%               - Col.7:  1/0, Compensador o no de eclimetro.
%               - Col.8:  Parte constante de error del distanciometro, en metros.
%               - Col.9:  Parte proporcional de error del distanciometro, en ppm.
%               - Col.10: Error de centrado en el instrumento, en metros.
%               - Col.11: Error de centrado en el elemento de punteria, en metros.
%               - Col.12: Error de medida de altura de instrumento, en metros.
%               - Col.13: Error en altura de punteria, en metros.
%           - Tolerancia planimetrica, en metros. Si la prevision de error de alguna solucion 
%             multiple para la posicion planimetrica de un punto calculado supera 
%             esta cota no se utilizara en la media ponderada.
%           - Tolerancia altimetrica, en metros. Si la prevision de error de alguna solucion 
%             multiple para la posicion altimetrica de un punto calculado supera 
%             esta cota no se utilizara en la media ponderada.
%           - Coeficiente de refraccion a utilizar para corregir los cenitales.
%             Si se envia 0, utilizara el estandar 0.08.
%             Unicamente se corrigen aquellos cenitales para los que tambien se ha medido distancia.
%           - Nombre, con toda la ruta, del fichero donde se desean detalles de los
%             calculos realizados. Si este fichero existe debe ser borrado previamente.
% Devuelve: La misma matriz de coordenadas ampliada con dos nuevas columnas:
%           - Columna 8: Desorientacion media ponderada en radianes si se ha realizado
%                        vuelta de horizonte en el punto.
%           - Columna 9: Error de la media ponderada, en radianes.
% Ejemplo:  [cp]=calcla3d(cp,obs,elipsoide,huso,instru,tolpla,tolalt,fsalida);
