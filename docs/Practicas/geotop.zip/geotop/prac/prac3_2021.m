% funci�n para comprobar la practica 3 (17/10/2021)
%[] = prac3_2021(crdfile,obsfile,outfile,sisref);
