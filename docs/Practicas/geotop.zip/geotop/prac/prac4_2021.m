% funci�n para realizar la pr�ctica N�4 (2021)
% []=prac4_2021(group,cmpfile,elipsoide,husogeneral)
