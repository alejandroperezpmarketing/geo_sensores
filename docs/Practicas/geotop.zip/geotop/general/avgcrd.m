% Funcion : avgcrd
% Objeto  : dada una matriz que contiene las coordenadas de m�ltiples
%           puntos repetidos, calcula el promedio y su desviaci�n t�pica
% Recibe  : matriz con coordenadas con el siguiente formato:
%           geo ->  num   lat(rad)   lon(rad)   hel(m)
%           car ->  num     X(m)       Y(m)       Z(m)
%           utm ->  num     E(n)       N(m)       zn    H(m)
% Devuelve: Dos matrices, la primera con los promedios, la segunda con la
%           desviaci�n t�pica de los mismos
% Ejemplo : [pro,err]=avgcrd(crd)
function[pro,err]=avgcrd(crd)

%se efectuan los promedios
tmp = 0;
points =  unique(crd(:,1));

[mp,np] = size(points);
for i = 1 : mp,
    
    num = points(i,1);
    
    clear tmp;
    cont = 0;

    [m,n] = size(crd);
    for j = 1 : m,
        if crd(j,1) == num,
            cont = cont + 1;
            tmp(cont,:) = crd(j,:);
        end
    end

    avg_val = mean(tmp);
    avg_err = std(tmp);

    if i == 1,
        pro = [ avg_val(1,:) ];
        err = [ avg_err(1,:) ];
    else,
        pro = [ pro ; avg_val(1,:)];
        err = [ err ; avg_err(1,:)];            
    end
        
end
