% Funcion:  buscafil
% Objeto:   Localiza la primera ocurrencia de un numero en la columna
%           indicada de una matriz.
% Recibe:   Numero a localizar, matriz de busqueda y columna en la que buscar.
%           Ejemplo,
%				      npe=1003;
%				      ncol=4;
%				      coor=[ 365897.345  4756234.459  30  1012  
%                        325456.459  4754856.456  30  1110  
%                        326666.555  4744444.333  30  1003  
%                        377777.888  4722222.111  30  1145];
%           El valor devuelto por la funcion seria 3, fila numero 3.
% Devuelve: Posicion, numero de fila, comenzando en 1.
%           Si no lo encuentra devuelve -1.
% Ejemplo:  pos=buscafil(npe,coor,ncol);
function[n]=buscafil(j,c,ncol)
[fil,col]=size(c);
if ncol>col,
   n=-1;
else,   
	control=0;
	i=1;
	while control==0,
		if(c(i,ncol)==j),
   		n=i;
      	control=1;
   	else,
      	i=i+1;
      	if(i>fil),
      		control=1;
        		n=-1;
      	end;
   	end;
   end;
end;


