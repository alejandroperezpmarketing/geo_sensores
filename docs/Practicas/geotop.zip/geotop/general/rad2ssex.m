% Funcion:  rad2ssex
% Objeto:   Cambio de formato de angulos.
%           Pasa un angulo en radianes a segundos sexagesimales.
% Recibe:   Angulo en radianes.
% Devuelve: Angulo en segundos sexagesimales.
% Ejemplo:  segsex=rad2ssex(rad);
function[segsex]=rad2ssex(rad)
segsex = 180 * 3600 * rad / pi;
