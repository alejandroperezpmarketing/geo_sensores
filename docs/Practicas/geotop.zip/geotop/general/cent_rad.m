% Funcion:  cent_rad
% Objeto:   Cambio de formato de angulos.
%           Pasa un angulo en formato centesimal a radianes.
% Recibe:   Angulo en graduacion centesimal.
% Devuelve: Angulo en radianes.
% Ejemplo:  fir=cent_rad(fic);
function[radianes]=cent_rad(centesimal)
radianes = pi * centesimal / 200;
