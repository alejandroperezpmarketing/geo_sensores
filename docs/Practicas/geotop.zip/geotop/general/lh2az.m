% Funcion:  lh2az
% Objeto:   Calculo del azimut a partir de una lectura horizontal y la desorientacion.
% Recibe:   La lectura horizontal en radianes y la desorientaci�n en radianes.
% Devuelve: Azimut en radianes con un valor entre 0 y 2pi.
% Ejemplo:  a=lh2az(lh,des);
function[az]=lh2az(lh,des);
az = lh + des;
dospi = 2*pi;
while az > dospi,
	az = az - dospi;
end;
if az < 0,
	az = az + dospi;
end;
   
   