% Funcion:  edirev
% Objeto:   Calculo del error de una lectura cenital realizada con un teodolito.
%           Utiliza la formulacion clasica de teoria de errores.
% Recibe:   - Una matriz con las caracteristicas del instrumental.
%             Su estructura es, ej:
%  			  inst=[1  2  0.001  0.001  0.020  2.0  0.015  0.015  0.000  0      0      0     0
%					     2  2  0.001  0.001  0.010  1.0  0.015  0.015  0.000  0      0      0     0
%  					  3  1  1      1.0    20     30   1      0.01   3.000  0.005  0.020  0.01  0.01];
%             - Cada fila corresponde a un instrumento distinto.
%             - Cada fila tiene 13 columnas.
%             - La primera columna es el numero del instrumento.
%             - La segunda columna es el tipo: 1-Est. Total o Teo+Dis, 2-GPS.
%               Para Est.Total las siguientes columnas corresponden a:
%               - Col.3:  1/0, Lectura Analogica / Digital.
%               - Col.4:  Apreciacion de lectura angular, en segundos centesimales.
%               - Col.5:  Sensibilidad del nivel tubular en segundos sexagesimales.
%               - Col.6:  Aumentos del anteojo.
%               - Col.7:  1/0, Compensador o no de eclimetro.
%               - Col.8:  Parte constante de error del distanciometro, en metros.
%               - Col.9:  Parte proporcional de error del distanciometro, en ppm.
%               - Col.10: Error de centrado en el instrumento, en metros.
%               - Col.11: Error de centrado en el elemento de punteria, en metros.
%               - Col.12: Error de medida de altura de instrumento, en metros.
%               - Col.13: Error en altura de punteria, en metros.
%           - Fila del instrumento utilizado en la lectura en la matriz de instrumentos.
%           - Numero de veces que se ha realizado punteria y lectura.
% Devuelve: - Error en la lectura cenital en radianes.
% Ejemplo:  [edire]=edirev(instru,ni,nl)
function[edire]=edirev(instru,ni,nl)
if instru(ni,3)==1,
	el=2/3*instru(ni,4)/10000*pi/200/sqrt(nl);
else,
   el=instru(ni,4)/10000*pi/200/sqrt(nl);
end;
if instru(ni,7)==1,
   evv=0;
else,
   evv=1/3*instru(ni,5)/3600*pi/180;
end;
epv=20/instru(ni,6)*(1+4*instru(ni,6)/100)/sqrt(nl)/3600*pi/180;
edire=sqrt(el^2+evv^2+epv^2);
