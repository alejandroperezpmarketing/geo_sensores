% Funcion:  in2pi
% Objeto:   Dado un �ngulo en radianes comprendido entre -infinito y + infinito
%           devuelve un valor entre 0 y 2*pi 
% Devuelve: un valor angular comprendido entre 0 y 2*pi 
% Ejemplo:  ang=in2pi(ang);
function[ang]=in2pi(ang);
if ang < 0,
    ang = ang + 2*pi;
end;
if ang > 2*pi,
    ang = ang - 2*pi;
end;