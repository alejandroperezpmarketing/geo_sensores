% Funcion:  parelip
% Objeto:   Contiene los parametros de los elipsoides: HAYFORD,WGS84,GRS80
% Recibe:   Nombre del elipsoide encerrado entre comillas simples
% Devuelve: Vector fila con los siguientes elementos:
%           - par(1,1)=Semieje mayor.
%           - par(1,2)=Aplanamiento.
%           - par(1,3)=Semieje menor.
%           - par(1,4)=Primera excentricidad
%           - par(1,5)=Segunda excentricidad
%           Por defecto devuelve los par�metros correspondientes a la esfera de radio 6371 km.
% Ejemplo:  [par]=parelip('Hayford');
function[par]=parelip(nomelip);

par(1,1) = 6371000.000;
par(1,2) = 0;

if  strcmp(upper(nomelip),'HAYFORD') == 1,
   par(1,1) = 6378388.000;
   par(1,2) = 1 / 297.000;
end;   

if  strcmp(upper(nomelip),'WGS84') == 1,
   par(1,1) = 6378137.000;
   par(1,2) = 1 / 298.257223563;
end;   

if  strcmp(upper(nomelip),'GRS80') == 1,
   par(1,1) = 6378137.000;
   par(1,2) = 1 / 298.257222101;
end;   

par(1,3) = par(1,1) - par(1,1) * par(1,2);
par(1,4) = sqrt( 1 - ( par(1,3)^2 ) / ( par(1,1)^2 ));
par(1,5) = sqrt(( par(1,1)^2 ) / ( par(1,3)^2 ) - 1);
return;

