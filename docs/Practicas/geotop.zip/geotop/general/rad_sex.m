% Funcion:  rad_sex
% Objeto:   Cambio de formato angular.
%           Convierte de un valor angular num�rico expresado en radianes
%           a una cadena de caracteres con el correspondiente expresado en graduaci�n sexagesimal:
%           ( ej: 0.612358942846936 >>> '35� 5' 8.09870"' )
% Recibe:   Valor n�merico de un �ngulo expresado en radianes.
% Devuelve: Cadena de caracteres con el correspondiente valor en graduaci�n sexagesimal.
% Ejemplo:  valstr=rad_sex(valrad);
function[value_string]=rad_sex_gsn(radianes)
degsexa=abs(radianes*180/pi);
pseudosexa1=p_entera(degsexa);
degsexa=(degsexa-pseudosexa1)*100*.6;
pseudosexa2=p_entera(degsexa);
degsexa=(degsexa-pseudosexa2)*100*.6;
pseudosexa3=degsexa;
if abs(pseudosexa3-60)<0.000001,
	pseudosexa2=pseudosexa2+1;
   pseudosexa3=0;
end;
if abs(pseudosexa2-60)<(0.000001/60),
	pseudosexa1=pseudosexa1+1;
   pseudosexa2=0;
end;

deg_str = num2str(pseudosexa1,'%2.0f');
min_str = num2str(pseudosexa2,'%2.0f');
sec_str = num2str(pseudosexa3,'%8.5f');

if length(deg_str) < 2,
    deg_str = [ ' ' deg_str];
end;

if length(min_str) < 2,
    min_str = [ ' ' min_str];
end;

if pseudosexa3 < 10,
    sec_str = [ ' ' sec_str];
end;

if pseudosexa3 > 10 && length(sec_str) < 8,
    sec_str = [ sec_str ' '];
end;


if radianes>0,       
    value_string = [ deg_str '�' min_str '''' sec_str '"'];
else
    value_string = [ '-' deg_str '�' min_str '''' sec_str '"'];
end;
