% Funcion:  ssex2rad
% Objeto:   Cambio de formato de angulos.
%           Pasa un angulo en segundos sexagesimales a radianes.
% Recibe:   Angulo en segundos sexagesimales.
% Devuelve: Angulo en radianes.
% Ejemplo:  rad=ssex2rad(seg);
function[rad]=ssex2rad(seg)
rad = pi * seg / (180 * 3600 );
