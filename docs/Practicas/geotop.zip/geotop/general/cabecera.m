% Funcion:  cabecera
% Objeto:   Impresion de cabecera de resultados de distintas funciones y
%           programas.
% Recibe:   - Titulacion para la que se aplica el programa o funcion.
%           - Asignatura para la que se aplica el programa o funcion.
%           - Nombre del programa o funcion.
%           - Autor.
%           No incluye punto al final de ninguna linea.
%           - Nombre, con la ruta completa, del fichero en el que se imprime.
% Devuelve: No devuelve nada.
% Ejemplo:  cabecera(titulacion,asignatura,programa,autor,fsalida);
function[]=cabecera(titulacion,asignatura,programa,autor,fsalida)
fprintf(fsalida,'U N I V E R S I D A D     P O L I T E C N I C A     D E     V A L E N C I A\n');
fprintf(fsalida,'DEPARTAMENTO DE INGENIERA CARTOGRAFICA, GEODESIA Y FOTOGRAMETRIA\n');
fprintf(fsalida,'E.T.S.I. GEODESICA, CARTOGRAFICA Y TOPOGRAFICA\n\n');
fprintf(fsalida,'TITULACION: ..... %s\n',titulacion);
fprintf(fsalida,'ASIGNATURA: ..... %s\n',asignatura);
[m,n]=size(programa);
for i=1:m,
   if i==1,
      fprintf(fsalida,'PROGRAMA:   ..... %s\n',programa(i,:));
   else,
      fprintf(fsalida,'                  %s\n',programa(i,:));
   end;
end;

if autor(1,1) ~= 0
    [m,n]=size(autor);
    for i=1:m,
        if i==1,
            fprintf(fsalida,'AUTORES:    ..... %s\n',autor(i,:));
        else,
            fprintf(fsalida,'                  %s\n',autor(i,:));
        end;
    end;
end;
fprintf(fsalida,'\n\n');
