% Funcion:  rad_psdo
% Objeto:   Cambio de formato de angulos.
%           Pasa un angulo de radianes al conocido como formato
%           pseudo decimal sexagesimal:
%           ( ej: 40.24305678 son 40 g. 24 m. 30.5678 seg. sex. )
% Recibe:   Angulo en radianes.
% Devuelve: Angulo en pseudosexa ( positivo o negativo ).
% Ejemplo:  fipsdo=rad_psdo(firad);
function[pseudosexa]=rad_psdo(radianes)
degsexa=abs(radianes*180/pi);
pseudosexa1=p_entera(degsexa);
degsexa=(degsexa-pseudosexa1)*100*.6;
pseudosexa2=p_entera(degsexa);
degsexa=(degsexa-pseudosexa2)*100*.6;
pseudosexa3=degsexa;
if abs(pseudosexa3-60)<0.000001,
	pseudosexa2=pseudosexa2+1;
   pseudosexa3=0;
end;
if abs(pseudosexa2-60)<(0.000001/60),
	pseudosexa1=pseudosexa1+1;
   pseudosexa2=0;
end;
pseudosexa=pseudosexa1+pseudosexa2/100+pseudosexa3/10000;
if radianes<0,
   pseudosexa=-pseudosexa;
end;
