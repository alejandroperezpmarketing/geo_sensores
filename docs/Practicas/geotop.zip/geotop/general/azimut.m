% Funcion:  azimut
% Objeto:   Calculo del azimut en el plano entre dos puntos.
% Recibe:   Coordenadas de los dos puntos.
% Devuelve: Azimut en radianes.
% Ejemplo:  a12=azimut(x1,y1,x2,y2);
function[a]=azimut(xi,yi,xj,yj)
ax=xj-xi;
ay=yj-yi;
a=atan2(ax,ay);
if a<0,
	a=a+2*pi;
end;
   
   