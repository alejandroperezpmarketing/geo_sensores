% Libreria GeoTop: 	General.
%
%Areacor. - c�lculo de la superficie en el plano del recinto encerrado por un pol�gono a partir 
%           de los v�rtices del mismo, definidos por sus coordenadas cartesianas.
%Azimut.  - c�lculo del azimut en el plano entre dos puntos.
%Busca.   - determinaci�n del n�mero de la fila de una matriz en la que, en su primera columna, 
%           se encuentra un n�mero enviado a la funci�n.
%Buscacol.- determinaci�n del n�mero de la columna una matriz en la que, en la fila indicada, 
%           se encuentra un n�mero enviado a la funci�n.
%Buscafil.- determinaci�n del n�mero de la fila de una matriz en la que, en la columna indicada,
%           se encuentra un n�mero enviado a la funci�n.
%Cabecera.- impresi�n en un fichero de resultados de la cabecera de un programa.
%Distancia.-c�lculo de la distancia plana entre dos puntos.
%Edgcla.  - c�lculo de la previsi�n de error de una distancia cl�sica.
%Edireh.  - c�lculo de la previsi�n de error de una lectura azimutal.
%Edirev.  - c�lculo de la previsi�n de error de una lectura cenital.
%Floor.   - determinaci�n del n�mero entero inferior a un n�mero real dado.
%Ordena.  - ordenaci�n de las filas de una matriz, de menor a mayor, en funci�n del contenido de la
%           columna indicada.
%P_entera. - devuelve la parte entera de un n�mero real.
%psdo_rad. - convierte un �ngulo en formato seudo-decimal-sexagesimal a radianes.
%rad_psdo. - convierte un �ngulo en radianes a formato seudo-decimal-sexagesimal.
%sex_rad.  - convierte una string con un valor angular en formato sexagesimal al correspondiente valor num�rico en radianes.
%rad_sex.  - convierte un �ngulo en radianes a una string con el correspondiente valor en graduaci�n sexagesimal
%cent_rad. - convierte un �ngulo en formato centesimal a su correspondiente valor en radianes.
%rad_cent. - convierte un navlor angular en radianes a su correspondiente valor en graduaci�n centesimal.
%ssex2rad. - convierte segundos sexagesimales a radianes.
%rad2ssex. - convierte radianes a segundos sexagesimales.
%scent2rad.- convierte segundos centesimales a radianes.
%rad2scent.- convierte radianes a segundos centesimales.
