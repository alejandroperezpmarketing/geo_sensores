% Funcion:  sex_rad
% Objeto:   Cambio de formato angular.
%           Convierte una cadena de caracteres del tipo '39�30'51.24287"' a
%           un valor n�merico con el valor equivalente en radianes 
%           ( ej: '35� 5' 8.09870"' >>> 0.612358942846936)
% Recibe:   Valor n�merico en radianes.
% Devuelve: Cadena de caracteres con su equivalencia en graduaci�n sexagesimal.
% Ejemplo:  valrad=sex_rad(valstr);
function[valrad]=rad_sex(valstr)
deg_symbol_pos = strfind(valstr,'�');
min_symbol_pos = strfind(valstr,'''');
sec_symbol_pos = strfind(valstr,'"');

deg_val = str2num(valstr(1:deg_symbol_pos-1));
min_val = str2num(valstr(deg_symbol_pos+1:min_symbol_pos-1));
sec_val = str2num(valstr(min_symbol_pos+1:sec_symbol_pos-1));

negative = 0;
if deg_val < 0,
    negative = 1;
end
if abs(deg_val) < 0.1,
    if length(strfind(valstr(1:3),'-')) ~= 0,
        negative = 1;
    end
end

if negative == 0,
    valrad = pi * ( deg_val + min_val/60 + sec_val/3600 ) / 180;
else,
    valrad = pi * ( deg_val - min_val/60 - sec_val/3600 ) / 180;
end;

