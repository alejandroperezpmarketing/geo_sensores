% Funcion:  buscaobs
% Objeto:   devuelve una matriz con las observaciones localizadas.
% Recibe:   Punto estaci�n, punto visado, matriz de observaciones.
% Devuelve: matriz con la fila de las observaciones encontradas, numero de observaciones encontradas.
% Ejemplo:  [res,num]=buscaobs(npe,npv,obs);
function[res,num]=buscaobs(npe,npv,obs)
cont = 0;
[m,n]=size(obs);
for i = 1 : m,
   if obs(i,1) == npe,
      if  obs(i,2) == npv,
      	cont = cont + 1;
         res(cont,1) = i;
      end;
   end;
end;
num = cont;
return;
