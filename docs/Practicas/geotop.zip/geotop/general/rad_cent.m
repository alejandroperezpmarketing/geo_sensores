% Funcion:  rad_cent
% Objeto:   Cambio de formato de angulos.
%           Pasa un angulo en radianes a formato centesimal.
% Recibe:   Angulo en radianes.
% Devuelve: Angulo en graduacion centesimal.
% Ejemplo:  fic=rad_cent(fir);
function[cent]=cent_rad(rad)
cent = 200 * rad / pi;
