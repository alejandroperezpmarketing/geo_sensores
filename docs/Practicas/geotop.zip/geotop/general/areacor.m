% Funcion:  areacor
% Objeto:   Calculo de la superficie interior de un poligono sobre el plano.
% Recibe:   Coordenadas de los vertices que definen el poligono.
%           Se recibe en una matriz donde cada fila es un punto,
%           la primera columna la abcisa, y la segunda la ordenada.
%           Cierra sobre el primer punto por lo que no debe figurar
%           repetido en la matriz de datos.
%           Ejemplo,
%				      c=[ x1  y1
%                     x2  y2
%                     ......
%							 xn  yn];
%           tratandose de un poligono de n vertices.
% Devuelve: Superficie en la unidad al cuadrado de las coordenadas.
% Ejemplo:  spol=areacor(c);
function[sup]=areacor(c);
[m,n]=size(c);
sup=0;
for i=1:m,
	xn=c(i,1);
   yn=c(i,2);
   if i==m,
   	xn1=c(1,1);
   	yn1=c(1,2);
   else,
   	xn1=c(i+1,1);
      yn1=c(i+1,2);
   end;
   sup=sup+(xn1-xn)*(yn1+yn);
end;
sup=sup/2;
