% Funcion:  deg2rad
% Objeto:   
% Recibe:   
% Devuelve: 
% Ejemplo:[angle_rad]=deg2rad(angle_deg);
function[angle_rad]=deg2rad(angle_deg);
angle_rad=angle_deg*pi/180;
