% Funcion:  rad2scent
% Objeto:   Cambio de formato de angulos.
%           Pasa un angulo en radianes a segundos centesimales.
% Recibe:   Angulo en radianes.
% Devuelve: Angulo en segundos centesimales.
% Ejemplo:  fic=rad_cent(fir);
function[segcent]=rad2scent(rad)
segcent = 2000000 * rad / pi;
