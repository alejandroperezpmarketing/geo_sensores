% Funcion:  scent2rad
% Objeto:   Cambio de formato de angulos.
%           Pasa un angulo en segundos centesimales a radianes.
% Recibe:   Angulo en segundos centesimales.
% Devuelve: Angulo en radianes.
% Ejemplo:  rad=scent2rad(seg);
function[rad]=scent2rad(seg)
rad = pi * seg / 2000000 ;
