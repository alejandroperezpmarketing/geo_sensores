% Funcion:  ordena
% Objeto:   Ordena las filas de una matriz de menor a mayor segun el 
%           contenido de la columna indicada.
% Recibe:   - Numero de la columna que marca la ordenacion y
%           - Matriz a ordenar.
% Devuelve: La matriz de entrada ordenada.
% Ejemplo:  matrizord=ordena(ncol,matriz);
function[v]=ordena(c,v)
[m,n]=size(v);
for i=1:m-1,
	valormin=v(i,c);
   posmin=i;
   for j=i:m,
   	if v(j,c)<valormin,
      	valormin=v(j,c);
        	posmin=j;
      end;
   end;
   if posmin~=i,
      for j=1:n,
      	aux=v(posmin,j);
        	v(posmin,j)=v(i,j);
        	v(i,j)=aux;
      end;
   end;
end;

