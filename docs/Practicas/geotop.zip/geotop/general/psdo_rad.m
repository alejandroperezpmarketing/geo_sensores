% Funcion:  psdo_rad
% Objeto:   Cambio de formato de angulos.
%           Pasa del conocido como formato pseudo decimal sexagesimal
%           ( ej: 40.24305678 son 40 g. 24 m. 30.5678 seg. sex. )
%           a radianes.
% Recibe:   Angulo en pseudosexa ( positivo o negativo ).
% Devuelve: Angulo en radianes.
% Ejemplo:  fir=psdo_rad(fip);
function[radianes]=psdo_rad(pseudosexa)
if pseudosexa<0,
	sig=-1;
   pseudosexa=abs(pseudosexa);
else
	sig=1;
end;
pseudosexa1=p_entera(pseudosexa);
pseudosexa=(pseudosexa-pseudosexa1)*100;
pseudosexa2=p_entera(pseudosexa);
pseudosexa3=(pseudosexa-pseudosexa2)*100;
degsexa=pseudosexa1+pseudosexa2/60+pseudosexa3/3600;
radianes=sig*(degsexa*pi/180);
