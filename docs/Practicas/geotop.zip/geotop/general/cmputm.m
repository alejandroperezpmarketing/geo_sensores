% Funcion:  cmputm
% Objeto:   Comparar dos matrices de coordenadas
%           coor1: matriz original -> np,E(m),N(m),huso,H(ort/elp)
%           coor2: matriz a comparar -> np,E(m),N(m),huso,H(ort/elp)
% Devuelve: Una matriz con las diferencias coor2-coor2 expresadas en el sistema geodesico
%           local de cada punto (segun coordenadas contenidas en coor1)
% Llamadas: busca,psdo_rad,rm,rn
% Librer�as: General,Geodesia     
% Autor: Santiago Navarro Tar�n (2004)
% Ejemplo: [dif]=cmputm(coor1,coor2,elipsoide)
function[dif]=cmputm(coor1,coor2,elipsoide)
cont=0;
[m,n]=size(coor2);
for(i=1:m)
   np = coor2(i,1);
   fil = busca(np,coor1);
   if fil > 0,
      cont=cont+1;
      [lat1,lon1]=utmgeo(coor1(fil,2),coor1(fil,3),coor1(fil,4),elipsoide);
      [lat2,lon2]=utmgeo(coor2(i,2),coor2(i,3),coor2(i,4),elipsoide);
      dif(cont,1)=np;
      dif(cont,2) = ( lat2 - lat1 ) * rm(lat1,elipsoide);
      dif(cont,3) = ( lon2 - lon1 ) * rn(lat1,elipsoide) * cos(lat1);
      dif(cont,4) =  coor2(i,5)- coor1(fil,5);
   end;
end;
      
      
   

