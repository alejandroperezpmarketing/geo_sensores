% Funcion:  buscacol
% Objeto:   Localiza la primera ocurrencia de un numero en la fila
%           indicada de una matriz.
% Recibe:   Numero a localizar, matriz de busqueda y fila en la que buscar.
%           Ejemplo,
%				      npe=1003;
%				      nfil=3;
%				      coor=[ 1002  1004  1005  1006
%				             1060  1050  1049  1035
%                        1035  1003  1004  1007];

%           El valor devuelto por la funcion seria 2, columna numero 2.
% Devuelve: Posicion, numero de columna, comenzando en 1.
%           Si no lo encuentra devuelve -1.
% Ejemplo:  pos=buscacol(npe,coor,nfil);
function[n]=buscacol(j,c,nfil)
[fil,col]=size(c);
if nfil>fil,
   n=-1;
else,   
	control=0;
	i=1;
	while control==0,
		if(c(nfil,i)==j),
   		n=i;
      	control=1;
   	else,
      	i=i+1;
      	if(i>col),
      		control=1;
        		n=-1;
      	end;
   	end;
   end;
end;
