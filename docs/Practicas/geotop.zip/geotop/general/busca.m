% Funcion:  busca
% Objeto:   Localiza la primera ocurrencia de un numero en la primera
%           columna de una matriz.
% Recibe:   Numero a localizar y matriz de busqueda.
%           Ejemplo,
%				      npe=1003;
%				      coor=[ 1012  365897.345  4756234.459  30
%                        1110  325456.459  4754856.456  30
%                        1003  326666.555  4744444.333  30
%                        1145  377777.888  4722222.111  30];
%           El valor devuelto por la funcion seria 3, fila numero 3.
% Devuelve: Posicion, numero de fila, comenzando en 1.
%           Si no se encuentra devuelve -1.
% Ejemplo:  pos=busca(npe,coor);
function[n]=busca(j,c)
[fil,col]=size(c);
control=0;
i=1;
while control==0,
	if(c(i,1)==j),
   n=i;
   control=1;
   else,
   	i=i+1;
      if(i>fil),
      	control=1;
        	n=-1;
      end;
   end;
end;

