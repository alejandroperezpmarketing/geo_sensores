% Funcion:  rad2deg
% Objeto:   
% Recibe:   
% Devuelve: 
% Ejemplo:[angle_deg]=rad2deg(angle_rad);
function[angle_deg]=rad2deg(angle_rad);
angle_deg=angle_rad*180/pi;
