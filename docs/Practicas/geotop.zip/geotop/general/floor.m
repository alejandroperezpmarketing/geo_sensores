% Funcion:  floor
% Objeto:   Numero entero inferior al real dado. 
% Recibe:   - Numero real.
% Devuelve: Numero entero inferior.
% Ejemplo:  entmenor=floor(numreal);
%           Adviertase,
%             floor(3.6)=3
%             floor(3.2)=3
%             floor(-3.2)=-4;
%             floor(-3.6)=-4;
function[x]=floor(y)
x=round(y);
if (x-y>1e-10)&(y>0),
	x=x-1;
end;
if (x-y<1e-10)&(y<0),
   x=x+1;
end;
if (y<0)
   x=x-1;
end;

