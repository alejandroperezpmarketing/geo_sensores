% Funcion:  cmpgeo
% Objeto:   Comparar dos matrices de coordenadas
%           coor1: matriz original -> np,lat(psdo),lon(psdo),H(ort/elp)
%           coor2: matriz a comparar -> np,lat(rad),lon(rad),H(ort/elp)
% Devuelve: Una matriz con las diferencias expresadas en el sistema geodesico local
%           de cada punto
% Llamadas: busca,psdo_rad,rm,rn
% Librer�as: General,Geodesia     
% Autor: Santiago Navarro Tar�n (2004)
% Ejemplo: [dif]=cmpgeo(coor1,coor2,elipsoide)
function[dif]=cmpgeo(coor1,coor2,elipsoide)
cont=0;
[m,n]=size(coor2);
for(i=1:m)
   np = coor2(i,1);
   fil = busca(np,coor1);
   if fil ~= -1,
      cont=cont+1;
      dif(cont,1)=np;
      lat2 = psdo_rad(coor1(fil,2));
      lon2 = psdo_rad(coor1(fil,3));
      dif(cont,2) = ( coor2(i,2)- lat2 ) * rm(lat2,elipsoide);
      dif(cont,3) = ( coor2(i,3)- lon2 ) * rn(lat2,elipsoide) * cos(lat2);
      dif(cont,4) =  coor2(i,4)- coor1(fil,4);
   end;
end;
      
      
   

