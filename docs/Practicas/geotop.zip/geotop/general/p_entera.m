% Funcion:  p_entera
% Objeto:   Da la parte entera de un numero.
%           Si llega un numero tipo 36.999999999 se supone que era 37.
% Recibe:   Numero a truncar.
% Devuelve: Parte entera.
% Ejemplo:  pex=p_entera(x);
function[x]=int(y)
x=abs(y);
if (abs(x-round(x)))<1e-10,
	x=round(x);
end;
x=floor(x);
if y<0,
   x=-x;
end;

