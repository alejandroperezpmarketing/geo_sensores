% Funcion:  distancia
% Objeto:   Calculo de la distancia en el plano entre dos puntos.
% Recibe:   Coordenadas de los dos puntos.
% Devuelve: Distancia en la misma unidad que las coordenadas.
% Ejemplo:  d12=distancia(x1,y1,x2,y2);
function[d]=distancia(xi,yi,xj,yj)
ax=xj-xi;
ay=yj-yi;
d=sqrt(ax^2+ay^2);
