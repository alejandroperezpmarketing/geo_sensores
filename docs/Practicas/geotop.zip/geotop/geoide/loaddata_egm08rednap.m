% Funcion:  loaddata_egm08rednap
% Objeto:   Carga en memoria los datos del geoide EGM08REDNAP.
% Devuelve: Tres matrices con los siguientes datos:
%           - Matriz con las caracteristicas de la malla
%           - Matriz con los valores de ondulaci�n de la malla
%           - Matriz con los par�metros del elipsoide asociado al
%             sistema de referencia del elipsoide.
% Ejemplo:  [geodata1,geodata2,geodata3]=loaddata_egm08rednap();
