% Funcion:  eta_ed50
% Objeto:   Calcula la componente de la desviacion relativa de la vertical
%           en ED50 segun la direccion del primer vertical.
% Recibe:   Coordenadas geodesicas en radianes del punto: latitud y longitud.
%           El dominio de la longitud es [0,pi] U ]-pi,0]
% Devuelve: Componente de la desviacion relativa de la vertical en radianes.
% Ejemplo:  etap=eta_ed50(fip,lonp);
