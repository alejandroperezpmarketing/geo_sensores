% Funcion:  loaddata_ed50dma
% Objeto:   Carga en memoria los datos del geoide para Europa Occidental
%           (ED50) de la DMA (Defense Mapping Agency)
% Devuelve: Tres matrices con los siguientes datos:
%           - Matriz con las caracteristicas de la malla
%           - Matriz con los valores de ondulaci�n de la malla
%           - Matriz con los par�metros del elipsoide asiciado al
%             sistema de referencia del elipsoide.
% Ejemplo:  [geodata1,geodata2,geodata3]=loaddata_ed50dma
