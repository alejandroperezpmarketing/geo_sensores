% Funcion:  dvme
% Objeto:   Calcula desviacion de la vertical en la direcci�n del meridiano.
% Recibe:   - Matriz con los datos de la malla del geoide.
%           - Matriz con los datos de ondulaci�n del geoide.
%           - Matriz con los datos del elipsoide asociado al geoide.
%           - Latitud en radianes.
%           - Longitud en radianes.
%           - Elipsoide correspondiente al sistema de referencia de
%             las coordenadas anteriores. 0 si coincide con el del geoide.
%           - Matriz de parametros de transformaci�n (tx,ty,tz,dl,wx,wy,wz)'
%             para transformar desde el sistema de referencia de las coordenadas
%             al del geoide. 0 si coincide con el del geoide.
%           Las tres primeras matrices se obtienen cargando los datos correspondientes, p.ej:
%           para IBERGEO95   -> [geodata1,geodata2,geodata3]=loaddata_ibergeo95; 
%           para EGG97       -> [geodata1,geodata2,geodata3]=loaddata_egg97;
%           para ED50DMA     -> [geodata1,geodata2,geodata3]=loaddata_ed50dma; 
%           para EGM08REDNAP -> [geodata1,geodata2,geodata3]=loaddata_egm08rednap; 
% Devuelve: Desviacion de la vertical en la direccion del meridiano en radianes.
% Ejemplo:  [desv_me]=dvme(geodata1,geodata2,geodata3,lat,lon,0,0);