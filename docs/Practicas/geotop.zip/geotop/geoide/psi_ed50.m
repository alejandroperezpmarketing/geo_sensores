% Funcion:  psi_ed50
% Objeto:   Calcula la componente de la desviacion relativa de la vertical
%           en ED50 segun la direccion del meridiano.
% Recibe:   Coordenadas geodesicas en radianes del punto: Latitud y Longitud.
%           El dominio de la longitud es [0,pi] U ]-pi,0]
% Devuelve: Componente de la desviacion relativa de la vertical en radianes.
% Ejemplo:  psip=psi_ed50(fip,lonp);
% Llamadas: rm, rn.
